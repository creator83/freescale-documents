/*
 * Copyright (c) 2014 - 2015, Freescale Semiconductor, Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * o Redistributions of source code must retain the above copyright notice, this list
 *   of conditions and the following disclaimer.
 *
 * o Redistributions in binary form must reproduce the above copyright notice, this
 *   list of conditions and the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 *
 * o Neither the name of Freescale Semiconductor, Inc. nor the names of its
 *   contributors may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <stdarg.h>

#include "device/fsl_device_registers.h"
#include "uart/fsl_uart_driver.h"
#include "fsl_uart_hal.h"
#include "fsl_smc_features.h"
#include "fsl_smc_hal.h"
#include "gpio/fsl_gpio_driver.h"
#include "fsl_interrupt_manager.h"
#include "fsl_clock_manager.h"
#include "fsl_port_hal.h"
#include "fsl_sim_hal.h"
#include "fsl_mcg_hal.h"
#include "fsl_osc_hal.h"
#include "fsl_rtc_driver.h"
#include "fsl_rtc_hal.h"


#include "board.h"
#include "highspeed_run_demo.h"
#include "fsl_pmc_hal.h"
#include "fsl_gpio_common.h"
#include "fsl_uart_common.h"

/*******************************************************************************
 * Prototypes
 ******************************************************************************/
void llwu_isr(void);
extern void cpu_identify(void);
extern void Init_FFT(void);
extern void Run_FFT(int16_t nTimes);
extern void initsinlut(int16_t isinlut[]);
void de_init_pins(void);
void configure_rtc_stopwatch(void);
static void cmd_get_datetime(void);
void convert_time_to_seconds(rtc_datetime_t *datetime, uint32_t *seconds);

/*******************************************************************************
 * Variables
 ******************************************************************************/
uint8_t s_uartInstance; /*!< uart instance for the target */
uint8_t uartEnabled = 1;

static uart_state_t uartState; /*!< uart state information */
static uart_user_config_t uartConfig =
{
    115200,
    kUartParityDisabled,
    kUartOneStopBit,
    kUart8BitsPerChar
};

int32_t fastIrcFreq = 4000000;  /*!<default fast irc frequency */
int32_t slowIrcFreq = 32768; /*!<default slow irc frequency */
int32_t mcgClkHz; /*!< MCG out clock frequecy in Hz */
int32_t mcgClkKhz; /*!<MCG out clock frequency in KHz */
int32_t coreClkKhz; /*!<Core clock frequency in KHz */
int32_t periphClkKhz; /*!<Peripheral clock frequency in KHz */
int32_t pllClkKhz; /*!<PLL clock frequency in KHz */
int32_t uart0ClkKhz; /*!<UART0 clock frequency in KHz */
uint32_t uart0ClkHz; /*!<UART0 clock frequency in Hz */
uint32_t uartClkHz; /*!<Other uart clock frequcy in Hz */

// Stopwatch variables
volatile rtc_datetime_t rtcDatetimeStart;
volatile rtc_datetime_t rtcDatetimeStop;
volatile uint16_t rtc_prescaler1_isr = 0;
volatile uint16_t rtc_prescaler2_isr = 0;
volatile uint16_t rtc_sub_second_start = 0;
volatile uint16_t rtc_sub_second_stop = 0;

/*******************************************************************************
 * Code
 ******************************************************************************/

/*!
 * @brief main function.
 */
int main(void)
{
    hardware_init();

    UART_DRV_Init(BOARD_DEBUG_UART_INSTANCE, &uartState, &uartConfig);
        
    dbg_uart_init();

#if (defined(TWR_K22F120M)||defined(TWR_K64F120M)||defined(FRDM_K22F120M))
    s_uartInstance = 1;
#elif (defined(FRDM_KL25Z48M)||defined(FRDM_K64F120M))
    s_uartInstance = 0;
#endif

    /* check and print the reson of reset */
    out_srs();

    /* identify the cpu */
    cpu_identify();

    /* configure the LED pins in the hardware */
    led_init();

    /* Initialize FFT */
    Init_FFT();
          
    /* start test loop */
    hsrun_power_modes_test(); 

}

/*!
* @brief configure LED pins for the tower/freedom hardware
*/
void led_init(void)
{
	
    GPIO_DRV_Init(switchPins, ledPins);

    LED1_ON;
    LED2_ON;
    LED3_ON;
#if defined(TOWER)
    LED4_ON;
#endif

}

/*!
* @brief returns the the current MCG mode
*/
uint8_t what_mcg_mode(void)
{
   /* check if in FEI mode */
   if (((CLOCK_HAL_GetClkStatMode(MCG_BASE) == kMcgClkStatFll) && /* check CLKS mux has selcted FLL output */
        (CLOCK_HAL_GetInternalRefStatMode(MCG_BASE) == kMcgInternalRefStatInternal)   /* check FLL ref is internal ref clk */
#if FSL_FEATURE_MCG_HAS_PLL
            && (CLOCK_HAL_GetPllStatMode(MCG_BASE) != kMcgPllStatPllClkSel)
#endif
       ))  /* check PLLS mux has selected FLL */
   {
       /* return FEI code */
       return FEI;
   }
#if FSL_FEATURE_MCG_HAS_PLL
   /* Check MCG is in PEE mode */
   else if (((CLOCK_HAL_GetClkStatMode(MCG_BASE) == kMcgClkStatPll) && /* check CLKS mux has selcted PLL output */
             (CLOCK_HAL_GetInternalRefStatMode(MCG_BASE) != kMcgInternalRefStatInternal) /* check FLL ref is external ref clk */
                 &&(CLOCK_HAL_GetPllStatMode(MCG_BASE) == kMcgPllStatPllClkSel)
                     ))	 /* check PLLS mux has selected PLL */
   {
       /* return PEE code */
       return PEE;
   }
   /* Check MCG is in PBE mode */
   else if (((CLOCK_HAL_GetClkStatMode(MCG_BASE) == kMcgClkStatExternalRef) && /* check CLKS mux has selcted external reference */
             (CLOCK_HAL_GetInternalRefStatMode(MCG_BASE) != kMcgInternalRefStatInternal) &&	  /* check FLL ref is external ref clk */
                 (CLOCK_HAL_GetPllStatMode(MCG_BASE) == kMcgPllStatPllClkSel) &&	  /* check PLLS mux has selected PLL */
                     (CLOCK_HAL_GetLowPowerMode(MCG_BASE) != kMcgLowPowerSelLowPower)))	  /* check MCG_C2[LP] bit is not set */
   {
       /* return PBE code */
       return PBE;
   }
#endif
   /* Check MCG is in FBE mode */
   else if (((CLOCK_HAL_GetClkStatMode(MCG_BASE) == kMcgClkStatExternalRef) &&   /* check CLKS mux has selcted external reference */
             (CLOCK_HAL_GetInternalRefStatMode(MCG_BASE) != kMcgInternalRefStatInternal) &&	/* check FLL ref is external ref clk */
#if FSL_FEATURE_MCG_HAS_PLL
                 (CLOCK_HAL_GetPllStatMode(MCG_BASE) != kMcgPllStatPllClkSel) &&	/* check PLLS mux has selected FLL */
#endif 
                     (CLOCK_HAL_GetLowPowerMode(MCG_BASE) != kMcgLowPowerSelLowPower)))	/* check MCG_C2[LP] bit is not set */
   {
       /* return FBE code */
       return FBE;
   }
   /* Check MCG is in BLPE mode */
   else if (((CLOCK_HAL_GetClkStatMode(MCG_BASE) == kMcgClkStatExternalRef) && 	/* check CLKS mux has selcted external reference */
             (CLOCK_HAL_GetInternalRefStatMode(MCG_BASE) != kMcgInternalRefStatInternal) &&	/* check FLL ref is external ref clk */
                 (CLOCK_HAL_GetLowPowerMode(MCG_BASE) == kMcgLowPowerSelLowPower)))	/* check MCG_C2[LP] bit is set */
   {
       /* return BLPE code */
       return BLPE;
   }
   /* check if in BLPI mode */
   else if (((CLOCK_HAL_GetClkStatMode(MCG_BASE) == kMcgClkStatInternalRef) && 	/* check CLKS mux has selcted int ref clk */
             (CLOCK_HAL_GetInternalRefStatMode(MCG_BASE) == kMcgInternalRefStatInternal) &&	/* check FLL ref is internal ref clk */
#if FSL_FEATURE_MCG_HAS_PLL
                 (CLOCK_HAL_GetPllStatMode(MCG_BASE) != kMcgPllStatPllClkSel) &&	/* check PLLS mux has selected FLL */
#endif
                     (CLOCK_HAL_GetLowPowerMode(MCG_BASE) == kMcgLowPowerSelLowPower)))	/* check LP bit is set */
   {
       return BLPI;                                    /* return BLPI code */
   }
   /* check if in FBI mode */
   else if (((CLOCK_HAL_GetClkStatMode(MCG_BASE) == kMcgClkStatInternalRef) && 	/* check CLKS mux has selcted int ref clk */
             (CLOCK_HAL_GetInternalRefStatMode(MCG_BASE) == kMcgInternalRefStatInternal) &&	/* check FLL ref is internal ref clk */
#if FSL_FEATURE_MCG_HAS_PLL
                 (CLOCK_HAL_GetPllStatMode(MCG_BASE) != kMcgPllStatPllClkSel) &&	/* check PLLS mux has selected FLL */
#endif 
                     (CLOCK_HAL_GetLowPowerMode(MCG_BASE) != kMcgLowPowerSelLowPower)))	/* check LP bit is clear */
   {
       /* return FBI code */
       return FBI;
   }
   /* Check MCG is in FEE mode */
   else if (((CLOCK_HAL_GetClkStatMode(MCG_BASE) == kMcgClkStatFll) &&    /* check CLKS mux has selcted FLL */
             (CLOCK_HAL_GetInternalRefStatMode(MCG_BASE) != kMcgInternalRefStatInternal)/* check FLL ref is external ref clk */
#if FSL_FEATURE_MCG_HAS_PLL
                 &&(CLOCK_HAL_GetPllStatMode(MCG_BASE) != kMcgPllStatPllClkSel)
#endif
                     ))	/* check PLLS mux has selected FLL */
   {
       /* return FEE code */
       return FEE;
   }
   else
   {
       return 0;                                                            /* error condition */
   }
} /* what_mcg_mode */
  

/*!
 * @brief main high speed run mode test routine
 */
void hsrun_power_modes_test(void)
{
    uint8_t opMode, fcrDivVal;
    int8_t testNum = UNDEF_VALUE;
    uint8_t testVal;
    uint32_t settings;
    uint32_t startSeconds, totalSeconds;
    
    /* declare power mode config structure */
    smc_power_mode_config_t smcConfig;

    /* declare power mode protection for HSrun */
    smc_power_mode_protection_config_t pmodes = {
        .vlpProt  = false,
        .llsProt  = false,
        .vllsProt = false,
        .hsrunProt= true
    };
    rtc_datetime_t rtcDatetime=
    {
        2014, /*!< year   - Range from 1970 to 2099.*/
        1,    /*!< month  - Range from 1 to 12.*/
        1,    /*!< day    - Range from 1 to 31 (depending on month).*/
        0,    /*!< hour   - Range from 0 to 23.*/
        0,    /*!< minute - Range from 0 to 59.*/
        0     /*!< second - Range from 0 to 59.*/
    };

    rtcDatetime = rtcDatetime;  // touch to clear compiler warning

    printf("\n\r*------------------------------------------------------------*");
    printf("\n\r*                 Kinetis High Speed Run DEMO                *");
    printf("\n\r*                    %s %s                    *", __DATE__, __TIME__);
    printf("\n\r*------------------------------------------------------------*\n\r");

    /* Congigure power mode protection settings for the application*/
    SMC_HAL_SetProtection(SMC_BASE, &pmodes);

    /* Call function to configure and start the RTC. */
    configure_rtc_stopwatch();
    
    while(1)
    {
                  
        while ((testNum > 22) | (testNum < 0)){
            LED1_ON;
            LED2_ON;
            LED3_ON;
#if defined(TOWER)
            LED4_ON;
#endif
            if (SMC_HAL_GetStat(SMC_BASE) == kStatVlpr){
                printf("  in VLPR Mode !  ");
            } else if (SMC_HAL_GetStat(SMC_BASE) == kStatRun){
                printf("  in Run Mode  !  ");
            } else if (SMC_HAL_GetStat(SMC_BASE) == kStatHsrun){
                printf("  in HS Run Mode  !  ");
            }
            else{}
            opMode = what_mcg_mode();
            mcgClkHz = CLOCK_HAL_GetOutClk(MCG_BASE);

            CLOCK_SYS_GetDivider(kClockDividerOutdiv1, &settings);
            mcgClkHz =  mcgClkHz / (settings + 1);

            if (opMode ==1)
            {
                printf("in BLPI mode now at %d Hz\r\n",(int)mcgClkHz );
            }
            if (opMode ==2)
            {
                printf(" in FBI mode now at %d Hz\r\n",(int)mcgClkHz );
            }
            if (opMode ==3)
            {
                printf(" in FEI mode now at %d Hz\r\n",(int)mcgClkHz );
            }
            if (opMode ==4)
            {
                printf(" in FEE mode now at %d Hz\r\n",(int)mcgClkHz );
            }
            if (opMode ==5)
            {
                printf(" in FBE mode now at %d Hz\r\n",(int)mcgClkHz );
            }
            if (opMode ==6)
            {
                printf(" in BLPE mode now at %d Hz\r\n",(int)mcgClkHz );
            }
            if (opMode ==7)
            {
                printf(" in PBE mode now at %d Hz\r\n",(int)mcgClkHz );
            }
            if (opMode ==8)
            {
                printf(" in PEE mode now at %d Hz\r\n",(int)mcgClkHz );
            }
            printf("\n\rSelect the desired operation: \n\r");

            printf("0 for CASE 0: Enter High Speed Run (HSRun) @ 120MHz \n\r");
            printf("1 for CASE 1: Enter Normal Run             @ 80MHz  \n\r");   
            printf("2 for CASE 2: Execute CPU load test at current speed \n\r");   
            printf("\n\r*------------------------------------------------------------*\n\r");

            printf("\n\r>> ");

            testVal = getchar();
            

            if((testVal>=0x30) && (testVal<=0x39))
            {
                testNum = testVal - 0x30;
            }
            if((testVal>=0x41) && (testVal<=0x4C))
            {
                testNum = testVal - 0x37;
            }
            if((testVal>=0x61) && (testVal<=0x6C))
            {
                testNum = testVal - 0x57;
            }
        }
        LED1_OFF;
        LED2_OFF;
        LED3_OFF;
#if defined(TOWER)
        LED4_OFF;
#endif

        switch(testNum){

            case 0:/*HSRun @ 120MHz*/
                  printf("Press any key to enter HSRun\n\r ");
                  UART_DRV_ReceiveDataBlocking(BOARD_DEBUG_UART_INSTANCE, 
                                               &testVal, 1, OSA_WAIT_FOREVER);
                
                  /*Disable UART while changing run modes*/
                  UART_DRV_Deinit(BOARD_DEBUG_UART_INSTANCE);
                 
                  /* Setup Dividers for HSRun Mode */
                  /* core/system=120, bus=60, FlexBus=30, flash=24 [MHz]*/
                  CLOCK_HAL_SetOutDividers(SIM_BASE, 0,1,3,4);
                  
                  /* Go to HSRun*/
                  /* set power mode to HS Run mode */
                  SMC_HAL_SetRunMode(SMC_BASE, kSmcHsrun);
                  
                  /* poll PMSTAT until HSRun mode has been entered */
                  while(SMC_HAL_GetStat(SMC_BASE)&&kStatHsrun != kStatHsrun)
                  {}
                  
                  /* Configure and enable clocks for HSRun mode */
                  pee_pbe(CLK0_FREQ_HZ);
                  pbe_fbe(CLK0_FREQ_HZ);
                  fbe_pbe(CLK0_FREQ_HZ,PLL0_PRDIV_HS,PLL0_VDIV_HS);
                  mcgClkHz = pbe_pee(CLK0_FREQ_HZ);
                       
                  /* Re-configure UART clock settings */
                  fcrDivVal = (1 << CLOCK_HAL_GetFastClkInternalRefDivider(MCG_BASE));	/* calculate the fast IRC divder factor */
                  mcgClkHz =  (fastIrcFreq / fcrDivVal); /* MCGOUT frequency equals fast IRC frequency divided by 2 */
                  CLOCK_SYS_GetDivider(kClockDividerOutdiv1, &settings);
                  mcgClkHz =  mcgClkHz / (settings + 1);
                  uartClkHz = mcgClkHz; /* UART clock frequency will equal system frequency */
                  
                  /*Re-enable UART after changing run modes*/
                  UART_DRV_Init(BOARD_DEBUG_UART_INSTANCE, &uartState, &uartConfig);          
                  break;
                
            case 1:/* Run @ 80MHz*/
                  printf("Press any key to enter Normal Run\n\r ");
                  UART_DRV_ReceiveDataBlocking(BOARD_DEBUG_UART_INSTANCE, 
                                               &testVal, 1, OSA_WAIT_FOREVER);

                  /*Disable UART while changing run modes*/
                  UART_DRV_Deinit(BOARD_DEBUG_UART_INSTANCE);

                  /* Configure and enable clocks for Run mode */
                  pee_pbe(CLK0_FREQ_HZ);
                  pbe_fbe(CLK0_FREQ_HZ);
                  fbe_pbe(CLK0_FREQ_HZ,PLL0_PRDIV,PLL0_VDIV);
                  mcgClkHz = pbe_pee(CLK0_FREQ_HZ);
                  
                  /* Setup Dividers for Run Mode */
                  /* core/system=80, bus=40, FlexBus=20, flash=26.67 [MHz]*/
                  CLOCK_HAL_SetOutDividers(SIM_BASE, 0,1,3,2);
             
                  /* Currently in HS Run.  Exit HS Run */
                  SMC_HAL_SetRunMode(SMC_BASE, kSmcRun);
                  
                  /* poll PMSTAT until Run mode has been entered */
                  while(SMC_HAL_GetStat(SMC_BASE)&&kStatRun != kStatRun)
                  {}
                  
                  /* Re-configure UART clock settings */
                  fcrDivVal = (1 << CLOCK_HAL_GetFastClkInternalRefDivider(MCG_BASE));	/* calculate the fast IRC divder factor */
                  mcgClkHz =  (fastIrcFreq / fcrDivVal); /* MCGOUT frequency equals fast IRC frequency divided by 2 */
                  CLOCK_SYS_GetDivider(kClockDividerOutdiv1, &settings);
                  mcgClkHz =  mcgClkHz / (settings + 1);
                  uartClkHz = mcgClkHz; /* UART clock frequency will equal system frequency */
                  
                  /* Re-enable UART after changing run modes*/
                  UART_DRV_Init(BOARD_DEBUG_UART_INSTANCE, &uartState, &uartConfig);
                  break;
 
            case 2:/*Execute CPU Test load*/
                  printf("\n\r* Start FFT *");
                  printf("\n\r");
                  
                  // Get RTC date, time, and sub-seconds prior to FFT
                  do {
                      RTC_DRV_GetDatetime(RTC_INST, (rtc_datetime_t *)&rtcDatetimeStart);
                      
                      // Need to read the prescaler twice to ensure that the time is valid.  
                      rtc_prescaler1_isr = RTC_HAL_GetPrescaler(RTC_BASE);
                      rtc_prescaler2_isr = RTC_HAL_GetPrescaler(RTC_BASE);
                  }while(rtc_prescaler1_isr != rtc_prescaler2_isr);
                  rtc_sub_second_start = (uint16_t)(rtc_prescaler1_isr / 327.68);
        
                  // Execute (N-number) of complex FFTs 
                  Run_FFT(50); 
                  
                  // Get RTC date, time, and sub-seconds after the FFT
                  do {
                      RTC_DRV_GetDatetime(RTC_INST, (rtc_datetime_t *)&rtcDatetimeStop);
                      rtc_prescaler1_isr = RTC_HAL_GetPrescaler(RTC_BASE);
                      rtc_prescaler2_isr = RTC_HAL_GetPrescaler(RTC_BASE);
                  }while(rtc_prescaler1_isr != rtc_prescaler2_isr);
                  rtc_sub_second_stop = (uint16_t)(rtc_prescaler1_isr / 327.68);
        
                  printf("\r* FFT Done  *");
                  
                 // Print Results of timing.  
                  printf("\n\n\rStart Time  = %02d:%02d:%02d.%02d\n\r",rtcDatetimeStart.hour,
                                rtcDatetimeStart.minute,
                                rtcDatetimeStart.second, 
                                rtc_sub_second_start);
                  printf("Stop Time   = %02d:%02d:%02d.%02d\n\n\r",rtcDatetimeStop.hour,
                                rtcDatetimeStop.minute,
                                rtcDatetimeStop.second, 
                                rtc_sub_second_stop);
                  
                  // Set rtcDatetime to the Stop time
                  rtcDatetime.hour = rtcDatetimeStop.hour;
                  rtcDatetime.minute = rtcDatetimeStop.minute;
                  rtcDatetime.second = rtcDatetimeStop.second;
                  
                  // Find the difference in seconds.  
                  convert_time_to_seconds((rtc_datetime_t *)&rtcDatetimeStart, &startSeconds);
                  convert_time_to_seconds((rtc_datetime_t *)&rtcDatetimeStop, &totalSeconds);
                  
                  if(rtc_sub_second_stop >= rtc_sub_second_start)
                  {
                      // If the stop sub-seconds are greater than the start
                      // time sub-seconds, we can simply subtract the start
                      //  seconds from the stop seconds, and do the same for
                      //  the sub-seconds.  
                      totalSeconds -= startSeconds;
                      rtc_sub_second_stop -= rtc_sub_second_start;
                  }
                  else
                  {
                      // If the stop sub-seconds are less than the start
                      //  time sub-seconds, we have to borrow from the seconds.
                      //  To do that, subtract one from the stop time seconds
                      //  and add 100 to the sub-seconds.  
                      totalSeconds -= 1;
                      totalSeconds -= startSeconds;
                      rtc_sub_second_stop += 100;
                      rtc_sub_second_stop -= rtc_sub_second_start;
                  }
                  printf("FFT Runtime in Total Seconds  = %2d.%02d\n\n\r",(int)totalSeconds,(int)rtc_sub_second_stop);
                  break;

            case 3:/*RTC test*/
                  printf("\n\r");
                  cmd_get_datetime();
                  printf("\n\r");
                  break;
                  
            case 0x0D:  /* enable debug mode */
                  printf("\n\r*--------------D E B U G    E N A B L E D--------------------*\n\r ");
                  SWD_CLK_ENABLE;
                  SWD_DIO_ENABLE;
                  break;
               
            case 0x15:  /* disable debug mode */
                  printf("\n\r*--------------D E B U G    D I S A B L E D------------------*\n\r ");
                  SWD_CLK_DISABLE;
                  SWD_DIO_DISABLE;
                  break;

              default:
                  break;
            }

            testNum = UNDEF_VALUE ;

	}
}

/*!
 * @brief switches from PEE to PBE mode
 * @param crystalVal - crystal value
 */
int32_t pee_pbe(int32_t crystalVal)
{
    int16_t i;

    /* Check MCG is in PEE mode */
    if (!((CLOCK_HAL_GetClkStatMode(MCG_BASE) == kMcgClkStatPll) &&        /* check CLKS mux has selcted PLL output */
          (CLOCK_HAL_GetInternalRefStatMode(MCG_BASE) != kMcgInternalRefStatInternal) &&	/* check FLL ref is external ref clk */
          (CLOCK_HAL_GetPllStatMode(MCG_BASE) == kMcgPllStatPllClkSel)))	/* check PLLS mux has selected PLL */
    {
      return 0x8;                                                       /* return error code */
    }

    /*
     * As we are running from the PLL by default the PLL and external clock settings are valid
     * To move to PBE from PEE simply requires the switching of the CLKS mux to select the ext clock
      */
    /* As CLKS is already 0 the CLKS value can simply be OR'ed into the register  */
    CLOCK_HAL_SetClkSrcMode(MCG_BASE, kMcgClkSelExternal);	/* switch CLKS mux to select external reference clock as MCG_OUT */


    /* Wait for clock status bits to update */
    for (i = 0 ; i < 2000 ; i++)
    {
        if (CLOCK_HAL_GetClkStatMode(MCG_BASE) == kMcgClkStatExternalRef)
        {
            break; /* jump out early if CLKST shows EXT CLK slected before loop finishes */
        }
    }
    if (CLOCK_HAL_GetClkStatMode(MCG_BASE) != kMcgClkStatExternalRef)
    {
        return 0x1A; /* check EXT CLK is really selected and return with error if not */
    }

    /* Now in PBE mode */
    return crystalVal; /* MCGOUT frequency equals external clock frequency */
} /* pee_pbe */

/*!
 * @brief switches from PBE to FBE mode
 * @param crystalVal - crystal value
 */
int32_t pbe_fbe(int32_t crystalVal)
{
    int16_t i;

    /* Check MCG is in PBE mode */
    if (!((CLOCK_HAL_GetClkStatMode(MCG_BASE) == kMcgClkStatExternalRef) &&       /* check CLKS mux has selcted external reference */
          (CLOCK_HAL_GetInternalRefStatMode(MCG_BASE) != kMcgInternalRefStatInternal) &&	/* check FLL ref is external ref clk */
          (CLOCK_HAL_GetPllStatMode(MCG_BASE) == kMcgPllStatPllClkSel) &&	/* check PLLS mux has selected PLL */
          (CLOCK_HAL_GetLowPowerMode(MCG_BASE) != kMcgLowPowerSelLowPower)))	/* check MCG_C2[LP] bit is not set */
    {
        return 0x7;                                                       /* return error code */
    }

    /*
     * As we are running from the ext clock, by default the external clock settings are valid
     * To move to FBE from PBE simply requires the switching of the PLLS mux to disable the PLL
     */

    CLOCK_HAL_SetPllSelMode(MCG_BASE, kMcgPllSelFll);	/* clear PLLS to disable PLL, still clocked from ext ref clk */

    /* wait for PLLST status bit to set */
    for (i = 0 ; i < 2000 ; i++)
    {
        if (!CLOCK_HAL_GetPllStatMode(MCG_BASE))
        {
            break; /* jump out early if PLLST clears before loop finishes */
        }
    }
    if (CLOCK_HAL_GetPllStatMode(MCG_BASE))
    {
        return 0x15; /* check bit is really clear and return with error if not clear */
    }

    /* Now in FBE mode */
    return crystalVal; /* MCGOUT frequency equals external clock frequency */
} /* pbe_fbe */

/*!
 * @brief switches from FBE to PBE mode
 * This function transitions the MCG from FBE mode to PBE mode.
 * This function presently only supports OSC0 and PLL0. Support for OSC1 and PLL1 will be added soon
 * The function requires the desired OSC and PLL be passed in to it for compatibility with the
 * future support of OSC/PLL selection
 *
 * @param crystalVal - external clock frequency in Hz
 * @param prDivVal - value to divide the external clock source by to create the desired
 *                           PLL reference clock frequency
 * @param vDivVal - value to multiply the PLL reference clock frequency by
 * Return value : MCGCLKOUT frequency (Hz) or error code
 */
int32_t fbe_pbe(int32_t crystalVal, int8_t prDivVal, int8_t vDivVal)
{
    int16_t i;
    int32_t pllFreq;

    /* Check MCG is in FBE mode */
    if (!((CLOCK_HAL_GetClkStatMode(MCG_BASE) == kMcgClkStatExternalRef) &&       /* check CLKS mux has selcted external reference */
          (CLOCK_HAL_GetInternalRefStatMode(MCG_BASE) != kMcgInternalRefStatInternal) &&	/* check FLL ref is external ref clk */
          (CLOCK_HAL_GetPllStatMode(MCG_BASE) != kMcgPllStatPllClkSel) &&	/* check PLLS mux has selected FLL */
          (CLOCK_HAL_GetLowPowerMode(MCG_BASE) != kMcgLowPowerSelLowPower)))	/* check MCG_C2[LP] bit is not set */
    {
        return 0x4;                                                       /* return error code */
    }

    /* As the external frequency has already been checked when FBE mode was enterred it is not checked here */

    /* Check PLL divider settings are within spec. */
    if ((prDivVal < 1) || (prDivVal > 26)) {return 0x41;} //todo CJR
    if ((vDivVal < 24) || (vDivVal > 50)) {return 0x42;}

    /* Check PLL reference clock frequency is within spec. */
    if (((crystalVal / prDivVal) < 2000000) || ((crystalVal / prDivVal) > 6000000)) {return 0x43;} //todo CJR

    /* Check PLL output frequency is within spec. */
    pllFreq = (crystalVal / prDivVal) * vDivVal;
    if ((pllFreq < 48000000) || (pllFreq > 125000000)) {return 0x45;}  //todo CJR

    /* Configure MCG_C5 */
    /* If the PLL is to run in STOP mode then the PLLSTEN bit needs to be OR'ed in here or in user code. */
    CLOCK_HAL_SetPllExternalRefDivider0(MCG_BASE, prDivVal - 1);	/*set PLL ref divider */

    /* Configure MCG_C6 */
    /*
     * The PLLS bit is set to enable the PLL, MCGOUT still sourced from ext ref clk
     * The clock monitor is not enabled here as it has likely been enabled previously and so the value of CME
     * is not altered here.
     *
     * The loss of lock interrupt can be enabled by seperately OR'ing in the LOLIE bit in MCG_C6
     */
	/* write new VDIV and enable PLL */
    CLOCK_HAL_SetVoltCtrlOscDivider0(MCG_BASE, vDivVal - 24);
    CLOCK_HAL_SetPllSelMode(MCG_BASE, kMcgPllSelPllClkSel);

    /* wait for PLLST status bit to set */
    for (i = 0 ; i < 2000 ; i++)
    {
      if (CLOCK_HAL_GetPllStatMode(MCG_BASE))
      {
        break; /* jump out early if PLLST sets before loop finishes */
      }
    }
    if (!CLOCK_HAL_GetPllStatMode(MCG_BASE))
    {
      return 0x16; /* check bit is really set and return with error if not set */
    }

    /* Wait for LOCK bit to set */
    for (i = 0 ; i < 2000 ; i++)
    {
        if (CLOCK_HAL_GetLock0Mode(MCG_BASE))
        {
            break; /* jump out early if LOCK sets before loop finishes */
        }
    }
    if (!CLOCK_HAL_GetLock0Mode(MCG_BASE))
    {
        return 0x44; /* check bit is really set and return with error if not set */
    }

    /* now in PBE */
    return crystalVal; /* MCGOUT frequency equals external clock frequency */
} /* fbe_pbe */

/*!
 * @brief switches from PBE to PEE mode
 * @param crystalVal - crystal value
 */
int32_t pbe_pee(int32_t crystalVal)
{
    uint8_t prDiv, vDiv;
    int16_t i;

    /* Check MCG is in PBE mode */
    if (!((CLOCK_HAL_GetClkStatMode(MCG_BASE) == kMcgClkStatExternalRef) &&       /* check CLKS mux has selcted external reference */
          (CLOCK_HAL_GetInternalRefStatMode(MCG_BASE) != kMcgInternalRefStatInternal) &&	/* check FLL ref is external ref clk */
          (CLOCK_HAL_GetPllStatMode(MCG_BASE) == kMcgPllStatPllClkSel) &&	/* check PLLS mux has selected PLL */
          (CLOCK_HAL_GetLowPowerMode(MCG_BASE) != kMcgLowPowerSelLowPower)))	/* check MCG_C2[LP] bit is not set */
    {
      return 0x7;                                                       /* return error code */
    }

    /* As the PLL settings have already been checked when PBE mode was enterred they are not checked here */

    /* Check the PLL state before transitioning to PEE mode */

    /* Check LOCK bit is set before transitioning MCG to PLL output (already checked in fbe_pbe but good practice */
    /* to re-check before switch to use PLL) */
    for (i = 0 ; i < 2000 ; i++)
    {
        if (CLOCK_HAL_GetLock0Mode(MCG_BASE))
        {
            break; /* jump out early if LOCK sets before loop finishes */
        }
    }
    if (!CLOCK_HAL_GetLock0Mode(MCG_BASE))
    {
      return 0x44; /* check bit is really set and return with error if not set */
    }
    /* Use actual PLL settings to calculate PLL frequency */
    prDiv = ((MCG_C5 & MCG_C5_PRDIV0_MASK) + 1);
    vDiv = ((MCG_C6 & MCG_C6_VDIV0_MASK) + 24);

    CLOCK_HAL_SetClkSrcMode(MCG_BASE, kMcgClkSelOut);	/* clear CLKS to switch CLKS mux to select PLL as MCG_OUT */

    /* Wait for clock status bits to update */
    for (i = 0 ; i < 2000 ; i++)
    {
        if (CLOCK_HAL_GetClkStatMode(MCG_BASE) == kMcgClkStatPll)
        {
            break; /* jump out early if CLKST = 3 before loop finishes */
        }
    }
    if (CLOCK_HAL_GetClkStatMode(MCG_BASE) != kMcgClkStatPll)
    {
        return 0x1B; /* check CLKST is set correctly and return with error if not */
    }

    /* Now in PEE */
    return ((crystalVal / prDiv) * vDiv); /*MCGOUT equals PLL output frequency */

}  /* pbe_pee */

/*!
 * @brief checks the value in the SRS registers and sends
 * messages to the terminal announcing the status at the start of the
 * code.
 */
void out_srs(void)
{
    if (RCM_SRS1 & RCM_SRS1_SACKERR_MASK)
    {
        printf("\n\rStop Mode Acknowledge Error Reset");
    }
    if (RCM_SRS1 & RCM_SRS1_MDM_AP_MASK)
    {
	printf("\n\rMDM-AP Reset");
    }
    if (RCM_SRS1 & RCM_SRS1_SW_MASK)
    {
	printf("\n\rSoftware Reset");
    }
    if (RCM_SRS1 & RCM_SRS1_LOCKUP_MASK)
    {
	printf("\n\rCore Lockup Event Reset");
    }

    if (RCM_SRS0 & RCM_SRS0_POR_MASK)
    {
	printf("\n\rPower-on Reset");
    }
    if (RCM_SRS0 & RCM_SRS0_PIN_MASK)
    {
	printf("\n\rExternal Pin Reset");
    }
    if (RCM_SRS0 & RCM_SRS0_WDOG_MASK)
    {
	printf("\n\rWatchdog(COP) Reset");
    }
    if (RCM_SRS0 & RCM_SRS0_LOC_MASK)
    {
	printf("\n\rLoss of External Clock Reset");
    }
#if FSL_FEATURE_RCM_HAS_LOL
    if (RCM_SRS0 & RCM_SRS0_LOL_MASK)
    {
	printf("\n\rLoss of Lock in PLL Reset");
    }
#endif
    if (RCM_SRS0 & RCM_SRS0_LVD_MASK)
    {
	printf("\n\rLow-voltage Detect Reset");
    }
    if (RCM_SRS0 & RCM_SRS0_WAKEUP_MASK)
    {
        printf("\n\r[outSRS]Wakeup bit set from low power mode ");
        if (SMC_HAL_GetStopMode(SMC_BASE) == kSmcLls)
        {
            printf("LLS exit ") ;
        }
        if ((SMC_HAL_GetStopMode(SMC_BASE)== kSmcVlls) && (SMC_HAL_GetStopSubMode(SMC_BASE)== kSmcStopSub0))
        {
            printf("VLLS0 exit ") ;
        }
        if ((SMC_HAL_GetStopMode(SMC_BASE)== kSmcVlls) && (SMC_HAL_GetStopSubMode(SMC_BASE)== kSmcStopSub1))
        {
            printf("VLLS1 exit ") ;
        }
        if ((SMC_HAL_GetStopMode(SMC_BASE)== kSmcVlls) && (SMC_HAL_GetStopSubMode(SMC_BASE)== kSmcStopSub2))
        {
            printf("VLLS2 exit") ;
        }
        if ((SMC_HAL_GetStopMode(SMC_BASE)== kSmcVlls) && (SMC_HAL_GetStopSubMode(SMC_BASE)== kSmcStopSub3))
        {
            printf("VLLS3 exit ") ;
        }
    }

    printf("\n\r");

    if ((RCM_SRS0 == 0) && (RCM_SRS1 == 0))
    {
	printf("[outSRS]RCM_SRS0 is ZERO   = %#02X \r\n\r", (RCM_SRS0))  ;
	printf("[outSRS]RCM_SRS1 is ZERO   = %#02X \r\n\r", (RCM_SRS1))  ;
    }
}

/*!
 * @brief configure_rtc_stopwatch routine
 *
 * Setup function to use RTC like a stopwatch
 *
 */
void configure_rtc_stopwatch(void)
{
    /* RTC configuration structures */	
	  rtc_datetime_t rtcDatetime =
    {
        2014, /*!< year   - Range from 1970 to 2099.*/
        1,    /*!< month  - Range from 1 to 12.*/
        1,    /*!< day    - Range from 1 to 31 (depending on month).*/
        0,    /*!< hour   - Range from 0 to 23.*/
        0,    /*!< minute - Range from 0 to 59.*/
        0     /*!< second - Range from 0 to 59.*/
    };
		
    /* Set the Clock Gates on RTC */
    CLOCK_SYS_EnableRtcClock(0);

    /* Turn on the RTC Oscillator */
    RTC_HAL_SetOscillatorCmd(RTC_BASE, true);

    /* Set the Date and Time */
    RTC_HAL_SetDatetime(RTC_BASE, &rtcDatetime);
}

/*!
 * @brief get the current date time.
 *
 * This function get the current date time
 */
static void cmd_get_datetime(void)
{
    rtc_datetime_t date;
    RTC_DRV_GetDatetime(RTC_INST, &date);
    printf("Current datetime: %04hd-%02hd-%02hd %02hd:%02hd:%02hd\r\n",
           date.year, date.month, date.day,
           date.hour, date.minute, date.second);
}

/*!
 * @brief converts RTC time to seconds.
 *
 * This function converts hours+min+sec to total seconds
 */
void convert_time_to_seconds(rtc_datetime_t *datetime, uint32_t *seconds)
{
    *seconds = ((datetime->hour * SECONDS_IN_A_HOUR) + 
               (datetime->minute * SECONDS_IN_A_MIN) + datetime->second);
    (*seconds)++;
}

void HardFault_Handler(void)
{
#ifdef TWR_K22F120M
   PORTD_PCR5 = 0;
   PORTD_PCR6 = 0;
   PORTD_PCR4 = 0;
   
   PORTD_PCR7 = PORT_PCR_MUX(1);
   
   GPIOD_PDDR = (1 << 7);
   GPIOD_PCOR = (1 << 7);
#else
   PORTE_PCR7 = 0;
   PORTE_PCR8 = 0;
   PORTE_PCR9 = 0;
   
   PORTE_PCR6 = PORT_PCR_MUX(1);
   
   GPIOE_PDDR = (1 << 6);
   GPIOE_PCOR = (1 << 6);
#endif
   while(1)
   {}
   
}

void de_init_pins(void)
{
   
   /* I2C Pins */
   /* PORTD_PCR8 */
   PORT_HAL_SetMuxMode(PORTD_BASE,8u,kPortPinDisabled);
   /* PORTD_PCR9 */
   PORT_HAL_SetMuxMode(PORTD_BASE,9u,kPortPinDisabled);
   /* PORTC_PCR10 */
   PORT_HAL_SetMuxMode(PORTC_BASE,10u,kPortPinDisabled);
   /* PORTC_PCR11 */
   PORT_HAL_SetMuxMode(PORTC_BASE,11u,kPortPinDisabled);
   /* PORTE_PCR24 */
   PORT_HAL_SetMuxMode(PORTE_BASE,24u,kPortPinDisabled);
   /* PORTE_PCR25 */
   PORT_HAL_SetMuxMode(PORTE_BASE,25u,kPortPinDisabled);
   
   /* RTC Pins */
   PORT_HAL_SetMuxMode(PORTE_BASE,26u,kPortPinDisabled);
   
   /* MISC */
   PORT_HAL_SetMuxMode(PORTB_BASE,6u,kPortPinDisabled);
   PORT_HAL_SetMuxMode(PORTB_BASE,8u,kPortPinDisabled);
   PORT_HAL_SetMuxMode(PORTC_BASE,8u,kPortPinDisabled);
   PORT_HAL_SetMuxMode(PORTC_BASE,9u,kPortPinDisabled);
   
#if defined(FRDM_K64F120M)
   /* SDHC Pins */
   /* PORTE_PCR3 */
   PORT_HAL_SetMuxMode(PORTE_BASE,3u,kPortPinDisabled);
   /* PORTE_PCR1 */
   PORT_HAL_SetMuxMode(PORTE_BASE,1u,kPortPinDisabled);
   /* PORTE_PCR0 */
   PORT_HAL_SetMuxMode(PORTE_BASE,0u,kPortPinDisabled);
   /* PORTE_PCR5 */
   PORT_HAL_SetMuxMode(PORTE_BASE,5u,kPortPinDisabled);
   /* PORTE_PCR4 */
   PORT_HAL_SetMuxMode(PORTE_BASE,4u,kPortPinDisabled);
   /* PORTE_PCR2 */
   PORT_HAL_SetMuxMode(PORTE_BASE,2u,kPortPinDisabled);
#endif
   
   /* SPI Pins */
   /* PORTD_PCR0 */
   PORT_HAL_SetMuxMode(PORTD_BASE,0u,kPortPinDisabled);
   /* PORTD_PCR3 */
   PORT_HAL_SetMuxMode(PORTD_BASE,3u,kPortPinDisabled);
   /* PORTD_PCR1 */
   PORT_HAL_SetMuxMode(PORTD_BASE,1u,kPortPinDisabled);
   /* PORTD_PCR2 */
   PORT_HAL_SetMuxMode(PORTD_BASE,2u,kPortPinDisabled);
   /* PORTB_PCR10 */
   PORT_HAL_SetMuxMode(PORTB_BASE,10u,kPortPinDisabled);
   /* PORTB_PCR11 */
   PORT_HAL_SetMuxMode(PORTB_BASE,11u,kPortPinDisabled);
#if !defined(FRDM_K64F120M)
   /* PORTB_PCR17 */
   PORT_HAL_SetMuxMode(PORTB_BASE,17u,kPortPinDisabled);
   /* PORTB_PCR16 */
   PORT_HAL_SetMuxMode(PORTB_BASE,16u,kPortPinDisabled);
#endif
   
   /* CAN Pins */
   /* PORTB_PCR19 */
   PORT_HAL_SetMuxMode(PORTB_BASE,19u,kPortPinDisabled);
   /* PORTB_PCR18 */
   PORT_HAL_SetMuxMode(PORTB_BASE,18u,kPortPinDisabled);
   
   /* Ethernet Pins */
   /* PORTC_PCR16 */
   PORT_HAL_SetMuxMode(PORTC_BASE,16u,kPortPinDisabled);
   /* PORTC_PCR17 */
   PORT_HAL_SetMuxMode(PORTC_BASE,17u,kPortPinDisabled);
   /* PORTC_PCR18 */
   PORT_HAL_SetMuxMode(PORTC_BASE,18u,kPortPinDisabled);
   /* PORTC_PCR19 */
   PORT_HAL_SetMuxMode(PORTC_BASE,19u,kPortPinDisabled);
   /* PORTA_PCR14 */
   PORT_HAL_SetMuxMode(PORTA_BASE,14u,kPortPinDisabled);
   /* PORTB_PCR1 */
   PORT_HAL_SetMuxMode(PORTB_BASE,1u,kPortPinDisabled);
   /* PORTB_PCR0 */
   PORT_HAL_SetMuxMode(PORTB_BASE,0u,kPortPinDisabled);
   /* PORTA_PCR13 */
   PORT_HAL_SetMuxMode(PORTA_BASE,13u,kPortPinDisabled);
   /* PORTA_PCR12 */
   PORT_HAL_SetMuxMode(PORTA_BASE,12u,kPortPinDisabled);
   /* PORTA_PCR5 */
   PORT_HAL_SetMuxMode(PORTA_BASE,5u,kPortPinDisabled);
   /* PORTA_PCR16 */
   PORT_HAL_SetMuxMode(PORTA_BASE,16u,kPortPinDisabled);
   /* PORTA_PCR17 */
   PORT_HAL_SetMuxMode(PORTA_BASE,17u,kPortPinDisabled);
   /* PORTA_PCR15 */
   PORT_HAL_SetMuxMode(PORTA_BASE,15u,kPortPinDisabled);
}

/*******************************************************************************
* EOF
******************************************************************************/
