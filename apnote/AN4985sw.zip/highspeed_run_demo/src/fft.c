/*
 * Copyright (c) 2014 - 2015, Freescale Semiconductor, Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * o Redistributions of source code must retain the above copyright notice, this list
 *   of conditions and the following disclaimer.
 *
 * o Redistributions in binary form must reproduce the above copyright notice, this
 *   list of conditions and the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 *
 * o Neither the name of Freescale Semiconductor, Inc. nor the names of its
 *   contributors may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#include <stdio.h>
#include <stdint.h>

#include "fft.h"
#include "math.h"

/*******************************************************************************
 * Prototypes
 ******************************************************************************/
void Init_FFT(void);
void Run_FFT(int16_t nTimes);
void initsinlut(int16_t isinlut[]);
  
// __ramfunc 

/*******************************************************************************
 * Code
 ******************************************************************************/
// Decimation in Time FFT complex algorithm
// Note: the sign of the complex exponential in the transform is defined as:
// X[k] = Sum(j = 0, N - 1) x[j] exp(-2 * PI * i * j * k / N)
// x[j] = Sum(k = 0, N - 1) X[k] exp(+2 * PI * i * j * k / N)
// Note: the 1/iN normalization is not applied to the inverse transform
// Note: iN should be a power of 2 with iN=1 valid
void fComplexFFT(struct fcomplex fX[], uint32_t iN, int16_t idirection)
{
	// calling parameters
	// fX: array of complex input data replaced by FFT  
	// iN: size of FFT (ie use 1024 for 1K transform not 10)
	// idirection: +1 for forward transform and -1 for inverse transform
	// non-negative values of idirection are mapped to +1 and negative values to -1

	// local variables
	uint32_t iM;					// FFT size increasing from 2 to iN
	uint32_t i, j, k;				// loop counters
	struct fcomplex fWMjk;		// fWM^jk
	struct fcomplex fWM;		// fWM
	struct fcomplex ftmp;		// temporary complex

	// for safety, detect and correct erroneous values of idirection
	if (idirection >= 0)
		idirection = 1;
	else
		idirection = -1;

	// shuffle the input data so the output will be correctly ordered
	// loop over all elements in the data array
	j = 0;
	for (i = 0; i < iN; i++)
	{
		// only swap when j is greater than i to avoid double cancelling swaps
		if (j > i)
		{
			// swap data in bins i and j
			ftmp = fX[j];
			fX[j] = fX[i];
			fX[i] = ftmp;
		}
		// set k to the highest bit address bit only set (N/2)
		k = iN >> 1;
		// loop subtracting successively smaller powers of 2 from j
		while ((k > 0) && (j >= k))
		{
			j -= k;
			k >>= 1;
		}
		j += k;
	}

	// loop over FFT sizes M doubling from 2 up to and including N
	// which is log2(N) iterations each of which makes 2 calls to trig functions
	// for 1K FFT, there are 10 iterations and only 20 expensive trig calls
	iM = 2;
	while (iM <= iN)
	{
		// fWM = exp(-2 * PI * i / M) for FFT and exp(2 * PI * i / M) for IFFT
		// this is used recurrently to rotate the phasor fWMjk=fWM^jk
		ftmp.Re = -(idirection * TWOPI) / iM;
		fWM.Re = cosf(ftmp.Re);
		fWM.Im = sinf(ftmp.Re);

		// set fWMjk = 1.0 = fWM^0;
		fWMjk.Re = 1.0F;
		fWMjk.Im = 0.0F;

		// M/2 iterations of the outer loop
		for (i = 0; i < (iM >> 1); i++)
		{
			// N/M iterations of the inner loop
			for (k = i; k < iN; k += iM)
			{
				// add offset iM/2 to k to get the index j of the second butterfly data point
				j = k + (iM >> 1);

				// Butterfly pre-compute: ftmp = fWMjk * fX[j]
				ftmp.Re = fWMjk.Re * fX[j].Re - fWMjk.Im * fX[j].Im;
				ftmp.Im = fWMjk.Re * fX[j].Im + fWMjk.Im * fX[j].Re;

				// apply butterfly for element j: fX[j] = fX[k] - fWMjk * fX[j]
				fX[j].Re = fX[k].Re - ftmp.Re;
				fX[j].Im = fX[k].Im - ftmp.Im;

				// apply butterfly for element k: fX[k] = fX[k] + fWMjk * fX[j]
				fX[k].Re += ftmp.Re;
				fX[k].Im += ftmp.Im;
			}

			// rotate the phasor fWMjk = fWMjk * fWM for next iteration of k
			ftmp.Re = fWMjk.Re;
			fWMjk.Re = ftmp.Re * fWM.Re - fWMjk.Im * fWM.Im;
			fWMjk.Im = ftmp.Re * fWM.Im + fWMjk.Im * fWM.Re;
		}

		// double M for FFT with size 2M on next pass 
		iM <<= 1;
	}

	return;
}

// initialize FFT processing
void Init_FFT(void)
{
	int32_t ibin;			// bin index
	float ftmp;			// scratch

	// zero the two FFT buffers
	for (ibin = 0; ibin < FFTSIZE; ibin++)
	{
		FFTArrayA[ibin].Re = FFTArrayA[ibin].Im = 0.0F;
		//FFTArrayB[ibin].Re = FFTArrayB[ibin].Im = 0.0F;
		FFTArrayB[ibin].Re = FFTArrayB[ibin].Im = sine_table[ibin % SINE_TABLE_SIZE] * 1.0F;

	}
                                                       
	// initialize the global FFT pointers
	pBufferingFFTArray = FFTArrayA;
	pProcessingFFTArray = FFTArrayB;

	// initialize the output scaling
	globals.fScaling = thisSensor.fgPerCount;  

	// compute the N/2 left hand half of the symmetric Blackman-Nuttall windowing function
	// using Q15 format mapping +1.00 onto 32768 giving maximum value of (int16) 32767.2994 = 32767
	for (ibin = 0; ibin < FFTSIZE / 2; ibin++)
	{
		ftmp = A0 - A1 * cosf(2.0F * PI * (float) ibin / (float)(FFTSIZE - 1)) + 
				A2 * cosf(4.0F * PI * (float) ibin / (float)(FFTSIZE - 1)) - 
				A3 * cosf(6.0F * PI * (float) ibin / (float)(FFTSIZE - 1));
		Blackman[ibin] = (int16_t) (ftmp * 32768.0F);
	}

	// initialize the sine wave look up table
	initsinlut(isinlut);

	return;
}

// execute the Fourier domain processing for block n-1
// at the end of this function:
// a) pProcessingFFTArray[].Re holds the array of autocorrelation function elements for transmission
// b) pProcessingFFTArray[].Im holds the array of logarithmic high or low pass filtered PSD elements for transmission
// c) LowPassPSD[] holds the low pass filtered PSD array
// d) HighPassPSD[] holds the low pass filtered PSD array
void Run_FFT(int16_t nTimes)
{
	int32_t i, ibin;						// bin counter
	float fLPF;						// low pass filter coefficient
	float ftmp;						// scratch


        for (i =0; i < nTimes; i++)
        {
            // compute the forward complex FFT in situ
            fComplexFFT(pProcessingFFTArray, FFTSIZE, 1);

            // loop over all bins updating the low and high pass filtered power spectral densities
            // this loop assumes that the input data is real and the spectrum is therefore
            // symmetric about Nyquist
            fLPF = 1.0F / (float) globals.Averaging;
            for (ibin = 0; ibin < (FFTSIZE / 2 + 1); ibin++)
            {
                    // set ftmp to the modulus squared of this FFT bin
                    ftmp = pProcessingFFTArray[ibin].Re * pProcessingFFTArray[ibin].Re +
                                    pProcessingFFTArray[ibin].Im * pProcessingFFTArray[ibin].Im;

                    // reset or update the exponential low pass filtered estimate LPFPSD
                    if ((globals.RequestedResetPSDCountdown == 0) || (globals.Averaging == 1))
                            // reset the filtered value to the current power
                            LowPassPSD[ibin] = ftmp;
                    else
                            // update the low pass filter
                            LowPassPSD[ibin] += fLPF * (ftmp - LowPassPSD[ibin]);

                    // calculate the high pass filtered estimate
                    HighPassPSD[ibin] = ftmp - LowPassPSD[ibin];

            } // end of low pass filtering loop over FFT bins

            // copy the DC to Nyquist low pass PSD bins into the FFT array
            for (ibin = 0; ibin <= (FFTSIZE / 2); ibin++)
            {
                    pProcessingFFTArray[ibin].Re = LowPassPSD[ibin];
                    pProcessingFFTArray[ibin].Im = 0.0F;
            }
            // copy the remaining negative frequency low pass PSD bins into the FFT array
            for (ibin = (FFTSIZE / 2 + 1); ibin < FFTSIZE; ibin++)
            {
                    pProcessingFFTArray[ibin].Re = LowPassPSD[FFTSIZE - ibin];
                    pProcessingFFTArray[ibin].Im = 0.0F;
            }

            // compute the autocorrelation by applying inverse FFT to low pass PSD and normalize the real bins
            fComplexFFT(pProcessingFFTArray, FFTSIZE, -1);
            ftmp = 1.0F / (float) (FFTSIZE * FFTSIZE);
            for (ibin = 0; ibin < FFTSIZE; ibin++)
                    pProcessingFFTArray[ibin].Re *= ftmp;

            // copy the logarithmic high pass or low pass PSD into the imaginary components for transmission
            if (globals.PSDFilter == LPF)
            {
                    // low pass filter selected
                    for (ibin = 0; ibin < FFTSIZE; ibin++)
                    {	
                            // calculate logarithm of low pass PSD (lower limit -80dB)
                            if (LowPassPSD[ibin] > 0.0F)
                                    pProcessingFFTArray[ibin].Im = 10.0F * log10f(LowPassPSD[ibin]);			
                            else
                                    pProcessingFFTArray[ibin].Im = -80.0F;
                            if (pProcessingFFTArray[ibin].Im < -80.0F)
                                    pProcessingFFTArray[ibin].Im = -80.0F;
                    } // end of loop calculating logarithm of low pass PSD
            }
            else
            {
                    // high pass filter selected
                    for (ibin = 0; ibin < FFTSIZE; ibin++)
                    {	
                            // calculate logarithm of high pass PSD (lower limit -80dB)
                            if (HighPassPSD[ibin] > 0.0F)
                                    pProcessingFFTArray[ibin].Im = 10.0F * log10f(HighPassPSD[ibin]);			
                            else
                                    pProcessingFFTArray[ibin].Im = -80.0F;
                            if (pProcessingFFTArray[ibin].Im < -80.0F)
                                    pProcessingFFTArray[ibin].Im = -80.0F;
                    } // end of loop calculating logarithm of high pass PSD
            }

            // decrease the countdown flag if non-negative so that -1 denotes no pending reset
            if (globals.RequestedResetPSDCountdown >= 0)
                    globals.RequestedResetPSDCountdown--;
        }
        return;
}

// function initializes the look up table in the quadrant 0 to 90 deg
// for the functions isin and icos
void initsinlut(int16_t isinlut[])
{
	int16_t i;
	int32_t isin;

	// loop over all entries
	for (i = 0; i < NSINELUT; i++)
	{
		isin = (int32_t)(32768.0F * sinf((float) i * 90.0F / (float) (NSINELUT - 1) * FDEGTORAD) + 0.5F); 
		if (isin == 32768) isin = 32767;
		isinlut[i] = isin;
	}

	return;
}

/*******************************************************************************
 * EOF
 ******************************************************************************/
