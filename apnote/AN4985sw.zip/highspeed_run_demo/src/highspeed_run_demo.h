/*
 * Copyright (c) 2014 - 2015, Freescale Semiconductor, Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * o Redistributions of source code must retain the above copyright notice, this list
 *   of conditions and the following disclaimer.
 *
 * o Redistributions in binary form must reproduce the above copyright notice, this
 *   list of conditions and the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 *
 * o Neither the name of Freescale Semiconductor, Inc. nor the names of its
 *   contributors may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#ifndef __HIGHSPEED_RUN_DEMO_H__
#define __HIGHSPEED_RUN_DEMO_H__

#include <stdint.h>
#include "uart/fsl_uart_driver.h"
#include "fsl_smc_hal.h"
#include "fsl_mcg_hal.h"
#include "fsl_rtc_driver.h"
#include "fsl_rtc_hal.h"

/*******************************************************************************
 * Defination
 ******************************************************************************/
#define LOW_POWER 0                     /*!< Low power indication during PLL initialization */
#define HIGH_GAIN 1                     /*!< High power indication during PLL initialization */

#define CLK0_TYPE           CRYSTAL     /*!< Clock type indication */

#define MCGOUT 1                        /*!< MCG out indication during PLL initialization */         
   
#define SWD_CLK_DISABLE PORT_HAL_SetMuxMode(PORTA_BASE, 0, kPortPinDisabled)        /*!< Disable SWD port clock */
#define SWD_DIO_DISABLE	PORT_HAL_SetMuxMode(PORTA_BASE, 3, kPortPinDisabled)        /*!< Disable SWD port DIO */
   
#define SWD_CLK_ENABLE PORT_HAL_SetMuxMode(PORTA_BASE, 0, kPortMuxAlt7)         /*!< Enable SWD port clock */
#define SWD_DIO_ENABLE PORT_HAL_SetMuxMode(PORTA_BASE, 3, kPortMuxAlt7)         /*!< Enable SWD port DIO */

/* MCG Mode defines */
#define BLPI 1  /*!< BLPI MCG mode */
#define FBI  2  /*!< FBI MCG mode */
#define FEI  3  /*!< FEI MCG mode */
#define FEE  4  /*!< FEE MCG mode */
#define FBE  5  /*!< FBE MCG mode */
#define BLPE 6  /*!< BLPE MCG mode */
#define PBE  7  /*!< PBE MCG mode */
#define PEE  8  /*!< PEE MCG mode */

#define UNDEF_VALUE  0xFF

#ifdef  ON
#undef  ON
#endif
#define ON      (1)

#ifdef  OFF
#undef  OFF
#endif
#define OFF     (0)

/* Clock specific macros */   
#if (defined(TWR_K22F120M) || defined(FRDM_K22F120M))
#define CLK0_FREQ_HZ        8000000     /*!< 8MHz External Reference Clock */
#elif (defined(FRDM_K64F120M) || defined(TWR_K64F120M))
#define CLK0_FREQ_HZ		50000000 	/*!< 50MHz External Reference Clock */
#endif

#define CRYSTAL 1                       /*!< Crystal */
#define CANNED_OSC 0                    /*!< CANNED_OSC */

/* IRC defines */
#define SLOW_IRC 0                      /*!< Slow Internal Reference Clock */
#define FAST_IRC 1                      /*!< Fast Internal Reference Clock */

#define MCG_OUT_FREQ 48000000           /*!< Given MCG OUT Clock frequency*/

#if defined(CPU_MK22FN512VDC12)
#define OSC0_CR                         OSC_CR
#define SMC_STOPCTRL_VLLSM_MASK         SMC_STOPCTRL_LLSM_MASK
#endif

#if defined(CPU_MKL25Z128VLK4)       
#define sysinit                         SystemInit                                       
#endif

/* 
 * The expected PLL output frequency is:
 * PLL out = ((CLKIN/PRDIV) x VDIV)
 * where the CLKIN is CLK0_FREQ_HZ.
 *
 */

/* Clock specific macros */   
#if (defined(TWR_K22F120M) || defined(FRDM_K22F120M))
  #define PLL0_PRDIV      4       /*!<divide reference by 4 = 2 MHz */
  #define PLL0_VDIV       40      /*!<multiply reference by 40 = 80 MHz */
  #define PLL0_PRDIV_HS   2       /*!<divide reference by 2 = 4 MHz */
  #define PLL0_VDIV_HS    30      /*!<multiply reference by 30 = 120 MHz */
#elif (defined(FRDM_K64F120M) || defined(TWR_K64F120M))
  #define PLL0_PRDIV      25       /*!<divide reference by 4 = 2 MHz */
  #define PLL0_VDIV       40      /*!<multiply reference by 40 = 80 MHz */
  #define PLL0_PRDIV_HS   10       /*!<divide reference by 2 = 4 MHz */
  #define PLL0_VDIV_HS    24      /*!<multiply reference by 30 = 120 MHz */
#endif



/* Defines for RTC Stopwatch */   
#define RTC_INST                0
#define SECONDS_IN_A_DAY        (86400U)
#define SECONDS_IN_A_HOUR       (3600U)
#define SECONDS_IN_A_MIN        (60U)
#define DAYS_IN_A_YEAR          (365U)
#define DAYS_IN_A_LEAP_YEAR     (366U)


/*******************************************************************************
 * Prototypes
 ******************************************************************************/
void init_hardware(void);   
void hsrun_power_modes_test(void);
void led_init(void);
int printf_demo(const char *format,...);
uint8_t what_mcg_mode(void);
int32_t pee_pbe(int32_t crystalVal);
int32_t pbe_fbe(int32_t crystalVal);
int32_t fbe_pbe(int32_t crystalVal, int8_t prDivVal, int8_t vDivVal);
int32_t pbe_pee(int32_t crystalVal);
void out_srs(void);
void configure_rtc_stopwatch(void);
static void cmd_get_datetime(void);
void convert_time_to_seconds(rtc_datetime_t *datetime, uint32_t *seconds);
void convert_seconds_to_time(rtc_datetime_t *datetime, uint32_t *seconds);

#endif /* __HIGHSPEED_RUN_DEMO_H__*/

/*******************************************************************************
 * EOF
 ******************************************************************************/
