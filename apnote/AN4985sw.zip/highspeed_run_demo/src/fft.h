/*
 * Copyright (c) 2014 - 2015, Freescale Semiconductor, Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * o Redistributions of source code must retain the above copyright notice, this list
 *   of conditions and the following disclaimer.
 *
 * o Redistributions in binary form must reproduce the above copyright notice, this
 *   list of conditions and the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 *
 * o Neither the name of Freescale Semiconductor, Inc. nor the names of its
 *   contributors may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#ifndef __FFT_H__
#define __FFT_H__

#include <stdint.h>
#include "uart/fsl_uart_driver.h"
#include "fsl_smc_hal.h"
#include "fsl_mcg_hal.h"

/*******************************************************************************
 * Definition
 ******************************************************************************/
#define PI        3.141592654F       // Pi
#define TWOPI     6.28318530717959F  // 2*PI
#define FDEGTORAD 0.01745329251994F  // degrees to radians conversion = pi / 180
#define NSINELUT  91                 // corresponding to 1 deg resolution

// compile time constants for Blackman-Nuttall window function
#define A0 0.3635819F
#define A1 0.4891775F
#define A2 0.1365995F
#define A3 0.0106411F

// PSD filter options
#define LPF 0
#define HPF 1

// FFT size
#define FFTSIZE    2048    // size of complex FFT: 512=4K bytes per FFT array

#define SINE_TABLE_SIZE   48

/*******************************************************************************
 * Structures
 ******************************************************************************/
struct fcomplex
{
		float Re;	// real component
		float Im;	// imaginary component
};

struct ProjectGlobals
{
		// scaling from counts to physics units for current channel
		float fScaling;
		// requested parameters only changed at the end of each FFT block
		volatile int16_t RequestedSensorChannel;
		volatile int16_t RequestedWindow;
		volatile int16_t RequestedDCNotch;
		volatile int16_t RequestedResetPSDCountdown;
		volatile int16_t RequestedResetDCNotchFlag;
		volatile int16_t RequestedTimeDomainData;
		// requested parameters that can be changed immediately
		volatile int16_t Averaging;
		volatile int16_t PSDFilter;
		// actual parameters in use
		int16_t SensorChannel;
		int16_t Window;
		int16_t DCNotch;
		int16_t ResetDCNotchFlag;
		int16_t TimeDomainData;	
};
// dummy sensor structure definition
struct DummySensor
{
		float fGp[3];				// accelerometer (g)
		float fgPerCount;			// initialized to FGPERCOUNT
		int16_t iGp[3];				// accelerometer (counts)
};

/* Pre-generated sine wave data, 16-bit signed samples */
int16_t sine_table[SINE_TABLE_SIZE] = {
0x0000, 0x10b4, 0x2120, 0x30fb, 0x3fff, 0x4dea, 0x5a81, 0x658b,
0x6ed8, 0x763f, 0x7ba1, 0x7ee5, 0x7ffd, 0x7ee5, 0x7ba1, 0x76ef,
0x6ed8, 0x658b, 0x5a81, 0x4dea, 0x3fff, 0x30fb, 0x2120, 0x10b4,
0x0000, 0xef4c, 0xdee0, 0xcf06, 0xc002, 0xb216, 0xa57f, 0x9a75,
0x9128, 0x89c1, 0x845f, 0x811b, 0x8002, 0x811b, 0x845f, 0x89c1,
0x9128, 0x9a76, 0xa57f, 0xb216, 0xc002, 0xcf06, 0xdee0, 0xef4c
};


/*******************************************************************************
 * Variables
 ******************************************************************************/
struct ProjectGlobals globals;
struct fcomplex FFTArrayA[FFTSIZE];	// 4K at 512: complex FFT array A
struct fcomplex FFTArrayB[FFTSIZE];	// 4K at 512: complex FFT array B
//float FFTArrayA[FFTSIZE];	// 4K at 512: complex FFT array A
//float FFTArrayB[FFTSIZE];	// 4K at 512: complex FFT array B
struct DummySensor thisSensor;          // dummy sensor
struct fcomplex *pBufferingFFTArray;    // pointer to FFT array with block FFT[n-2] and block Data[n]
struct fcomplex *pProcessingFFTArray;   // pointer to FFT array with block Data[n-1] used to compute FFT
float  LowPassPSD[FFTSIZE / 2 + 1];
float  HighPassPSD[FFTSIZE / 2 + 1];
int16_t Blackman[FFTSIZE / 2];
int16_t isinlut[NSINELUT];                // sine wave look up table



/*******************************************************************************
 * Prototypes
 ******************************************************************************/
void fComplexFFT(struct fcomplex fX[], uint32_t iN, int16_t idirection);
extern void Init_FFT(void);
extern void Run_FFT(int16_t nTimes);
extern void initsinlut(int16_t isinlut[]);

#endif /* __FFT_H__*/

/*******************************************************************************
 * EOF
 ******************************************************************************/
