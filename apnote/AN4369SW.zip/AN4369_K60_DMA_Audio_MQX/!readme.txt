03-23-2012

1. 
This SW has to be compiled under EVARM IAR compiler enviroment.
Developed and tested with EVARM IAR 6.30.

2.
Freescale MQX has to be installed on the PC
Tested with MQX 3.8

3. 
Written for TWR-K60N512 card and TWR-AUDIO-SGTL card
