/*******************************************************************************
*
* Copyright 2014 Freescale Semiconductor, Inc.
*
* This software is owned or controlled by Freescale Semiconductor.
* Use of this software is governed by the Freescale License
* distributed with this Material.
* See the LICENSE file distributed for more details.
* 
*
****************************************************************************//*!
*
* @file     curr3ph_2sh.h
*
* @brief    A header file of 3 phase current measurement SAC module
* 
* @board    TWR-KV31F120M
* 
******************************************************************************/

#ifndef CURR3PH_2SH_H_
#define CURR3PH_2SH_H_

#include "sac_defines.h"

/******************************************************************************
| defines and macros
|----------------------------------------------------------------------------*/
typedef struct CURR3PH_2SH_T                CURR3PH_2SH_T;             /*!< @public */
typedef struct CURR3PH_2SH_ADC_OFFSET_T     CURR3PH_2SH_ADC_OFFSET_T;  /*!< @public */

/******************************************************************************
| typedefs and structures
|----------------------------------------------------------------------------*/

/*------------------------------------------------------------------------*//*!
@brief      Definition of public structure data type.
*//*-------------------------------------------------------------------------*/
struct CURR3PH_2SH_ADC_OFFSET_T
{
    GDFLIB_FILTER_MA_T_F16    sOffsetAdcIaFilter;       /* IA channel offset filter */
    GDFLIB_FILTER_MA_T_F16    sOffsetAdcIbFilter;       /* IB channel offset filter */
    GDFLIB_FILTER_MA_T_F16    sOffsetAdcIcFilter;       /* IC channel offset filter */
    UWord16                   uw16AdcIaCalib;           /* IA channel offset calibration */
    UWord16                   uw16AdcIbCalib;           /* IB channel offset calibration */
    UWord16                   uw16AdcIcCalib;           /* IC channel offset calibration */
    UWord16                   uw16AdcIa;                /* IA channel offset */
    UWord16                   uw16AdcIb;                /* IB channel offset */
    UWord16                   uw16AdcIc;                /* IC channel offset */
    UWord16                   uw16OffsetFiltWindow;     /* common offset filter window */
};

struct CURR3PH_2SH_T
{
    MCLIB_3_COOR_SYST_T         * psIABC;               /* pointer to the 3-phase currents */
    CURR3PH_2SH_ADC_OFFSET_T      sOffset;              /* phase currents offest structure */
    volatile UWord32            * puw32Adc0BaseAddress; /* pointer to ADC0 result register A */
    volatile UWord32            * puw32Adc1BaseAddress; /* pointer to ADC1 result register A */
    
             UWord16              uw16AchnGroupADC0;    /* ChannelGroup for ADC0: 0 - RA, 1 - RB */
             UWord16              uw16AchnGroupADC1;    /* ChannelGroup for ADC1: 0 - RA, 1 - RB */
    
             UWord16            * puw16SVMSector;       /* pointer to the SVM sector */
             UWord16              uw16Adc1Ia;           /* current Ia sample from ADC1 */
             UWord16              uw16Adc0Ib;           /* current Ib sample from ADC0 */
             UWord16              uw16Adc1Ib;           /* current Ib sample from ADC1 */
             UWord16              uw16Adc0Ic;           /* current Ic sample from ADC0 */
};

/******************************************************************************
| exported variables
|----------------------------------------------------------------------------*/

/******************************************************************************
| exported function prototypes
|----------------------------------------------------------------------------*/
#ifdef __cplusplus
extern "C" {
#endif

extern bool SAC_Curr3Ph2ShInit(CURR3PH_2SH_T * this);
extern bool SAC_Curr3Ph2ShGet(CURR3PH_2SH_T *this);
extern bool SAC_Curr3Ph2ShChanAssign(CURR3PH_2SH_T *this);  
extern bool SAC_Curr3Ph2ShCalibInit(CURR3PH_2SH_T *this);
extern bool SAC_Curr3Ph2ShCalib(CURR3PH_2SH_T *this);
extern bool SAC_Curr3Ph2ShCalibSet(CURR3PH_2SH_T *this);

#ifdef __cplusplus
}
#endif

#endif /* CURR3PH_2SH_H_ */
