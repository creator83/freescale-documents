/*******************************************************************************
*
* Copyright 2014 Freescale Semiconductor, Inc.
*
* This software is owned or controlled by Freescale Semiconductor.
* Use of this software is governed by the Freescale License
* distributed with this Material.
* See the LICENSE file distributed for more details.
* 
*
****************************************************************************//*!
*
* @file     curr3ph_2sh.c
*
* @brief    3-phase current sensing SAC module
* 
* @board    TWR-KV31F120M
*
******************************************************************************/

/******************************************************************************
| includes
|----------------------------------------------------------------------------*/
#include "curr3ph_2sh.h"

/******************************************************************************
| defines and macros                                      (scope: module-local)
|----------------------------------------------------------------------------*/

/******************************************************************************
| typedefs and structures                                 (scope: module-local)
|----------------------------------------------------------------------------*/

/******************************************************************************
| global variable definitions                          (scope: module-exported)
|----------------------------------------------------------------------------*/

/******************************************************************************
| global variable definitions                             (scope: module-local)
|----------------------------------------------------------------------------*/
static bool statusPass;

/******************************************************************************
| function prototypes                                     (scope: module-local)
|----------------------------------------------------------------------------*/

/******************************************************************************
| function implementations                                (scope: module-local)
|----------------------------------------------------------------------------*/
/***************************************************************************//*!
@brief   Initializes phase current measurement using 2 shunts

@param[in,out]  this    Pointer to the current object.

@return         bool

@details
******************************************************************************/
bool SAC_Curr3Ph2ShInit(CURR3PH_2SH_T * this)
{
    statusPass = TRUE;
        
    /* offset filter window */       
    this->sOffset.uw16OffsetFiltWindow = 3; 
    
    
    this->puw32Adc0BaseAddress = (volatile UWord32 *) (ADC0_BASE);              /* ADCx BASE Address */
    this->puw32Adc1BaseAddress = (volatile UWord32 *) (ADC1_BASE);              /* ADCx + 1 Base Address */
    
    this->uw16AchnGroupADC0 =  0;                                               /* ChannelGroup for ADC0: 0 - RA, 1 - RB */
    this->uw16AchnGroupADC1 =  0;                                               /* ChannelGroup for ADC1: 0 - RA, 1 - RB */  
    
    /* phase current AD channel assignment for TWR-MC-LV3PH board and TWR-KV31F120M */
    /*
      Quantity     | ADC Module 0                   | ADC Module 1
      --------------------------------------------------------------------------
      I_A (PTB20)  | ADC0_SE8 ADC0_SC1n_ADCH(0x08)  | ADC1_SE8  ADC1_SC1n_ADCH(0x08)
      I_B (pin 20) | ADC0_DP3 ADC0_SC1n_ADCH(0x03)  | ADC1_DP0  ADC1_SC1n_ADCH(0x00)
      I_C (pin 18) | ADC0_DP0  ADC0_SC1n_ADCH(0x00) | ADC1_DP3 ADC1_SC1n_ADCH(0x03)
     */
    
    this->uw16Adc1Ia   =  (0x08);                                               /* on the module 1 , current IA is sampled on channel 8 */
    this->uw16Adc0Ib   =  (0x03);                                               /* on the module 0 , current IB is sampled on channel 3 */
    this->uw16Adc1Ib   =  (0x00);                                               /* on the module 1 , current IB is sampled on channel 0 */
    this->uw16Adc0Ic   =  (0x00);                                               /* on the module 0 , current IC is sampled on channel 0 */  
    
    return(statusPass);
}

/***************************************************************************//*!
@brief      Reads and calculates 3 phase samples based on SVM sector

@param[in,out]  this    Pointer to the current object.

@return         bool

@details
******************************************************************************/
bool SAC_Curr3Ph2ShGet(CURR3PH_2SH_T *this)
{
    MCLIB_3_COOR_SYST_T sIABCtemp;
    
    statusPass = TRUE;
    
    volatile UWord16 uW16SampleADC0 = (UWord16) ADC_HAL_GetChnConvValueRAW((UWord32) this->puw32Adc0BaseAddress, this->uw16AchnGroupADC0);
    volatile UWord16 uW16SampleADC1 = (UWord16) ADC_HAL_GetChnConvValueRAW((UWord32) this->puw32Adc1BaseAddress, this->uw16AchnGroupADC0); 

    switch (*this->puw16SVMSector) 
    {
    case 2:
    case 3: /* direct sensing of A, C, calculation of B */
        sIABCtemp.f16A = MLIB_ShLSat_F16(((Frac16)((Word16 )uW16SampleADC1) - this->sOffset.uw16AdcIa),4);
        sIABCtemp.f16C = MLIB_ShLSat_F16(((Frac16)((Word16 )uW16SampleADC0) - this->sOffset.uw16AdcIc),4);  
        sIABCtemp.f16B = MLIB_Neg_F16(MLIB_AddSat_F16(sIABCtemp.f16A ,sIABCtemp.f16C));  
        break;
    
    case 4: 
    case 5: /* direct sensing of A, B, calculation of C */
        sIABCtemp.f16A = MLIB_ShLSat_F16(((Frac16)((Word16) uW16SampleADC1) - this->sOffset.uw16AdcIa),4);
        sIABCtemp.f16B = MLIB_ShLSat_F16(((Frac16)((Word16) uW16SampleADC0) - this->sOffset.uw16AdcIb),4);  
        sIABCtemp.f16C = MLIB_Neg_F16(MLIB_AddSat_F16(sIABCtemp.f16A ,sIABCtemp.f16B)); 
        break;

    case 1:
    case 6: /* direct sensing of B, C, calculation of A  */ 
    default: 
        sIABCtemp.f16B = MLIB_ShLSat_F16(((Frac16)((Word16) uW16SampleADC1) - this->sOffset.uw16AdcIb),4);
        sIABCtemp.f16C = MLIB_ShLSat_F16(((Frac16)((Word16) uW16SampleADC0) - this->sOffset.uw16AdcIc),4);  
        sIABCtemp.f16A = MLIB_Neg_F16(MLIB_AddSat_F16(sIABCtemp.f16B ,sIABCtemp.f16C)); 
        break;
    }

     /* pass measured phase currents to the main module structure */
    *this->psIABC = sIABCtemp;
    
    return(statusPass);
}
/***************************************************************************//*!
@brief      Set new channel assingment for next sampling based on SVM sector

@param[in,out]  this    Pointer to the current object.

@return         bool

@details
******************************************************************************/
bool SAC_Curr3Ph2ShChanAssign(CURR3PH_2SH_T *this)
{
    UWord16 uw16Temp;
    
    statusPass = TRUE;
    
    /* in order to keep the setting of ADC_SC1 (the AIEN and DIFF flags), 
      the original value of the register is first "anded" with 0x60 and then 
      "ored" with mask that sets the ADCH
    */
    
    /* for SDK compatible syntax are used CMSIS macros in this project functions */
    switch (*this->puw16SVMSector) 
    {
    case 2:
    case 3: /* currents Ia, Ic will be measured */
            uw16Temp = (HW_ADC_SC1n_RD((UWord32) this->puw32Adc1BaseAddress, this->uw16AchnGroupADC1) & 0x60);   // Load value from ADC_SC1n register to temp variable
            uw16Temp = uw16Temp | this->uw16Adc1Ia;                                                              // Assign ADC channel to temp variable 
            HW_ADC_SC1n_WR((UWord32) this->puw32Adc1BaseAddress, this->uw16AchnGroupADC1, uw16Temp);             // Load value from variable and set ADC channel to ADCn register
             
            uw16Temp = (HW_ADC_SC1n_RD((UWord32) this->puw32Adc0BaseAddress, this->uw16AchnGroupADC0) & 0x60);   // Load value from ADC_SC1n register to temp variable
            uw16Temp = uw16Temp | this->uw16Adc0Ic;                                                              // Assign ADC channel to temp variable 
            HW_ADC_SC1n_WR((UWord32) this->puw32Adc0BaseAddress, this->uw16AchnGroupADC0, uw16Temp);             // Load value from variable and set ADC channel to ADCn register
            break;
        case 4:
        case 5: /*  currents Ia, Ib will be measured */   
            uw16Temp = (HW_ADC_SC1n_RD((UWord32) this->puw32Adc1BaseAddress, this->uw16AchnGroupADC1) & 0x60);   // Load value from ADC_SC1n register to temp variable
            uw16Temp = uw16Temp | this->uw16Adc1Ia;                                                              // Assign ADC channel to temp variable 
            HW_ADC_SC1n_WR((UWord32) this->puw32Adc1BaseAddress, this->uw16AchnGroupADC1, uw16Temp);             // Load value from variable and set ADC channel to ADCn register
                 
            uw16Temp = (HW_ADC_SC1n_RD((UWord32) this->puw32Adc0BaseAddress, this->uw16AchnGroupADC0) & 0x60);   // Load value from ADC_SC1n register to temp variable
            uw16Temp = uw16Temp | this->uw16Adc0Ib;                                                              // Assign ADC channel to temp variable 
            HW_ADC_SC1n_WR((UWord32) this->puw32Adc0BaseAddress, this->uw16AchnGroupADC0, uw16Temp);             // Load value from variable and set ADC channel to ADCn register
            break;
        case 1:
        case 6: /* currents Ib, Ic will be measured */
        default:
            uw16Temp = (HW_ADC_SC1n_RD((UWord32) this->puw32Adc1BaseAddress, this->uw16AchnGroupADC1) & 0x60);   // Load value from ADC_SC1n register to temp variable
            uw16Temp = uw16Temp | this->uw16Adc1Ib;                                                              // Assign ADC channel to temp variable 
            HW_ADC_SC1n_WR((UWord32) this->puw32Adc1BaseAddress, this->uw16AchnGroupADC1, uw16Temp);             // Load value from variable and set ADC channel to ADCn register
                      
            uw16Temp = (HW_ADC_SC1n_RD((UWord32) this->puw32Adc0BaseAddress, this->uw16AchnGroupADC0) & 0x60);   // Load value from ADC_SC1n register to temp variable
            uw16Temp = uw16Temp | this->uw16Adc0Ic;                                                              // Assign ADC channel to temp variable 
            HW_ADC_SC1n_WR((UWord32) this->puw32Adc0BaseAddress, this->uw16AchnGroupADC0, uw16Temp);             // Load value from variable and set ADC channel to ADCn register
            break;
    }
    return(statusPass);
} 
/***************************************************************************//*!
@brief      Initializes phase current channel offest measurement

@param[in,out]  this    Pointer to the current object.

@return         bool

@details
******************************************************************************/
bool SAC_Curr3Ph2ShCalibInit(CURR3PH_2SH_T *this)
{
    statusPass = TRUE;
    
    /* clear offset values */
    this->sOffset.uw16AdcIa = 0;
    this->sOffset.uw16AdcIb = 0;
    this->sOffset.uw16AdcIc = 0;
    this->sOffset.uw16AdcIaCalib = 0;
    this->sOffset.uw16AdcIbCalib = 0;
    this->sOffset.uw16AdcIcCalib = 0;
    
    /* initalize offset filters */
    this->sOffset.sOffsetAdcIaFilter.u16NSamples = this->sOffset.uw16OffsetFiltWindow;
    GDFLIB_FilterMAInit_F16(&this->sOffset.sOffsetAdcIaFilter);
    
    this->sOffset.sOffsetAdcIbFilter.u16NSamples = this->sOffset.uw16OffsetFiltWindow;
    GDFLIB_FilterMAInit_F16(&this->sOffset.sOffsetAdcIbFilter);
    
    this->sOffset.sOffsetAdcIcFilter.u16NSamples = this->sOffset.uw16OffsetFiltWindow;
    GDFLIB_FilterMAInit_F16(&this->sOffset.sOffsetAdcIcFilter);

    return(statusPass);
}    

/***************************************************************************//*!
@brief      Reads current samples and filter them based on SVM sector

@param[in,out]  this    Pointer to the current object.

@return         bool

@details
******************************************************************************/
bool SAC_Curr3Ph2ShCalib(CURR3PH_2SH_T *this)
{
    Word16  w16SampleA, w16SampleB;     
    
    statusPass = TRUE;

    w16SampleA     = (UWord16) ADC_HAL_GetChnConvValueRAW((UWord32) this->puw32Adc1BaseAddress, this->uw16AchnGroupADC0);
    w16SampleB     = (UWord16) ADC_HAL_GetChnConvValueRAW((UWord32) this->puw32Adc0BaseAddress, this->uw16AchnGroupADC1);

    switch (*this->puw16SVMSector) 
    {
    case 2:
    case 3: 
        /* sensing of offset IA -> ADC1_A and IC -> ADC0_A  */
        this->sOffset.uw16AdcIaCalib = 
                GDFLIB_FilterMA_F16((Frac16)w16SampleA,&this->sOffset.sOffsetAdcIaFilter);
        this->sOffset.uw16AdcIcCalib = 
                GDFLIB_FilterMA_F16((Frac16)w16SampleB,&this->sOffset.sOffsetAdcIcFilter);
        break;
    
    case 4: 
    case 5: 
        /* sensing of offset IA -> ADC1_A and IB -> ADC0_A */
        this->sOffset.uw16AdcIaCalib = 
                GDFLIB_FilterMA_F16((Frac16)w16SampleA,&this->sOffset.sOffsetAdcIaFilter);
        this->sOffset.uw16AdcIbCalib = 
                GDFLIB_FilterMA_F16((Frac16)w16SampleB,&this->sOffset.sOffsetAdcIbFilter);
        break;

    case 1:
    case 6:
    default:
        /* sensing of offset IB -> ADC_A and IC -> ADC_B */
        this->sOffset.uw16AdcIbCalib = 
                GDFLIB_FilterMA_F16((Frac16)w16SampleA,&this->sOffset.sOffsetAdcIbFilter);
        this->sOffset.uw16AdcIcCalib = 
                GDFLIB_FilterMA_F16((Frac16)w16SampleB,&this->sOffset.sOffsetAdcIcFilter);
        break;
    }
    
    return(statusPass);
}

/***************************************************************************//*!
@brief      Passes measured offset values to main structure 

@param[in,out]  this    Pointer to the current object.

@return         bool

@details
******************************************************************************/
bool SAC_Curr3Ph2ShCalibSet(CURR3PH_2SH_T *this)
{
    statusPass = TRUE;
    
    this->sOffset.uw16AdcIa = this->sOffset.uw16AdcIaCalib;
    this->sOffset.uw16AdcIb = this->sOffset.uw16AdcIbCalib;
    this->sOffset.uw16AdcIc = this->sOffset.uw16AdcIcCalib;
    
    return(statusPass);
}  

/* End of file */
