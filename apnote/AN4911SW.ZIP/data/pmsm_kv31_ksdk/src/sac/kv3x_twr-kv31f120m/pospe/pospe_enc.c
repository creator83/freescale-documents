/*******************************************************************************
*
* Copyright 2014 Freescale Semiconductor, Inc.
*
* This software is owned or controlled by Freescale Semiconductor.
* Use of this software is governed by the Freescale License
* distributed with this Material.
* See the LICENSE file distributed for more details.
* 
*
****************************************************************************//*!
*
* @file     pospe_enc.c
*
* @brief    Position and speed SAC module based on quadrature encoder sensor 
*
* @board    TWR-KV31F120M
*
******************************************************************************/

/******************************************************************************
| includes
|----------------------------------------------------------------------------*/

#include "pospe_enc.h"

/******************************************************************************
| external declarations
|----------------------------------------------------------------------------*/

/******************************************************************************
| defines and macros                                      (scope: module-local)
|----------------------------------------------------------------------------*/

/******************************************************************************
| typedefs and structures                                 (scope: module-local)
|----------------------------------------------------------------------------*/

/******************************************************************************
| global variable definitions                          (scope: module-exported)
|----------------------------------------------------------------------------*/

/******************************************************************************
| global variable definitions                             (scope: module-local)
|----------------------------------------------------------------------------*/
static bool    statusPass;

/******************************************************************************
| function prototypes                                     (scope: module-local)
|----------------------------------------------------------------------------*/

/******************************************************************************
| function implementations                                (scope: module-local)
|----------------------------------------------------------------------------*/


/***************************************************************************//*!
@brief          Initialize internal module variables

@param[in,out]  this    Pointer to the current object.

@return         bool

@details
******************************************************************************/
bool SAC_PospeEncInit(POSPE_ENC_T * this)
{
    statusPass = TRUE;

    /* initialize FTM control registers */
    this->puw32FtmBaseAddress   = (volatile UWord32 *)(FTM1_BASE);              // FTM1 Base address
    
    this->f16PosError           = 0;
    this->f16PosMe              = 0;
    this->f16PosMeEst           = 0;
    this->f16SpeedMeEst         = 0;
    
    /* initilize tracking observer */
    this->sTo.f16Theta          = 0;
    this->sTo.f16Speed          = 0;
    this->sTo.f32I_1            = 0;
    this->sTo.f16IntegScale     = 0;
    this->sTo.i16IntegShift     = 0;
    this->sTo.f16PropScale 	= 0;
    this->sTo.i16PropShift 	= 0;
    this->sTo.f16ThScaled 	= 0;
    this->sTo.i16ThShift 	= 0;  
    
    
    return(statusPass);
}

/***************************************************************************//*!
@brief  Update number of pulses in FTM register setting

@param[in,out]  this    Pointer to the current object.

@return         bool

@details
******************************************************************************/
bool SAC_PospeEncConfig(POSPE_ENC_T * this)
{
    UWord16 uw16Edges;
    UWord16 uw16ClockSource;
    
    statusPass = TRUE;
    
    /* Number of the edge limit */
    uw16Edges = (this->uw16NoOfEncPuls * 4) - 1;
    
    /* Store registers */
    uw16ClockSource   = FTM_HAL_GetClockSource((UWord32) this->puw32FtmBaseAddress);
    
    /* disable Quadrature mode clear CLKS bit field to stop FTM */
    FTM_HAL_SetQuadDecoderCmd((UWord32) this->puw32FtmBaseAddress, false);
    FTM_HAL_SetClockSource((UWord32) this->puw32FtmBaseAddress, kClock_source_FTM_None);
    
    /* update counter register */
    FTM_HAL_SetMod((UWord32) this->puw32FtmBaseAddress,(UWord16) uw16Edges);
    
    /*Enable FTM clock */
    FTM_HAL_SetClockSource((UWord32) this->puw32FtmBaseAddress,(ftm_clock_source_t) uw16ClockSource);
    FTM_HAL_SetQuadDecoderCmd((UWord32) this->puw32FtmBaseAddress, true);
    
    return(statusPass);
}

/***************************************************************************//*!
@brief          Update actual position and speed

@param[in,out]  this    Pointer to the current object.

@return         bool

@details
******************************************************************************/
bool SAC_PospeEncGet(POSPE_ENC_T * this)
{
    statusPass = TRUE;
    
    this->f16PosMe = (Frac16)(MLIB_ShL_F16(MLIB_Mul_F16(this->f16PosMeGain, (Frac16)(FTM_HAL_GetCounter((UWord32) this->puw32FtmBaseAddress))), this->i16PosMeShift));
    
     /* Tracking observer calculation */			
    this->f16PosMeEst = ACLIB_TrackObsrv_F16(this->f16PosError, &this->sTo);
	
    /* Speed estimation by the tracking observer */
    this->f16SpeedMeEst = this->sTo.f16Speed;   	
 
    /* Calculation of error function for the TO  */
    this->f16PosError  = MLIB_Sub_F16(this->f16PosMe,this->f16PosMeEst);
    
    *this->pf16PosElEst     = (Frac16)(this->f16PosMe * this->uw16PolePairs);
    *this->pf16SpeedElEst   = (Frac16)(this->f16SpeedMeEst * this->uw16PolePairs);
    
    return(statusPass);
}

/***************************************************************************//*!
@brief          Clear internal module variables and FTM counter

@param[in,out]  this    Pointer to the current object.

@return         bool

@details
******************************************************************************/
bool SAC_PospeEncClear(POSPE_ENC_T * this)
{
    statusPass = TRUE;

    this->f16PosMeEst           = 0;
    this->f16SpeedMeEst         = 0;
    
    /* initilize tracking observer */
    this->sTo.f16Theta          = 0;
    this->sTo.f16Speed          = 0;
    this->sTo.f32I_1            = 0;
    
    /* clear FTM counter */
    FTM_HAL_SetCounter((UWord32) this->puw32FtmBaseAddress, 0);
    
    return(statusPass);
}

/***************************************************************************//*!
@brief          Clear internal module variables and FTM counter

@param[in,out]  this    Pointer to the current object.

@return         bool

@details
******************************************************************************/
bool SAC_PospeEncCountSet(POSPE_ENC_T * this, UWord16 uw16CountNo)
{
    statusPass = TRUE;
    
    /* set FTM counter to required value */
    FTM_HAL_SetCounter((UWord32) this->puw32FtmBaseAddress, uw16CountNo);
    
    return(statusPass);
}
/* End of file */
