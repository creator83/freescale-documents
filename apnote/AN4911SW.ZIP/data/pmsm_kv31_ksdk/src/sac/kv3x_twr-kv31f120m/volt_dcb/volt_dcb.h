/*******************************************************************************
*
* Copyright 2014 Freescale Semiconductor, Inc.
*
* This software is owned or controlled by Freescale Semiconductor.
* Use of this software is governed by the Freescale License
* distributed with this Material.
* See the LICENSE file distributed for more details.
* 
*
****************************************************************************//*!
*
* @file     volt_dcb.h
*
* @brief    A header file of DC-bus voltage sensing SAC module
*
* @board    TWR-KV31F120M
*
******************************************************************************/

#ifndef VOLT_DCB_H_
#define VOLT_DCB_H_

#include "sac_defines.h"

/******************************************************************************
| defines and macros
|----------------------------------------------------------------------------*/
typedef struct VOLT_DCB_T           VOLT_DCB_T; /*!< @public */

/******************************************************************************
| typedefs and structures
|----------------------------------------------------------------------------*/

/*------------------------------------------------------------------------*//*!
@brief      Definition of public structure data type.
*//*-------------------------------------------------------------------------*/
struct VOLT_DCB_T
{
    Frac16                 *pf16UDcBus;         /* pointer to DC Bus voltage variable */
    
    volatile UWord32       *puw32AdcBaseAdress; /* pointer to result register of DC Bus voltage sample */ 
    volatile UWord16        uw16AchnGroup;      /* value of ADC channel group */  
};

/******************************************************************************
| exported variables
|----------------------------------------------------------------------------*/

/******************************************************************************
| exported function prototypes
|----------------------------------------------------------------------------*/
#ifdef __cplusplus
extern "C" {
#endif

extern bool SAC_VoltDcBusInit(VOLT_DCB_T * this);
extern bool SAC_VoltDcBusGet(VOLT_DCB_T * this);

#ifdef __cplusplus
}
#endif

#endif /* VOLT_DCB_H_ */
