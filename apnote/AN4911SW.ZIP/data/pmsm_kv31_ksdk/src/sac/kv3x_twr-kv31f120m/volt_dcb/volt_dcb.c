/*******************************************************************************
*
* Copyright 2014 Freescale Semiconductor, Inc.
*
* This software is owned or controlled by Freescale Semiconductor.
* Use of this software is governed by the Freescale License
* distributed with this Material.
* See the LICENSE file distributed for more details.
* 
*
****************************************************************************//*!
*
* @file     volt_dcb.c
*
* @brief    DC-bus voltage sensing SAC module
*
* @board    TWR-KV31F120M
*
******************************************************************************/

/******************************************************************************
| includes
|----------------------------------------------------------------------------*/
#include "volt_dcb.h"

/******************************************************************************
| defines and macros                                      (scope: module-local)
|----------------------------------------------------------------------------*/

/******************************************************************************
| typedefs and structures                                 (scope: module-local)
|----------------------------------------------------------------------------*/

/******************************************************************************
| global variable definitions                          (scope: module-exported)
|----------------------------------------------------------------------------*/

/******************************************************************************
| global variable definitions                             (scope: module-local)
|----------------------------------------------------------------------------*/
static bool statusPass;

/******************************************************************************
| function prototypes                                     (scope: module-local)
|----------------------------------------------------------------------------*/

/******************************************************************************
| function implementations                                (scope: module-local)
|----------------------------------------------------------------------------*/

/***************************************************************************//*!
@brief          Function initializes DCB voltage result register address

@param[in,out]  this    Pointer to the current object.

@return         bool

@details
******************************************************************************/
bool SAC_VoltDcBusInit(VOLT_DCB_T * this)
{
    statusPass = TRUE;
        
    /* result register channel 2, ADC0_RB = 0x4003B014 */
    this->puw32AdcBaseAdress = (volatile UWord32 *)(ADC0_BASE);                 // Adress of ADC0 or ADC1
    this->uw16AchnGroup = 1;                                                    // Channel group: 0 - RA, 1 - RB
    return(statusPass);
}

/***************************************************************************//*!
@brief          Function reads DCB voltage sample

@param[in,out]  this    Pointer to the current object.

@return         bool

@details        Result register value is shifted 3 times right and stored to
*               DCBus voltage pointer 
******************************************************************************/
bool SAC_VoltDcBusGet(VOLT_DCB_T * this)
{
    statusPass = TRUE;
        
    /* read DC Bus voltage sample from defined ADC result register */
    *this->pf16UDcBus = (Frac16)MLIB_ShLSat_F16(((UWord16)(ADC_HAL_GetChnConvValueRAW((UWord32) this->puw32AdcBaseAdress, this->uw16AchnGroup))), 3);
    
    return(statusPass);
}

/* End of file */
