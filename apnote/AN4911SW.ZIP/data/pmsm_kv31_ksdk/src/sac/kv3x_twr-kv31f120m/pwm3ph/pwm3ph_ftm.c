/*******************************************************************************
*
* Copyright 2014 Freescale Semiconductor, Inc.
*
* This software is owned or controlled by Freescale Semiconductor.
* Use of this software is governed by the Freescale License
* distributed with this Material.
* See the LICENSE file distributed for more details.
* 
*
****************************************************************************//*!
*
* @file     pwm3ph_ftm.c
*
* @brief    3-phase PWM FTM driver layer of SAC module
*
* @board    TWR-KV31F120M
*
******************************************************************************/

/******************************************************************************
| includes
|----------------------------------------------------------------------------*/
#include "pwm3ph_ftm.h"

/******************************************************************************
| defines and macros                                      (scope: module-local)
|----------------------------------------------------------------------------*/

/******************************************************************************
| typedefs and structures                                 (scope: module-local)
|----------------------------------------------------------------------------*/

/******************************************************************************
| global variable definitions                          (scope: module-exported)
|----------------------------------------------------------------------------*/

/******************************************************************************
| global variable definitions                             (scope: module-local)
|----------------------------------------------------------------------------*/
static bool statusPass;

/******************************************************************************
| function prototypes                                     (scope: module-local)
|----------------------------------------------------------------------------*/

/******************************************************************************
| function implementations                                (scope: module-local)
|----------------------------------------------------------------------------*/

/***************************************************************************//*!
@brief          Pointers initialization to value, mask, load and modulo FTM regs

@param[in,out]  this    Pointer to the current object.

@return         bool

@details
******************************************************************************/
bool SAC_FtmPwm3PhInit(PWM3PH_FTM_T * this)
{
    statusPass = TRUE;
 
    /* Set Base Address of FTM peripheral */
    this->puw32PwmBaseAddress    = (volatile UWord32 *)(FTM0_BASE);             //  FTM0_BaseAddress
    
    return(statusPass);
}

/***************************************************************************//*!
@brief          Write new values to FTM value registers and update them

@param[in,out]  this    Pointer to the current object.

@return         bool

@details
******************************************************************************/
bool SAC_FtmPwm3PhSet(PWM3PH_FTM_T * this)
{
    Frac16                        f16DutyCycle;
    Frac16                        uw16ModuloTemp;  
    MCLIB_3_COOR_SYST_T_F16       sUABCtemp;   
    statusPass = TRUE;
    
    /* pointer to duty cycle structure */
    sUABCtemp = *this->psUABC;
    
    uw16ModuloTemp = (UWord16)FTM_HAL_GetMod((UWord32) this->puw32PwmBaseAddress);                 /* Get modulo value */
    
    /* phase A */
    f16DutyCycle = MLIB_Mul_F16(uw16ModuloTemp, sUABCtemp.f16A);
    FTM_HAL_SetChnCountVal((UWord32) this->puw32PwmBaseAddress, 0, (Word16) MLIB_Neg_F16(f16DutyCycle));
    FTM_HAL_SetChnCountVal((UWord32) this->puw32PwmBaseAddress, 1, (Word16) (f16DutyCycle));
    
    /* phase B */
    f16DutyCycle = MLIB_Mul_F16(uw16ModuloTemp, sUABCtemp.f16B);
    FTM_HAL_SetChnCountVal((UWord32) this->puw32PwmBaseAddress, 2, (Word16) MLIB_Neg_F16(f16DutyCycle));
    FTM_HAL_SetChnCountVal((UWord32) this->puw32PwmBaseAddress, 3, (Word16) (f16DutyCycle));
    
    /* phase C */
    f16DutyCycle = MLIB_Mul_F16(uw16ModuloTemp, sUABCtemp.f16C);           
    FTM_HAL_SetChnCountVal((UWord32) this->puw32PwmBaseAddress, 4, (Word16) MLIB_Neg_F16(f16DutyCycle));
    FTM_HAL_SetChnCountVal((UWord32) this->puw32PwmBaseAddress, 5, (Word16) (f16DutyCycle));  
    
    /*
     * Set LDOK bit in FTm PWMLOAD register
     */
    FTM_HAL_SetPwmLoadCmd((Word32) this->puw32PwmBaseAddress, true);
    
    return(statusPass);
}

/***************************************************************************//*!
@brief          Enable PWM outputs

@param[in,out]  this    Pointer to the current object.

@return         bool

@details
******************************************************************************/
bool SAC_FtmPwm3PhOutEn(PWM3PH_FTM_T * this)
{
    statusPass = TRUE;
    
    /* FlexTIMER
     * OUTMASK register = mcPWM_BASE + $0x60
     *
     * Any write to the OUTMASK register, stores the value in its write buffer. The register is
     * updated with the value of its write buffer according to PWM synchronization.
     *
     * CHnOM = 0 - Channel output is not masked. It continues to operate normally.
     * CHnOM = 1 - Channel output is masked. It is forced to its inactive state.
     * |----------------------------------------------------------------------------|
     * |bits:   |   31..8   |  7   |   6  |   5  |  4   |   3  |  2   |  1   |  0   |     
     * |Meaning:| RESERVED  |CH7OM |CH6OM |CH5OM |CH4OM |CH3OM |CH2OM |CH1OM |CH0OM |
     * |----------------------------------------------------------------------------|
     * |Value:  |     0     |      |      |      |      |      |      |      |      |
     * |----------------------------------------------------------------------------|
     */

    /* PWM outputs enabled in channels 0..5 */
    HW_FTM_OUTMASK_WR((Word32) this->puw32PwmBaseAddress, 0x0000);

    return(statusPass);
}

/***************************************************************************//*!
@brief          Disable PWM outputs

@param[in,out]  this    Pointer to the current object.

@return         bool

@details
******************************************************************************/
bool SAC_FtmPwm3PhOutDis(PWM3PH_FTM_T * this)
{
    statusPass = TRUE;
    
    /* FlexTIMER
     * OUTMASK register = mcPWM_BASE + $0x60
     *
     * Any write to the OUTMASK register, stores the value in its write buffer. The register is
     * updated with the value of its write buffer according to PWM synchronization.
     *
     * CHnOM = 0 - Channel output is not masked. It continues to operate normally.
     * CHnOM = 1 - Channel output is masked. It is forced to its inactive state.
     * |----------------------------------------------------------------------------|
     * |bits:   |   31..8   |  7   |   6  |   5  |  4   |   3  |  2   |  1   |  0   |         
     * |Meaning:| RESERVED  |CH7OM |CH6OM |CH5OM |CH4OM |CH3OM |CH2OM |CH1OM |CH0OM |
     * |----------------------------------------------------------------------------|
     * |Value:  |     0     |      |      |      |      |      |      |      |      |
     * |----------------------------------------------------------------------------|
     */

    /* PWM outputs disabled in channels 0..5 */
    HW_FTM_OUTMASK_WR((Word32) this->puw32PwmBaseAddress, 0x003F);

    return(statusPass);
}

/* End of file */
