/*******************************************************************************
*
* Copyright 2014 Freescale Semiconductor, Inc.
*
* This software is owned or controlled by Freescale Semiconductor.
* Use of this software is governed by the Freescale License
* distributed with this Material.
* See the LICENSE file distributed for more details.
* 
*
****************************************************************************//*!
*
* @file     volt_dcb.h
*
* @brief    A header file of DC-bus voltage sensing SAC module
*
** @board    TWR-KV31F120M
*
******************************************************************************/

#ifndef DRIVER3PH_H_
#define DRIVER3PH_H_

#include "sac_defines.h"
#include "fsl_dspi_hal.h"
#include "fsl_gpio_hal.h"

/******************************************************************************
| defines and macros
|----------------------------------------------------------------------------*/
typedef struct DRIVER3PH_T           DRIVER3PH_T;   /*!< @public */
typedef struct MC33937DSPI_T         MC33937DSPI_T; /*!< @public */
/******************************************************************************
| typedefs and structures
|----------------------------------------------------------------------------*/
/*------------------------------------------------------------------------*//*!
@brief  Structure containing
*//*-------------------------------------------------------------------------*/
typedef union
{
    UWord8 R;
    struct { /* MC33937 faults */
        UWord8    overTemp       :1;    
        UWord8    desaturation   :1;
        UWord8    lowVls         :1;
        UWord8    overCurrent    :1;
        UWord8    phaseErr       :1;
        UWord8    framingErr     :1;
        UWord8    writeErr       :1;
        UWord8    resetEvent     :1;
    }B;
}mc33937ConfigMask_t;

typedef union
{
    UWord8 R;
    struct {
        UWord8    lock          :1;    /* lock configuration regs */
        UWord8    enableFullOn  :1;    /* enable FULL ON PWM's without DT */
        UWord8                  :1;    
        UWord8    disableDesat  :1;    /* disable phase desaturation error */
        UWord8                  :1;
        UWord8                  :1;
        UWord8                  :1;
        UWord8                  :1;
    }B;
}mc33937Mode_t;

typedef union {
    UWord8 R;
    struct {
        UWord8     overTemp     :1;    /* TLIM flag detected on any channel */
        UWord8     desaturation :1;    /* DESAT flag detected on any channel */
        UWord8     lowVls       :1;    /* Low VLS voltage flag */
        UWord8     overCurrent  :1;    /* Over-current event flag */
        UWord8     phaseErr     :1;    /* Phase error flag */
        UWord8     framingErr   :1;    /* Framing error flag */
        UWord8     writeErr     :1;    /* Write Error After the Lock flag */
        UWord8     resetEvent   :1;    /* reset event flag, is set upon exiting /RST */
    } B;
}mc33937SR0_t;

typedef union {
    UWord8 R;
    struct {
        UWord8     lockbit      :1;     /* LockBit indicates the IC regs are locked */
        UWord8     fullon       :1;     /* present status of FULLON MODE */
        UWord8                  :1;     /* reserved */
        UWord8     deadtime_cal :1;     /* Deadtime calibration occurred */
        UWord8     calib_overfl :1;     /* flag for a Deadtime Calibration Overflow */
        UWord8     zds          :1;     /* Zero deadtime is commanded */
        UWord8     desat_mode   :1;     /* current state of the Desaturation/Phase Error turn-off mode */
        UWord8                  :1;     /* reserved */
    } B;
}mc33937SR1_t;

typedef union {
    UWord8 R;
    struct {
        UWord8     mask0_0      :1;     /* status of the MASK0.0 bit */
        UWord8     mask0_1      :1;     /* status of the MASK0.1 bit */
        UWord8     mask0_2      :1;     /* status of the MASK0.2 bit */
        UWord8     mask0_3      :1;     /* status of the MASK0.3 bit */
        UWord8     mask1_0      :1;     /* status of the MASK1.0 bit */
        UWord8     mask1_1      :1;     /* status of the MASK1.1 bit */
        UWord8     mask1_2      :1;     /* status of the MASK1.2 bit */
        UWord8     mask1_3      :1;     /* status of the MASK1.3 bit */
    } B;
}mc33937SR2_t;

/*------------------------------------------------------------------------*//*!
@brief  Structure containing
*//*-------------------------------------------------------------------------*/
struct MC33937DSPI_T
{
      volatile UWord32   * puw32SpiBaseAddress;                                 /* SPI base address */
  
      volatile UWord32   * puw32GpioEnBaseAdd;                                  /* PORT status register for driver enabled */
      volatile UWord32     uw32GpioEnPin;                                       /* pin number for driver enabled */
      
      volatile UWord32   * puw32GpioOcBaseAdd;                                  /* PORT status register for overcurrent detection */
      volatile UWord32     uw32GpioOcPin;                                       /* pin number for overcurrent detection */
      
      volatile UWord32   * puw32GpioIntBaseAdd;                                 /* PORT status register for interrupt detection */
      volatile UWord32     uw32GpioIntPin;                                      /* pin number for interrupt detection */
  
      volatile UWord32   * puw32GpioResetBaseAdd;                               /* PORT status register for reset */
      volatile UWord32     uw32GpioResetPin;                                    /* pin number for reset, driver */
      
      dspi_command_config_t  commandConfig;                                     /* SPI command SDK structure */   
};
/*------------------------------------------------------------------------*//*!
@brief      Definition of public structure data type.
*//*-------------------------------------------------------------------------*/
struct DRIVER3PH_T
{
    MC33937DSPI_T               sSpiData;           /*  hw dependent structure*/
    UWord16                     uw16Deadtime;       /* define dead time of HS and LS transistors, value in [ns]*/
    mc33937ConfigMask_t         sInterruptEnable;   /* define interrupt mask */
    mc33937Mode_t               sMode;              /* define required pre-driver mode */  
    mc33937SR0_t                sSr0;               /* status register 0 */
    mc33937SR1_t                sSr1;               /* status register 1 */
    mc33937SR2_t                sSr2;               /* status register 2 */
    UWord8                      sSr3;               /* status register 3 */
};

/******************************************************************************
| exported variables
|----------------------------------------------------------------------------*/

/******************************************************************************
| exported function prototypes
|----------------------------------------------------------------------------*/
#ifdef __cplusplus
extern "C" {
#endif

extern bool SAC_Driver3PhInit(DRIVER3PH_T * this);
extern bool SAC_Driver3PhSendCmd(DRIVER3PH_T * this, volatile UWord8 * puw8TxData, volatile UWord8 * puw8RxData);
extern bool SAC_Driver3PhReadOc(DRIVER3PH_T * this);
extern bool SAC_Driver3PhReadInt(DRIVER3PH_T * this);
extern bool SAC_Driver3PhClearRst(DRIVER3PH_T * this);
extern bool SAC_Driver3PhSetRst(DRIVER3PH_T * this);
extern bool SAC_Driver3PhClearEn(DRIVER3PH_T * this);
extern bool SAC_Driver3PhSetEn(DRIVER3PH_T * this);
extern bool SAC_Driver3PhSetDeadtime(DRIVER3PH_T * this);
extern bool SAC_Driver3PhClearFlags(DRIVER3PH_T * this);
extern bool SAC_Driver3PhGetSr0(DRIVER3PH_T * this);
extern bool SAC_Driver3PhGetSr1(DRIVER3PH_T * this);
extern bool SAC_Driver3PhGetSr2(DRIVER3PH_T * this);
extern bool SAC_Driver3PhGetSr3(DRIVER3PH_T * this);
extern bool SAC_Driver3PhConfig(DRIVER3PH_T * this);

#ifdef __cplusplus
}
#endif

#endif /* DRIVER3PH_H_ */
