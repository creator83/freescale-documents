/*******************************************************************************
*
* Copyright 2014 Freescale Semiconductor, Inc.
*
* This software is owned or controlled by Freescale Semiconductor.
* Use of this software is governed by the Freescale License
* distributed with this Material.
* See the LICENSE file distributed for more details.
* 
*
****************************************************************************//*!
*
* @file     driver3ph.c
*
* @brief    MC33937 MOSFET 3 pahse predriver SAC module
*
** @board    TWR-KV31F120M
*
******************************************************************************/

/******************************************************************************
| includes
|----------------------------------------------------------------------------*/
#include "driver3ph_mc33937.h"

/******************************************************************************
| defines and macros                                      (scope: module-local)
|----------------------------------------------------------------------------*/

/******************************************************************************
| typedefs and structures                                 (scope: module-local)
|----------------------------------------------------------------------------*/

/******************************************************************************
| global variable definitions                          (scope: module-exported)
|----------------------------------------------------------------------------*/

/******************************************************************************
| global variable definitions                             (scope: module-local)
|----------------------------------------------------------------------------*/
static bool statusPass;

/******************************************************************************
| function prototypes                                     (scope: module-local)
|----------------------------------------------------------------------------*/

/******************************************************************************
| function implementations                                (scope: module-local)
|----------------------------------------------------------------------------*/

/***************************************************************************//*!
@brief          Function initializes pointers to SPI register

@param[in,out]  this    Pointer to the current object.

@return         bool

@details
******************************************************************************/
bool SAC_Driver3PhInit(DRIVER3PH_T * this)
{
    statusPass = TRUE;
        
    this->sSpiData.puw32SpiBaseAddress      = (volatile UWord32 *)(SPI0_BASE);  /* status register */
    this->sSpiData.commandConfig.isChipSelectContinuous = false;
    this->sSpiData.commandConfig.whichCtar              = kDspiCtar0;           /* Select Ctar 0 */
    this->sSpiData.commandConfig.whichPcs               = kDspiPcs0;            /* Select PCS pin 0 */
    this->sSpiData.commandConfig.isEndOfQueue           = false;
    this->sSpiData.commandConfig.clearTransferCount     = false;
    
    /* Overcurrent PIN & PORT */
    this->sSpiData.puw32GpioOcBaseAdd      = (volatile UWord32 *)(PTC_BASE);    /* status register */
    this->sSpiData.uw32GpioOcPin           = 9;                                 /* pin number for over current, default: 9 */
    
    /* Enable PIN & PORT */
    this->sSpiData.puw32GpioEnBaseAdd      = (volatile UWord32 *)(PTA_BASE);    /* status register */
    this->sSpiData.uw32GpioEnPin           = 5;                                 /* pin number for driver enabled, default: 5 */
    
    /* Interrupt PIN & PORT */
    this->sSpiData.puw32GpioIntBaseAdd     = (volatile UWord32 *)(PTB_BASE);    /* status register */
    this->sSpiData.uw32GpioIntPin          = 18;                                /* pin number for interrupt detection, default: 18 */
    
    /* Reset PIN & PORT */
    this->sSpiData.puw32GpioResetBaseAdd   = (volatile UWord32 *)(PTC_BASE);    /* status register */
    this->sSpiData.uw32GpioResetPin        = 7;                                 /* pin number for reset, driver, default: 18 */    
    
    return(statusPass);
}

/***************************************************************************//*!
@brief          Send SPI command to MC33937

@param[in,out]  this    Pointer to the current object.
                puw8TxData Data to be send via SPI
                puw8rxData Data to be read from SPI

@return         bool

@details        
******************************************************************************/
bool SAC_Driver3PhSendCmd(DRIVER3PH_T * this, volatile UWord8 * puw8TxData, volatile UWord8 * puw8RxData)
{
    statusPass = TRUE;
     
    /* Write data to the SPI transmit data register */
    DSPI_HAL_WriteDataMastermodeBlocking((UWord32) this->sSpiData.puw32SpiBaseAddress,(&this->sSpiData.commandConfig), (UWord16) *puw8TxData);
     
    /* Read SPI read data register */
    *puw8RxData = DSPI_HAL_ReadData((UWord32) this->sSpiData.puw32SpiBaseAddress);
    
    return(statusPass);
}

/***************************************************************************//*!
@brief          Read MC33937 over current pin

@param[in,out]  this    Pointer to the current object.

@return         bool

@details        
******************************************************************************/
bool SAC_Driver3PhReadOc(DRIVER3PH_T * this)
{
    statusPass = TRUE;
    
    /* Read overcurrent pin */
    statusPass = GPIO_HAL_ReadPinInput((UWord32) this->sSpiData.puw32GpioOcBaseAdd, this->sSpiData.uw32GpioOcPin); 
    
    return(statusPass);
}

/***************************************************************************//*!
@brief          Read MC33937 interrupt  pin

@param[in,out]  this    Pointer to the current object.

@return         bool

@details        
******************************************************************************/
bool SAC_Driver3PhReadInt(DRIVER3PH_T * this)
{
    statusPass = TRUE;
    
    /* Read interrupt pin */
    statusPass = GPIO_HAL_ReadPinInput((UWord32) this->sSpiData.puw32GpioIntBaseAdd, this->sSpiData.uw32GpioIntPin); 
    
    return(statusPass);
}

/***************************************************************************//*!
@brief          Clear MC33937 reset  pin

@param[in,out]  this    Pointer to the current object.

@return         bool

@details        
******************************************************************************/
bool SAC_Driver3PhClearRst(DRIVER3PH_T * this)
{
    statusPass = TRUE;
    
    /* Clear pin output for 3PPA driver reset */
    GPIO_HAL_ClearPinOutput((UWord32) this->sSpiData.puw32GpioResetBaseAdd, this->sSpiData.uw32GpioResetPin);
    
    return(statusPass);
}

/***************************************************************************//*!
@brief          Set MC33937 reset  pin

@param[in,out]  this    Pointer to the current object.

@return         bool

@details        
******************************************************************************/
bool SAC_Driver3PhSetRst(DRIVER3PH_T * this)
{
    statusPass = TRUE;
    
    /* Set pin output for 3PPA driver reset */
    GPIO_HAL_SetPinOutput((UWord32) this->sSpiData.puw32GpioResetBaseAdd, this->sSpiData.uw32GpioResetPin);
    
    return(statusPass);
}

/***************************************************************************//*!
@brief          Clear MC33937 enable  pin

@param[in,out]  this    Pointer to the current object.

@return         bool

@details        
******************************************************************************/
bool SAC_Driver3PhClearEn(DRIVER3PH_T * this)
{
    statusPass = TRUE;
    
    /* Clear pin output for 3PPA driver enable */
    GPIO_HAL_ClearPinOutput((UWord32) this->sSpiData.puw32GpioEnBaseAdd, this->sSpiData.uw32GpioEnPin);
    
    return(statusPass);
}

/***************************************************************************//*!
@brief          Set MC33937 reset  pin

@param[in,out]  this    Pointer to the current object.

@return         bool

@details        
******************************************************************************/
bool SAC_Driver3PhSetEn(DRIVER3PH_T * this)
{
    statusPass = TRUE;
    
    /* Set pin output for 3PPA driver enable */
    GPIO_HAL_SetPinOutput((UWord32) this->sSpiData.puw32GpioEnBaseAdd, this->sSpiData.uw32GpioEnPin);
    
    return(statusPass);
}

/***************************************************************************//*!
@brief          Set MC33937 deadtime

@param[in,out]  this    Pointer to the current object.

@return         bool

@details        
******************************************************************************/
bool SAC_Driver3PhSetDeadtime(DRIVER3PH_T * this)
{
    UWord8  uw8TxData, uw8RxData;

    statusPass = TRUE;
    
    /* zero deadtime calibration */
    /* Send ZERODEADTIME command for dead time configuration with zero calibration */
    uw8TxData   = 0x80;
    statusPass &= SAC_Driver3PhSendCmd(this, &uw8TxData, &uw8RxData);
   
    
    return(statusPass);
}

/***************************************************************************//*!
@brief          Clear MC33937 fault registers

@param[in,out]  this    Pointer to the current object.

@return         bool

@details        
******************************************************************************/
bool SAC_Driver3PhClearFlags(DRIVER3PH_T * this)
{
    UWord8  uw8TxData, uw8RxData;
    
    statusPass = TRUE;
    
    /* CLINT0_COMMAND = 0x6F */
    /* CLINT1_COMMAND = 0x7F */
    uw8TxData   = 0x6F;
    statusPass &= SAC_Driver3PhSendCmd(this, &uw8TxData, &uw8RxData);
    uw8TxData   = 0x7F;
    statusPass &= SAC_Driver3PhSendCmd(this, &uw8TxData, &uw8RxData);
    
    return(statusPass);
}

/***************************************************************************//*!
@brief          Reads MC33937 status 0 register

@param[in,out]  this    Pointer to the current object.

@return         bool

@details        
******************************************************************************/
bool SAC_Driver3PhGetSr0(DRIVER3PH_T * this)
{
    UWord8  uw8TxData;
    
    statusPass = TRUE;
    
    /* Status Register 0 reading = 0x00 */
    uw8TxData   = 0x00;
    statusPass &= SAC_Driver3PhSendCmd(this, &uw8TxData, &this->sSr0.R);
    /* Status Register 0 write to read SR0 result */
    uw8TxData   = 0x00;
    statusPass &= SAC_Driver3PhSendCmd(this, &uw8TxData, &this->sSr0.R);
    
    return(statusPass);
}

/***************************************************************************//*!
@brief          Reads MC33937 status 1 register

@param[in,out]  this    Pointer to the current object.

@return         bool

@details        
******************************************************************************/
bool SAC_Driver3PhGetSr1(DRIVER3PH_T * this)
{
    UWord8  uw8TxData;
    
    statusPass = TRUE;
    
    /* Status Register 1 reading = 0x01 */
    uw8TxData   = 0x01;
    statusPass &= SAC_Driver3PhSendCmd(this, &uw8TxData, &this->sSr0.R);
    /* Status Register 0 write to read SR1 result */
    uw8TxData   = 0x00;
    statusPass &= SAC_Driver3PhSendCmd(this, &uw8TxData, &this->sSr1.R);
    
    return(statusPass);
}

/***************************************************************************//*!
@brief          Reads MC33937 status 2 register

@param[in,out]  this    Pointer to the current object.

@return         bool

@details        
******************************************************************************/
bool SAC_Driver3PhGetSr2(DRIVER3PH_T * this)
{
    UWord8  uw8TxData;
    
    statusPass = TRUE;
    
    /* Status Register 2 reading = 0x02 */
    uw8TxData   = 0x02;
    statusPass &= SAC_Driver3PhSendCmd(this, &uw8TxData, &this->sSr0.R);
    /* Status Register 0 write to read SR2 result */
    uw8TxData   = 0x00;
    statusPass &= SAC_Driver3PhSendCmd(this, &uw8TxData, &this->sSr2.R);
    
    return(statusPass);
}

/***************************************************************************//*!
@brief          Reads MC33937 status 3 register

@param[in,out]  this    Pointer to the current object.

@return         bool

@details        
******************************************************************************/
bool SAC_Driver3PhGetSr3(DRIVER3PH_T * this)
{
    UWord8  uw8TxData;
    
    statusPass = TRUE;
    
    /* Status Register 3 reading = 0x03 */
    uw8TxData   = 0x03;
    statusPass &= SAC_Driver3PhSendCmd(this, &uw8TxData, &this->sSr0.R);
    /* Status Register 0 write to read SR3 result */
    uw8TxData   = 0x00;
    statusPass &= SAC_Driver3PhSendCmd(this, &uw8TxData, &this->sSr3);
    
    return(statusPass);
}

/***************************************************************************//*!
@brief          Configure MC33937 registers

@param[in,out]  this    Pointer to the current object.

@return         bool

@details        
******************************************************************************/
bool SAC_Driver3PhConfig(DRIVER3PH_T * this)
{
    UWord8  uw8TxData, uw8RxData;
    register UWord32 uw32loop_cnt;
    
    statusPass = TRUE;
    
    /* EN1 and EN2 are still low */
    statusPass &= SAC_Driver3PhClearEn(this);

    /* Set RST high */
    statusPass &= SAC_Driver3PhSetRst(this);
    
    /* required start-up delay between the RST going up and initialization routine */
    /* at 75 MHz the delay will be 50 ms , at lower CPU clocks will be more as 2 ms */
    for (uw32loop_cnt = 0 ; uw32loop_cnt < 1500000; uw32loop_cnt++)
    {
      asm ("nop");
    }
    
    /* Clear all faults */
    statusPass &= SAC_Driver3PhClearFlags(this);

    /* Initialize MASK register 0 */
    uw8TxData   = 0x20|(UWord8)(this->sInterruptEnable.R);
    statusPass &= SAC_Driver3PhSendCmd(this, &uw8TxData, &uw8RxData);

    /* Initialize MASK register 1 */
    uw8TxData   = 0x30|(UWord8)(this->sInterruptEnable.R>>4);
    statusPass &= SAC_Driver3PhSendCmd(this, &uw8TxData, &uw8RxData);
    
    /* Initialize MODE_COMMAND register  */
    uw8TxData   = 0x40|(UWord8)(this->sMode.R);
    statusPass &= SAC_Driver3PhSendCmd(this, &uw8TxData, &uw8RxData);
    
    /* set dead time, ONLY ZERO DT AVAILABLE - TBD */
    statusPass &= SAC_Driver3PhSetDeadtime(this);

    /* Clear all faults */
    statusPass &= SAC_Driver3PhClearFlags(this);
    
    return(statusPass);
}
/* End of file */
