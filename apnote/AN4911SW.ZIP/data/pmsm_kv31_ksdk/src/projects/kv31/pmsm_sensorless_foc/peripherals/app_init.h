/*******************************************************************************
*
* Copyright 2014 Freescale Semiconductor, Inc.
*
* This software is owned or controlled by Freescale Semiconductor.
* Use of this software is governed by the Freescale License
* distributed with this Material.
* See the LICENSE file distributed for more details.
* 
*
****************************************************************************//*!
*
* @file         app_init.c
*
* @brief        This file contains the init functions for some peripherals.
* 
*******************************************************************************/
#ifndef __APP_INIT_H
#define __APP_INIT_H

/* SDK includes */
#include "fsl_device_registers.h"
#include "fsl_port_hal.h"
#include "fsl_gpio_hal.h"
#include "fsl_clock_manager.h"
#include "fsl_interrupt_manager.h"

/* Projects includes */
#include "board_twr-kv31f120m.h"
#include "peripherals_init.h"
#include "app_init.h"
#include "m1_state_machine.h"
#include "pmsm_appconfig.h"

#include "freemaster.h"
#include "MKV31F51212.h"
#include "SWLIBS_Typedefs.h"
/***************************** Prototypes **********************************/

void InitPorts(void);
/***************************************************************************
* InitPorts
* --------------------------------------------------------------------------
* Initialization of the MCU ports
****************************************************************************/

void InitFreemaster(void);
/***************************************************************************
* InitFreemaster
* --------------------------------------------------------------------------
* Initialization of the Freemaster
****************************************************************************/

#endif /* __APP_INIT_H*/

/********************************************************************/
