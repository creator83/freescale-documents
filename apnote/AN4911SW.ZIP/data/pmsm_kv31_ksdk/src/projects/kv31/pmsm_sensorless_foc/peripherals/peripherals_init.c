/*******************************************************************************
*
* Copyright 2014 Freescale Semiconductor, Inc.
*
* This software is owned or controlled by Freescale Semiconductor.
* Use of this software is governed by the Freescale License
* distributed with this Material.
* See the LICENSE file distributed for more details.
* 
*
****************************************************************************//*!
*
* @file         peripherals_init.c
*
* @brief        This file contains the init functions for some peripherals.
* 
*******************************************************************************/

#include "peripherals_init.h"
/******************************************************************************
* global variables
******************************************************************************/
uint32_t                baudRate;
uint32_t                calculatedDelay;
/***************************************************************************
* InitUART as HAL_SDK
* --------------------------------------------------------------------------
* Initialization of the UART module
****************************************************************************/
#pragma optimize = none
void InitUART(void)
{
    /* Enable UART0 Clock in SIM module */
    SIM_HAL_EnableUartClock(SIM_BASE, 0); 
   
    /* Initialise UART Module */
    UART_HAL_Init(UART0_BASE);
    
    /* Set UART BaudRate */
    UART_HAL_SetBaudRate(UART0_BASE, CLOCK_SYS_GetUartFreq(0), FMSTR_BAUDRATE); 
    
    /* Enable UART Transmitter - TX */
    UART_HAL_EnableTransmitter(UART0_BASE);
  
    /* Enable UART Receiver - RX */
    UART_HAL_EnableReceiver(UART0_BASE);
}
/***************************************************************************
* InitSPI as HAL_SDK
* --------------------------------------------------------------------------
* Initialization of the SPI module
****************************************************************************/
#pragma optimize = none
void InitSPI0(void)
{
    /* HAL SPI module structure */
    dspi_data_format_config_t dataFormat;                                          
    dataFormat.bitsPerFrame = 8;                                              /* 8bits(1 byte) pes SPI frame */
    dataFormat.clkPolarity = kDspiClockPolarity_ActiveLow;                    /* SPI clock polarity */
    dataFormat.clkPhase = kDspiClockPhase_FirstEdge;                          /* Clock phase */
    dataFormat.direction = kDspiMsbFirst;                                     /* MSB or LSB bit first */

    /* Enable SPI Clock in SIM module */
    SIM_HAL_EnableSpiClock(SIM_BASE, 0);                                        /* Enable the clock for SPI0 */  
  
    /* Initialize SPI module */
    DSPI_HAL_Init(SPI0_BASE);                                                   
  
    /* Halt before SPI settings */
    DSPI_HAL_Disable(SPI0_BASE);                                                
    
    /* Enable module */
    DSPI_HAL_Enable(SPI0_BASE);                                                 
    
    /* Set DSPI as Master Mode */
    DSPI_HAL_SetMasterSlaveMode(SPI0_BASE, kDspiMaster);                        
    
    /* Select PCS pin and polarity select */
    DSPI_HAL_SetPcsPolarityMode(SPI0_BASE, kDspiPcs0, kDspiPcs_ActiveLow);       
   
    /* Enable or disable SPI TX & RX FIFO */ 
    DSPI_HAL_SetFifoCmd(SPI0_BASE, false, false);                               
    
    /* Configure the data format for a particular CTAR */
    DSPI_HAL_SetDataFormat(SPI0_BASE, kDspiCtar0, &dataFormat);  
    
    /* bitsPerSec = 518600, sourceClockInHz = 60000000 */
    DSPI_HAL_SetBaudRate(SPI0_BASE, kDspiCtar0, 518600, 600000); 
      
    /* Configures the delay prescaler and scaler for a particular CTAR */
    DSPI_HAL_SetDelay(SPI0_BASE, kDspiCtar0, 0, 1, kDspiPcsToSck);              /* PCS to SCK Delay Prescaler = 3, PCS to SCK Delay Scaler = 4 */ 
    DSPI_HAL_SetDelay(SPI0_BASE, kDspiCtar0, 2, 3, kDspiLastSckToPcs);          /* After SCK Delay Prescaler = 5, After SCK Delay Scaler */    
    DSPI_HAL_SetDelay(SPI0_BASE, kDspiCtar0, 3, 1, kDspiAfterTransfer);         /* Delay after Transfer Prescaler = 7, Delay After Transfer Scaler */
    
    /* Disable SPI transfer */
    DSPI_HAL_StopTransfer(SPI0_BASE);                                           
    
    /* Enable/Start SPI transfer */
    DSPI_HAL_StartTransfer(SPI0_BASE);                                          
    
    PORT_HAL_SetMuxMode(PORTE_BASE, 16, kPortMuxAlt2);                          /* SPI0 CS,  PTE16,TWR elevator pin B46 */
    PORT_HAL_SetMuxMode(PORTE_BASE, 17, kPortMuxAlt2);                          /* SPI0 SCLK,PTE17,TWR elevator pin B48 */
    PORT_HAL_SetMuxMode(PORTE_BASE, 18, kPortMuxAlt2);                          /* SPI0 MOSI,PTE18,TWR elevator pin B45 */
    PORT_HAL_SetMuxMode(PORTE_BASE, 19, kPortMuxAlt2);                          /* SPI0 MISO,PTE19,TWR elevator pin B44 */      
} 
/***************************************************************************
* InitFTM0
* --------------------------------------------------------------------------
* Initialization of the FTM0 module for center-aligned PWM generation
****************************************************************************/
#pragma optimize = none
void InitFTM0(void)
{
    /* Enable FTM0 Clock in SIM module */
    SIM_HAL_EnableFtmClock(SIM_BASE, 0);
    
    /* Disable all channels outputs using the OUTPUT MASK feature.
    However, the output pins are still driven as GPIO since the
    channel mode is set to FTM channel disabled after RESET */
    FTM_HAL_SetChnOutputMask(FTM0_BASE, HW_CHAN0, 1);
    FTM_HAL_SetChnOutputMask(FTM0_BASE, HW_CHAN1, 1);
    FTM_HAL_SetChnOutputMask(FTM0_BASE, HW_CHAN2, 1);
    FTM_HAL_SetChnOutputMask(FTM0_BASE, HW_CHAN3, 1);
    FTM_HAL_SetChnOutputMask(FTM0_BASE, HW_CHAN4, 1);
    FTM_HAL_SetChnOutputMask(FTM0_BASE, HW_CHAN5, 1);
    
    /* Disable Write Protection: true: Write-protection is enabled, false: Write-protection is disabled */
    FTM_HAL_SetWriteProtectionCmd(FTM0_BASE, false);
    
    /* Sets the BDM mode to 3 */ 
    FTM_HAL_SetBdmMode(FTM0_BASE, 3);

    /* Enable FTM0 ccounter */
    FTM_HAL_Enable(FTM0_BASE, true);
    
    /* Set FTM0 fault control mode /4/ : Fault control is enabled for all channels, and the selected mode is the automatic fault clearing */
    FTM_HAL_SetFaultControlMode(FTM0_BASE, 3);
    
    /* Set MOD value to FTM0 */
    FTM_HAL_SetMod(FTM0_BASE, (uint16_t)(MODULO / 2 - 1));
                   
    /* Set counter initial value */
    FTM_HAL_SetCounterInitVal(FTM0_BASE, (uint16_t)(-MODULO / 2));
       
    /* Enable FTM to update counter at maximum loading points */
    FTM_HAL_SetMaxLoadingCmd(FTM0_BASE, true);               
    
    /* FTM peripheral combine module / Base_Addres, channel number, true/ */
    FTM_HAL_SetDualChnFaultCmd(FTM0_BASE, HW_CHAN0, true);                      /* FTM peripheral timer channel pair fault control */        
    FTM_HAL_SetDualChnPwmSyncCmd(FTM0_BASE, HW_CHAN0, true);                    /* FTM peripheral timer channel pair counter PWM sync */       
    FTM_HAL_SetDualChnDeadtimeCmd(FTM0_BASE, HW_CHAN0, true);                   /* FTM peripheral timer channel pair deadtime insertion */       
    FTM_HAL_SetDualChnCompCmd(FTM0_BASE, HW_CHAN0, true);                       /* FTM peripheral timer channel pair output complement mode  */             
    FTM_HAL_SetDualChnCombineCmd(FTM0_BASE, HW_CHAN0, true);                    /* FTM peripheral timer channel pair output combine mode    */       
    
    FTM_HAL_SetDualChnFaultCmd(FTM0_BASE, HW_CHAN2, true);                      /* FTM peripheral timer channel pair fault control */               
    FTM_HAL_SetDualChnPwmSyncCmd(FTM0_BASE, HW_CHAN2, true);                    /* FTM peripheral timer channel pair counter PWM sync */       
    FTM_HAL_SetDualChnDeadtimeCmd(FTM0_BASE, HW_CHAN2, true);                   /* FTM peripheral timer channel pair deadtime insertion */       
    FTM_HAL_SetDualChnCompCmd(FTM0_BASE, HW_CHAN2, true);                       /* FTM peripheral timer channel pair output complement mode */              
    FTM_HAL_SetDualChnCombineCmd(FTM0_BASE, HW_CHAN2, true);                    /* FTM peripheral timer channel pair output combine mode */       
    
    FTM_HAL_SetDualChnFaultCmd(FTM0_BASE, HW_CHAN4, true);                      /* FTM peripheral timer channel pair fault control */               
    FTM_HAL_SetDualChnPwmSyncCmd(FTM0_BASE, HW_CHAN4, true);                    /* FTM peripheral timer channel pair counter PWM sync */       
    FTM_HAL_SetDualChnDeadtimeCmd(FTM0_BASE, HW_CHAN4, true);                   /* FTM peripheral timer channel pair deadtime insertion */       
    FTM_HAL_SetDualChnCompCmd(FTM0_BASE, HW_CHAN4, true);                       /* FTM peripheral timer channel pair output complement mode */              
    FTM_HAL_SetDualChnCombineCmd(FTM0_BASE, HW_CHAN4, true);                    /* FTM peripheral timer channel pair output combine mode */       
   
   
    /* FTM peripheral timer channel output polarity / Base_Addres, channel number, 0-1/  */
    FTM_HAL_SetChnOutputPolarity(FTM0_BASE, 0, 1);                              /* Invert channel 0 polarity */       
    FTM_HAL_SetChnOutputPolarity(FTM0_BASE, 2, 1);                              /* Invert channel 2 polarity */       
    FTM_HAL_SetChnOutputPolarity(FTM0_BASE, 4, 1);                              /* Invert channel 4 polarity */       
   
    /* Sets the FTM deadtime value */
    FTM_HAL_SetDeadtimeCount(FTM0_BASE, 60);

    /* Sets the FTM peripheral timer channel counter value / Base_Addres, channel number, value/ */
    FTM_HAL_SetChnCountVal(FTM0_BASE, 0, (uint16_t)(-MODULO / 4));                        /* Initial setting of value registers to 50 % of duty cycle */        
    FTM_HAL_SetChnCountVal(FTM0_BASE, 1, (uint16_t)(MODULO / 4));                         /* Initial setting of value registers to 50 % of duty cycle */        
    FTM_HAL_SetChnCountVal(FTM0_BASE, 2, (uint16_t)(-MODULO / 4));                        /* Initial setting of value registers to 50 % of duty cycle */        
    FTM_HAL_SetChnCountVal(FTM0_BASE, 3, (uint16_t)(MODULO / 4));                         /* Initial setting of value registers to 50 % of duty cycle */        
    FTM_HAL_SetChnCountVal(FTM0_BASE, 4, (uint16_t)(-MODULO / 4));                        /* Initial setting of value registers to 50 % of duty cycle */        
    FTM_HAL_SetChnCountVal(FTM0_BASE, 5, (uint16_t)(MODULO / 4));                         /* Initial setting of value registers to 50 % of duty cycle */        
    
    /* Sets the FTM peripheral timer channel edge level / Base_Addres, channel number, level/ */
    FTM_HAL_SetChnEdgeLevel(FTM0_BASE, 0, 10);                          
    FTM_HAL_SetChnEdgeLevel(FTM0_BASE, 1, 10);
    FTM_HAL_SetChnEdgeLevel(FTM0_BASE, 2, 10);
    FTM_HAL_SetChnEdgeLevel(FTM0_BASE, 3, 10);
    FTM_HAL_SetChnEdgeLevel(FTM0_BASE, 4, 10);
    FTM_HAL_SetChnEdgeLevel(FTM0_BASE, 5, 10);

    /* Enables or disables the loading of MOD, CNTIN and CV with values of their write buffer */
    FTM_HAL_SetPwmLoadCmd(FTM0_BASE, true);
    
    /* Enable inittrig signal for starting of the PDB counter */
    FTM_HAL_SetInitTriggerCmd(FTM0_BASE, true);
    
    /* Initializes the channels output */
    FTM_HAL_SetInitChnOutputCmd(FTM0_BASE, true);
    
    /* Enable FTM clock source */
    FTM_HAL_SetClockSource(FTM0_BASE, kClock_source_FTM_SystemClk);
    
    /* Set PORT MUX to FTM output pins */
    PORT_HAL_SetMuxMode(PORTC_BASE, 1, kPortMuxAlt4);                           /* FTM0 CH0,PTC1,TWR Elevato pin A40 */       
    PORT_HAL_SetMuxMode(PORTC_BASE, 2, kPortMuxAlt4);                           /* FTM0 CH1,PTC2,TWR Elevato pin A39 */       
    PORT_HAL_SetMuxMode(PORTC_BASE, 5, kPortMuxAlt7);                           /* FTM0 CH2,PTC5,TWR Elevato pin A38 */       
    PORT_HAL_SetMuxMode(PORTC_BASE, 4, kPortMuxAlt4);                           /* FTM0 CH3,PTC4,TWR Elevato pin A37 */       
    PORT_HAL_SetMuxMode(PORTD_BASE, 4, kPortMuxAlt4);                           /* FTM0 CH4,PTD4,TWR Elevato pin B40 */       
    PORT_HAL_SetMuxMode(PORTD_BASE, 5, kPortMuxAlt4);                           /* FTM0 CH5,PTD5,TWR Elevato pin B39 */       
} 
/***************************************************************************
* InitPDB
* --------------------------------------------------------------------------
* Initialization of the PDB  for current and voltage sensing
* 
****************************************************************************/
#pragma optimize = none
void InitPDB(void)
{
    /* Enable PDB Clock in SIM module */
    SIM_HAL_EnablePdbClock(SIM_BASE, 0);       
    
    /* Sets the modulus value for the PDB module */
    PDB_HAL_SetModulusValue(PDB0_BASE, MODULO);
    
    /* PDB triggers for ADC0 module */
    PDB_HAL_SetPreTriggerDelayCount(PDB0_BASE, 0, 1, (uint32_t)(MODULO / 4));   /* Pretrigger delay ( generate trigger B for ADC - for voltage) */
    PDB_HAL_SetPreTriggerDelayCount(PDB0_BASE, 0, 0, (0));                      /* Pretrigger delay ( generate trigger B for ADC - for currents) */
    PDB_HAL_SetPreTriggerDelayCount(PDB0_BASE, 1, 0, (0));                      /* Pretrigger delay ( generate trigger A for ADC - for currents) */
   
    /* Sets the trigger source mode for the PDB module */
    PDB_HAL_SetTriggerSrcMode(PDB0_BASE, kPdbTrigger8);
   
    /* Sets the prescaler divider from the peripheral bus clock for the PDB */
    PDB_HAL_SetPreDivMode(PDB0_BASE, kPdbClkPreDivBy2);
   
    /* Switches to enable the PDB sequence error interrupt */
    PDB_HAL_SetSeqErrIntCmd(PDB0_BASE, true);

    /* Switches to enable the PDB interrupt*/
    PDB_HAL_SetIntCmd(PDB0_BASE, true);
    
    /* Switches on to enable the PDB module */
    PDB_HAL_Enable(PDB0_BASE);
    
    /* Loads the delay registers value for the PDB module*/
    PDB_HAL_SetLoadRegsCmd(PDB0_BASE);
    
    /* Enable PDB channels to trigger ADC coversion for Channel "n" and PreChannel "m" */
    PDB_HAL_SetPreTriggerCmd(PDB0_BASE, 0, 0, true);
    PDB_HAL_SetPreTriggerOutputCmd(PDB0_BASE, 0, 0, true);
    
    /* Enable PDB channels to trigger ADC coversion for Channel "n" and PreChannel "m" */
    PDB_HAL_SetPreTriggerCmd(PDB0_BASE, 0, 1, true);
    PDB_HAL_SetPreTriggerOutputCmd(PDB0_BASE, 0, 1, true);
    
    /* Enable PDB channels to trigger ADC coversion for Channel "n" and PreChannel "m" */
    PDB_HAL_SetPreTriggerCmd(PDB0_BASE, 1, 0, true);
    PDB_HAL_SetPreTriggerOutputCmd(PDB0_BASE, 1, 0, true);
    
}
/***************************************************************************
* InitADC
* --------------------------------------------------------------------------
* Initialization of the A/D converter for current and voltage sensing
* 
****************************************************************************/
#pragma optimize = none
void InitADC(void)
{
    /* Enable ADC Clock in SIM module */
    SIM_HAL_EnableAdcClock(SIM_BASE, 0);       
    SIM_HAL_EnableAdcClock(SIM_BASE, 1);       
  
    //------- ADC self calibration procedure START -----
    /* Settings up ADC module 0 */
    /* Setting the clock to 3.125 MHz (ADIV and ADICLK bits) and single-ended 12-bit conversion (MODE bits);*/
    ADC_HAL_SetClkDividerMode(ADC0_BASE, kAdcClkDividerInputOf8);               /* Selects the clock divider mode for the ADC module */
    ADC_HAL_SetResolutionMode(ADC0_BASE, kAdcResolutionBitOf12or13);            /* Selects the conversion resolution mode for ADC module */
    ADC_HAL_SetClkSrcMode(ADC0_BASE, kAdcClkSrcOfBusClk);                       /* Selects the input clock source for the ADC module */
    
    /* Settings up ADC module 1 */
    /* Setting the clock to 3.125 MHz (ADIV and ADICLK bits) and single-ended 12-bit conversion (MODE bits); */
    ADC_HAL_SetClkDividerMode(ADC1_BASE, kAdcClkDividerInputOf8);               /* Selects the clock divider mode for the ADC module */
    ADC_HAL_SetResolutionMode(ADC1_BASE, kAdcResolutionBitOf12or13);            /* Selects the conversion resolution mode for ADC module */
    ADC_HAL_SetClkSrcMode(ADC1_BASE, kAdcClkSrcOfBusClk);                       /* Selects the input clock source for the ADC module */
   
    /* Settings up ADC module 0 */
    /* HW averaging enabled, 32 samples averaged, continuous conversion must be enabled */
    ADC_HAL_SetHwAverageCmd(ADC0_BASE, true);                                   /* Switches to enable the hardware average for the ADC module */
    ADC_HAL_SetHwAverageMode(ADC0_BASE, kAdcHwAverageCountOf32);                /* Selects the hardware average mode for the ADC module */       
    ADC_HAL_SetContinuousConvCmd(ADC0_BASE, true);                              /* Switches to enable the continuous conversion mode for the ADC module */
    
    /* Settings up ADC module 1 */
    /* HW averaging enabled, 32 samples averaged, continuous conversion must be enabled */
    ADC_HAL_SetHwAverageCmd(ADC1_BASE, true);                                   /* Switches to enable the hardware average for the ADC module */
    ADC_HAL_SetHwAverageMode(ADC1_BASE, kAdcHwAverageCountOf32);                /* Selects the hardware average mode for the ADC module */       
    ADC_HAL_SetContinuousConvCmd(ADC1_BASE, true);                              /* Switches to enable the continuous conversion mode for the ADC module */
        
    
    /* Starting calibration of ADC0 */
    ADC_HAL_SetAutoCalibrationCmd(ADC0_BASE, true);
    while(!(ADC_HAL_GetChnConvCompletedCmd(ADC0_BASE, 0))){}                    /* Wait until the calibration completes */
    if(ADC_HAL_GetAutoCalibrationFailedCmd(ADC0_BASE))
    {
      asm ("nop");                                                              /* Adc calibration failed, place breakpoint here for debug */
    }
          
    uint16_t calib = 0;       
    calib = ADC_HAL_GetAutoPlusSideGainValue(ADC0_BASE);                        /* Get the values of CLP0 - CLP4 and CLPS internally */        
    ADC_HAL_SetPlusSideGainValue(ADC0_BASE, calib);                             /* Sets the plus side gain calibration value  for the ADC module */
    calib = ADC_HAL_GetAutoMinusSideGainValue(ADC0_BASE);                       /* Get the values of CLM0 - CLM4 and CLMS internally */
    ADC_HAL_SetMinusSideGainValue(ADC0_BASE, calib);                            /* Sets the minus side gain calibration value  for the ADC module */

      
    /* Starting calibration of ADC1 */
    ADC_HAL_SetAutoCalibrationCmd(ADC1_BASE, true);
    while(!(ADC_HAL_GetChnConvCompletedCmd(ADC1_BASE, 0))){}                    /* Wait until the calibration completes */
    if(ADC_HAL_GetAutoCalibrationFailedCmd(ADC1_BASE))
    {
        asm ("nop");                                                              /* Adc calibration failed, place breakpoint here for debug */
    }
             
    calib = ADC_HAL_GetAutoPlusSideGainValue(ADC1_BASE);                        /* Get the values of CLP0 - CLP4 and CLPS internally */        
    ADC_HAL_SetPlusSideGainValue(ADC1_BASE, calib);                             /* Sets the plus side gain calibration value  for the ADC module */ 
    calib = ADC_HAL_GetAutoMinusSideGainValue(ADC1_BASE);                       /* Get the values of CLM0 - CLM4 and CLMS internally */
    ADC_HAL_SetMinusSideGainValue(ADC1_BASE, calib);                            /* Sets the minus side gain calibration value  for the ADC module */
    //------- ADC self calibration procedure END -----    
    
    /* Settings up ADC module 0 */
    /* Setting the prescaller (bus_clock/4) = 50/4 = 12.5MHz and resoulution to 12 bits */
    ADC_HAL_SetClkDividerMode(ADC0_BASE, kAdcClkDividerInputOf4);               /* Selects the clock divider mode for the ADC module */
    ADC_HAL_SetResolutionMode(ADC0_BASE, kAdcResolutionBitOf12or13);            /* Selects the conversion resolution mode for ADC module */
    
    /* Settings up ADC module 1 */ 
    /* Setting the prescaller (bus_clock/4) = 50/4 = 12.5MHz and resoulution to 12 bits */
    ADC_HAL_SetClkDividerMode(ADC1_BASE, kAdcClkDividerInputOf4);               /* Selects the clock divider mode for the ADC module */
    ADC_HAL_SetResolutionMode(ADC1_BASE, kAdcResolutionBitOf12or13);            /* Selects the conversion resolution mode for ADC module */
    
    /* Hardware averaging and continuous conversion disabled */
    ADC_HAL_SetHwAverageMode(ADC0_BASE, false);                                 /* Switches to disable the hardware average for the ADC module */
    ADC_HAL_SetHwAverageCmd(ADC0_BASE, false);
    ADC_HAL_SetContinuousConvCmd(ADC0_BASE, false);                             /* Switches to disable the continuous conversion mode for the ADC module */
            
    /* Hardware averaging and continuous conversion disabled */
    ADC_HAL_SetHwAverageMode(ADC1_BASE, false);                                 /* Switches to disable the hardware average for the ADC module */
    ADC_HAL_SetHwAverageCmd(ADC1_BASE, false);
    ADC_HAL_SetContinuousConvCmd(ADC1_BASE, false);                             /* Switches to disable the continuous conversion mode for the ADC module */
    
    /* Hardware trigger enabled for ADC0 and ADC1 */
    ADC_HAL_SetHwTriggerCmd(ADC0_BASE, true);                                   /* Switches to enable the hardware trigger mode for the ADC module */
    ADC_HAL_SetHwTriggerCmd(ADC1_BASE, true);                                   /* Switches to enable the hardware trigger mode for the ADC module */
    
    /* Set the trigger of the ADC to FTM InitTrig (for calibration purposes only)*/
    SIM_HAL_SetAdcAlternativeTriggerCmd(SIM_BASE, 0, false);                    /* Sets the ADCx alternate trigger enable setting */       
    SIM_HAL_SetAdcPreTriggerMode(SIM_BASE, 0, kSimAdcPretrgselA);               /* Sets the ADCx trigger select setting */                        
    
    SIM_HAL_SetAdcAlternativeTriggerCmd(SIM_BASE, 1, false);                    /* Sets the ADCx alternate trigger enable setting */       
    SIM_HAL_SetAdcPreTriggerMode(SIM_BASE, 0, kSimAdcPretrgselA);               /* Sets the ADCx trigger select setting */                        
     
    /* Configures the conversion channel for the ADC module */
    /* Channel base address, chnGroup((A,0);(B,1)), interruptEnable, differentEnable, channel Number */
    ADC_HAL_ConfigChn(ADC0_BASE, 0, false, false, 1);             
    ADC_HAL_ConfigChn(ADC0_BASE, 1, false, false, 13);	 
    
    ADC_HAL_ConfigChn(ADC1_BASE, 0, true, false, 0);                 
    ADC_HAL_ConfigChn(ADC1_BASE, 1, false, false, 2);

}
/*
 *######################################################################
 *                           End of File
 *######################################################################
*/
