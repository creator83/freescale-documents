/*******************************************************************************
*
* Copyright 2014 Freescale Semiconductor, Inc.

*
* This software is owned or controlled by Freescale Semiconductor.
* Use of this software is governed by the Freescale License
* distributed with this Material.
* See the LICENSE file distributed for more details.
* 
*
****************************************************************************//*!
*
* @file     main.h
*
* @brief    PMSM sensorless on KV31 header file
*
******************************************************************************/

#ifndef __MAIN_H
#define __MAIN_H 1

/******************************************************************************
* Includes
******************************************************************************/


/****************************** Types **************************************/


/****************************** Macros **************************************/
#define M1_DISABLE_PWM_OUTPUT() FTM0_OUTMASK = FTM_OUTMASK_CH5OM_MASK | FTM_OUTMASK_CH4OM_MASK  \
                                             | FTM_OUTMASK_CH3OM_MASK | FTM_OUTMASK_CH2OM_MASK  \
                                             | FTM_OUTMASK_CH1OM_MASK | FTM_OUTMASK_CH0OM_MASK

#define M1_ENABLE_PWM_OUTPUT() FTM0_OUTMASK  = 0

#define MODULO 6000             //=busClock/RequiredFrekq for center aligned ( value of 3000 coresponds to 10kHz PWM & 60MHz Bus Cloc)

/************************** Local function prototypes ************************/
/* Application Setup */
#define TSS_USE_DCTRACKER       0
                                                  
/* Push button pressing speed increment [rpm]*/
#define SPEED_INC_BTN           500
#define SPEED_MAX_BTN           3500                                                  

/*******************************************************
*******          Function Prototypes           *********
*******************************************************/
#ifdef __cplusplus
extern "C" {
#endif
  

void ADC_ISR_Handler(void);
/***************************************************************************
* ADC_ISR_Handler
* --------------------------------------------------------------------------
* Handling ADC interrupt 
****************************************************************************/

void PDB_Error_ISR_Handler(void);
/***************************************************************************
* PDB_Error_ISR_Handler
* --------------------------------------------------------------------------
* Handling PDB interrupt 
****************************************************************************/

void PORT_ISR_Handler(void);
/***************************************************************************
* PORT_ISR_Handler
* --------------------------------------------------------------------------
* Handling PORT interrupt 
****************************************************************************/

#ifdef __cplusplus
}
#endif

/********************************************************************/
#endif // (_main_h)