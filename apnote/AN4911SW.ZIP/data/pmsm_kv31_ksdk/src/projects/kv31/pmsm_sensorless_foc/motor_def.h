/*******************************************************************************
*
* Copyright 2014 Freescale Semiconductor, Inc.

*
* This software is owned or controlled by Freescale Semiconductor.
* Use of this software is governed by the Freescale License
* distributed with this Material.
* See the LICENSE file distributed for more details.
* 
*
****************************************************************************//*!
*
* @file     motor_def.h
*
* @brief    Main control structure definition
*
******************************************************************************/

#ifndef _MCDEF_H_
#define _MCDEF_H_

/******************************************************************************
* Includes
******************************************************************************/
#include "pmsm_control.h"

/******************************************************************************
* Constants
******************************************************************************/

/******************************************************************************
* Macros 
******************************************************************************/
#define MC_FAULT_I_DCBUS_OVER   0   /* OverCurrent fault flag */
#define MC_FAULT_U_DCBUS_UNDER  1   /* Undervoltage fault flag */
#define MC_FAULT_U_DCBUS_OVER   2   /* Overvoltage fault flag */
#define MC_FAULT_LOAD_OVER      3   /* Overload fault flag */
#define MC_FAULT_SPEED_OVER     4   /* Over speed fault flag */
#define MC_FAULT_MC33937        5   /* MC33937 predriver fault flag */

/* Sets the fault bit defined by faultid in the faults variable */
#define MC_FAULT_SET(faults, faultid) (faults |= ((MCDEF_FAULT_T)1 << faultid))

/* Clears the fault bit defined by faultid in the faults variable */
#define MC_FAULT_CLEAR(faults, faultid) (faults &= ~((MCDEF_FAULT_T)1 << faultid))

/* Check the fault bit defined by faultid in the faults variable, returns 1 or 0 */
#define MC_FAULT_CHECK(faults, faultid) ((faults & ((MCDEF_FAULT_T)1 << faultid)) >> faultid)

/* Clears all fault bits in the faults variable */
#define MC_FAULT_CLEAR_ALL(faults) (faults = 0)

/* Check if a fault bit is set in the faults variable, 0 = no fault */
#define MC_FAULT_ANY(faults) (faults > 0)

/* Update a fault bit defined by faultid in the faults variable according to the LSB of value */
#define MC_FAULT_UPDATE(faults, faultid, value) {MC_FAULT_CLEAR(faults, faultid); faults |= (((MC_FAULT_T)value & (MC_FAULT_T)1) << faultid);}

/******************************************************************************
* Types
******************************************************************************/
typedef UWord16 MCDEF_FAULT_T;

typedef enum {
    CONTROL_MODE_SCALAR                 = 0,
    CONTROL_MODE_VOLTAGE_FOC            = 1,
    CONTROL_MODE_CURRENT_FOC            = 2,
    CONTROL_MODE_SPEED_FOC              = 3,
} MCS_CONTROL_MODE_T;              /* control modes of the motor */

typedef struct
{
    Frac16                      f16UDcBusOver;  /* DC bus over voltage level */
    Frac16                      f16UDcBusUnder; /* DC bus under voltage level */
    Frac16                      f16SpeedOver;   /* Over speed level */
    Frac16                      f16SpeedMin;    /* Minimum speed level */
    Frac16                      f16SpeedNom;    /* Nominal speed */
} MCDEF_FAULT_THRESHOLDS_T;


/* PMSM FOC with BEMF observer in DQ */
typedef struct
{
    MCS_PMSM_FOC_A1_T           sFocPMSM;                       /* Field Oriented Cntrol structure */
    MCS_SPEED_A1_T              sSpeed;                         /* Speed control loop structure  */
    MCS_PMSM_STARTUP_A1_T       sStartUp;                       /* Open loop start-up */
    MCS_ALIGNMENT_A1_T          sAlignment;                     /* PMSM simple two-step Ud voltage alignment */
    MCS_MCAT_CTRL_A1_T          sMCATctrl;                      /* Structure containing control variables directly updated from MCAT */
    MCS_PMSM_SCALAR_CTRL_A1_T   sScalarCtrl;                    /* Scalar control structure */
    MCDEF_FAULT_T               sFaultId;                       /* Application motor faults */
    MCDEF_FAULT_T               sFaultIdPending;                /* Fault pending structure */
    MCDEF_FAULT_THRESHOLDS_T    sFaultThresholds;               /* Fault tresholds */
    MCS_CONTROL_MODE_T          eControl;                       /* MCAT control modes */
    UWord16                     uw16CounterState;               /* Main state counter */    
    UWord16                     uw16CounterSlowLoop;            /* Slow control loop counter */
    UWord16                     uw16TimeSlowLoop;               /* Slow control loop time count number */
    UWord16                     uw16TimeFullSpeedFreeWheel;     /* Freewheel time count number */
    UWord16                     uw16TimeCalibration;            /* Calibration time count number */
    UWord16                     uw16TimeFaultRelease;           /* Fault time count number */
} MCDEF_PMSM_T;

/******************************************************************************
* Global variables
******************************************************************************/

/******************************************************************************
* Global functions
******************************************************************************/

/******************************************************************************
* Inline functions
******************************************************************************/


#endif /* _MCDEF_H_ */
