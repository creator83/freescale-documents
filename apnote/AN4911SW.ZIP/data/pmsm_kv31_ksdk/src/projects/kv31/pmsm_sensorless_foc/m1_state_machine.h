/*******************************************************************************
*
* Copyright 2014 Freescale Semiconductor, Inc.

*
* This software is owned or controlled by Freescale Semiconductor.
* Use of this software is governed by the Freescale License
* distributed with this Material.
* See the LICENSE file distributed for more details.
* 
*
****************************************************************************//*!
*
* @file     m1_state_machine.h
*
* @brief    Motor 1 state machine header file
*
******************************************************************************/
#ifndef _M1_STATE_MACHINE_H_
#define _M1_STATE_MACHINE_H_

/******************************************************************************
* Includes
******************************************************************************/
#include <stdbool.h>

#include "pmsm_appconfig.h"
#include "state_machine.h"
#include "pmsm_control.h"
#include "motor_def.h"

/* library headers */
#include "gmclib.h"
#include "gflib.h"
#include "gdflib.h"
#include "aclib.h"

/******************************************************************************
* Constants
******************************************************************************/

/******************************************************************************
* Macros 
******************************************************************************/

/******************************************************************************
* Types
******************************************************************************/
typedef enum {
    CALIB               = 0,
    READY               = 1,
    ALIGN               = 2,
    STARTUP             = 3,
    SPIN                = 4,
    FREEWHEEL           = 5,
    MEASURE             = 6,
} M1_RUN_SUBSTATE_T;         /* Run sub-states */

/******************************************************************************
* Global variables
******************************************************************************/
extern bool             mbM1SwitchAppOnOff; 
extern MCDEF_PMSM_T     gsM1Drive;
extern SM_APP_CTRL_T    gsM1Ctrl;

/******************************************************************************
* Global functions
******************************************************************************/
#ifdef __cplusplus
extern "C" {
#endif
  
extern void M1_SetAppSwitch(bool bValue);
extern bool M1_GetAppSwitch();
extern void M1_SetSpeed(Frac16 f16SpeedCmd);
extern Frac16 M1_GetSpeed(void);

#ifdef __cplusplus
}
#endif

/******************************************************************************
* Inline functions
******************************************************************************/

#endif /* M1_STATE_MACHINE */
