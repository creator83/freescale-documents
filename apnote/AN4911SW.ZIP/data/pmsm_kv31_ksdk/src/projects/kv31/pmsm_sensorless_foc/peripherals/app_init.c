/******************************************************************************
* 
* Copyright (c) 2014 Freescale Semiconductor;
* All Rights Reserved                       
*
******************************************************************************* 
*
* THIS SOFTWARE IS PROVIDED BY FREESCALE "AS IS" AND ANY EXPRESSED OR 
* IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES 
* OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  
* IN NO EVENT SHALL FREESCALE OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
* INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
* SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
* STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING 
* IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF 
* THE POSSIBILITY OF SUCH DAMAGE.
*
***************************************************************************//*!
*
* $FileName: app_init.c$
* $Version : 3.6.1.0$
* $Date    : Jan-21-2013$
*
* Comments:
*
*   This file contains the init functions for some peripherals.
*
*END************************************************************************/

#include "app_init.h"

/******************************************************************************
* Global variables
******************************************************************************/
extern bool            mbM1SwitchAppOnOff;
/******************************************************************************
* Local variables
******************************************************************************/

/***************************************************************************
* InitPorts
* --------------------------------------------------------------------------
* Global init of the board ports
****************************************************************************/
void InitPorts(void)
{   
    /* Enable Clock to Ports */
    CLOCK_SYS_EnablePortClock(0);                                               /* Port A - enable clock */
    CLOCK_SYS_EnablePortClock(1);                                               /* Port B - enable clock */
    CLOCK_SYS_EnablePortClock(2);                                               /* Port C - enable clock */
    CLOCK_SYS_EnablePortClock(3);                                               /* Port D - enable clock */
    CLOCK_SYS_EnablePortClock(4);                                               /* Port E - enable clock */

    /* LED's MUX set as GPIO */
    PORT_HAL_SetMuxMode(PORTE_BASE, 1, kPortMuxAsGpio);                         /* LED1 */
    PORT_HAL_SetMuxMode(PORTE_BASE, 0, kPortMuxAsGpio);                         /* LED2 */
    PORT_HAL_SetMuxMode(PORTB_BASE, 19, kPortMuxAsGpio);                        /* LED3 */
    PORT_HAL_SetMuxMode(PORTD_BASE, 7, kPortMuxAsGpio);                         /* LED4 */
    
    /* Set LED pin direction */
    GPIO_HAL_SetPinDir(PTE_BASE, 1, kGpioDigitalOutput);                        /* LED1 */
    GPIO_HAL_SetPinDir(PTE_BASE, 0, kGpioDigitalOutput);                        /* LED2 */
    GPIO_HAL_SetPinDir(PTB_BASE, 19, kGpioDigitalOutput);                       /* LED3 */
    GPIO_HAL_SetPinDir(PTD_BASE, 7, kGpioDigitalOutput);                        /* LED4 */

     /* Configures the drive strength if the pin is used as a digital output */
    PORT_HAL_SetDriveStrengthMode(PORTE_BASE, 1, kPortHighDriveStrength);       /* LED1 */
    PORT_HAL_SetDriveStrengthMode(PORTE_BASE, 0, kPortHighDriveStrength);       /* LED2 */
    PORT_HAL_SetDriveStrengthMode(PORTB_BASE, 19, kPortHighDriveStrength);      /* LED3 */
    PORT_HAL_SetDriveStrengthMode(PORTD_BASE, 7, kPortHighDriveStrength);       /* LED4 */
    
    /* Turn of all leds*/
    LED1_OFF; LED2_OFF; LED3_OFF; LED4_OFF;                                     

    /* For 3PPA driver - ENABLE */
    PORT_HAL_SetMuxMode(PORTA_BASE, 5, kPortMuxAsGpio);                         /* Set as GPIO */
    GPIO_HAL_SetPinDir(PTA_BASE, 5, kGpioDigitalOutput);                        /* Set as Output */

    /* For 3PPA driver - RESET */
    PORT_HAL_SetMuxMode(PORTC_BASE, 7, kPortMuxAsGpio);                         /* Set as GPIO */
    GPIO_HAL_SetPinDir(PTC_BASE, 7, kGpioDigitalOutput);                        /* Set as Output */

    /* For 3PPA driver - Interrupt */
    PORT_HAL_SetMuxMode(PORTB_BASE, 18, kPortMuxAsGpio);                        /* Set as GPIO */
    PORT_HAL_SetPassiveFilterCmd(PORTB_BASE, 18, 1);                            /* Set passive filter*/
    PORT_HAL_SetPullCmd(PORTB_BASE, 18, true);                                  /* Enable pull-up or pull-down */
    PORT_HAL_SetPullMode(PORTB_BASE, 18, kPortPullDown);                        /* Set pull mode to pull-down*/
    GPIO_HAL_SetPinDir(PTB_BASE, 18, kGpioDigitalInput);                        /* Set as Input*/
    
    /* For 3PPA driver - Overcurrent */
    PORT_HAL_SetMuxMode(PORTC_BASE, 9, kPortMuxAsGpio);                         /* Set as GPIO */
    PORT_HAL_SetPassiveFilterCmd(PORTC_BASE, 9, 1);                             /* Set passive filter*/
    PORT_HAL_SetPullCmd(PORTC_BASE, 9, true);                                   /* Enable pull-up or pull-down */
    PORT_HAL_SetPullMode(PORTC_BASE, 9, kPortPullDown);                         /* Set pull mode to pull-down*/
    GPIO_HAL_SetPinDir(PTC_BASE, 9, kGpioDigitalInput);                         /* Set as Input*/ 
    
    /* SW's MUX set - SW1 */    
    PORT_HAL_SetMuxMode(PORTC_BASE, 6, kPortMuxAsGpio);                         /* Set as GPIO */
    PORT_HAL_SetPinIntMode(PORTC_BASE, 6, kPortIntFallingEdge);                 /* Set interrupt at failing edge */
    PORT_HAL_SetPullCmd(PORTC_BASE, 6, true);                                   /* Enable pull-up or pull-down */
    PORT_HAL_SetPullMode(PORTC_BASE, 6, kPortPullUp);                           /* Set pull mode to pull-up */
    
    /* SW's MUX set - SW2 */    
    PORT_HAL_SetMuxMode(PORTC_BASE, 11, kPortMuxAsGpio);                        /* Set as GPIO */
    PORT_HAL_SetPinIntMode(PORTC_BASE, 11, kPortIntFallingEdge);                /* Set interrupt at failing edge */
    PORT_HAL_SetPullCmd(PORTC_BASE, 11, true);                                  /* Enable pull-up or pull-down */
    PORT_HAL_SetPullMode(PORTC_BASE, 11, kPortPullUp);                          /* Set pull mode to pull-up */
    
    /* SW's MUX set - SW3 */    
    PORT_HAL_SetMuxMode(PORTA_BASE, 4, kPortMuxAsGpio);                         /* Set as GPIO */
}
/**************************************************************************//*!
* FreeMASTER_Init
* --------------------------------------------------------------------------
* Initialize FreeMASTER resources
******************************************************************************/
void InitFreemaster(void)
{ 
    /* Set UART TX & RX pins */
    PORT_HAL_SetMuxMode(PORTB_BASE, 16, kPortMuxAlt3);                          /* TX, PTB16, TWR Elevator pin A43 */
    PORT_HAL_SetMuxMode(PORTB_BASE, 17, kPortMuxAlt3);                          /* RX, PTB17, TWR Elevator pin A44  */

    /* Initialize UART Driver */  
    InitUART();
  
    /* Initialize Freemaster */
    FMSTR_Init();
}
/*
 *######################################################################
 *                           End of File
 *######################################################################
*/