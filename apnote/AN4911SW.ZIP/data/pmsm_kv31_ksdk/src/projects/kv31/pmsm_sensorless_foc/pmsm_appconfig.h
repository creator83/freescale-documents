/**********************************************************************/
// File Name: {FM_project_loc}/../../src/projects/kv31/pmsm_sensorless_foc/PMSM_appconfig.h 
//
// Date:  17. February, 2015
//
// Automatically generated file for static configuration of the PMSM FOC application
/**********************************************************************/

#ifndef __M1_PMSM_APPCONFIG_H
#define __M1_PMSM_APPCONFIG_H


//Motor Parameters                      
//----------------------------------------------------------------------
//Pole-pair number                      = 2 [-]
//Stator resistance                     = 0.61 [Ohms]
//Direct axis inductance                = 0.000401 [H]
//Quadrature axis inductance            = 0.000484 [H]
//Back-EMF constant                     = 0.0149 [V.sec/rad]
//Drive inertia                         = 0.0000016 [kg.m2]
//Nominal current                       = 2 [A]

#define MOTOR_PP                        (2)
//----------------------------------------------------------------------

//Application scales                    
//----------------------------------------------------------------------
#define I_MAX                           (8.0F)
#define U_DCB_MAX                       (36.3F)
#define U_MAX                           (21.0F)
#define N_MAX                           (4400.0F)
#define FREQ_MAX                        (147.0)
#define E_MAX                           (15.1F)
#define U_DCB_TRIP                      FRAC16(0.798898071625)
#define U_DCB_UNDERVOLTAGE              FRAC16(0.399449035813)
#define U_DCB_OVERVOLTAGE               FRAC16(0.798898071625)
#define N_OVERSPEED                     FRAC16(0.954545454545)
#define N_MIN                           FRAC16(0.045454545455)
#define N_NOM                           FRAC16(0.909090909091)
#define I_PH_NOM                        FRAC16(0.25)
//DCB Voltage Filter                    
#define UDCB_IIR_B0                     FRAC16(0.003807378494)
#define UDCB_IIR_B1                     FRAC16(0.003807378494)
#define UDCB_IIR_A1                     FRAC16(-0.117385243012)
//Mechanical Alignment                  
#define ALIGN_VOLTAGE                   FRAC16(0.047619047619)
#define ALIGN_DURATION                  (500)

//Current Loop Control                  
//----------------------------------------------------------------------
//Loop Bandwidth                        = 200 [Hz]
//Loop Attenuation                      = 1 [-]
//Loop sample time                      = 0.0001 [sec]
//----------------------------------------------------------------------
//Current Controller Output Limit       
#define CLOOP_LIMIT                     FRAC16(0.9)
//D-axis Controller - Parallel type     
#define D_KP_GAIN                       FRAC16(0.606206359271)
#define D_KP_SHIFT                      (-2)
#define D_KI_GAIN                       FRAC16(0.771942178589)
#define D_KI_SHIFT                      (-6)
//Q-axis Controller - Parallel type     
#define Q_KP_GAIN                       FRAC16(0.924075695954)
#define Q_KP_SHIFT                      (-2)
#define Q_KI_GAIN                       FRAC16(0.931720734257)
#define Q_KI_SHIFT                      (-6)

//Speed Loop Control                    
//----------------------------------------------------------------------
//Loop Bandwidth                        = 10 [Hz]
//Loop Attenuation                      = 1 [-]
//Loop sample time                      = 0.001 [sec]
//----------------------------------------------------------------------
//Speed Controller - Parallel type      
#define SPEED_PI_PROP_GAIN              FRAC16(0.69115038379)
#define SPEED_PI_PROP_SHIFT             (-1)
#define SPEED_PI_INTEG_GAIN             FRAC16(0.530803494751)
#define SPEED_PI_INTEG_SHIFT            (-9)
#define SPEED_LOOP_HIGH_LIMIT           FRAC16(0.25)
#define SPEED_LOOP_LOW_LIMIT            FRAC16(-0.25)

#define SPEED_RAMP_UP                   FRAC32(0.000227272727)
#define SPEED_RAMP_DOWN                 FRAC32(0.000227272727)

#define SPEED_LOOP_CNTR                 (10)
#define SPEED_LOOP_FREQ                 (1000)

#define SPEED_IIR_B0                    FRAC16(0.029882152951)
#define SPEED_IIR_B1                    FRAC16(0.029882152951)
#define SPEED_IIR_A1                    FRAC16(-0.065235694097)

//Sensorless BEMF DQ nad Tracking Observer
//----------------------------------------------------------------------
//Loop Bandwidth                        = 200 [Hz]
//Loop Attenuation                      = 1 [-]
//Loop sample time                      = 0.0001 [sec]
//----------------------------------------------------------------------
//Bemf DQ Observer                      
#define I_SCALE                         FRAC16(0.867965367966)
#define U_SCALE                         FRAC16(0.568181818182)
#define E_SCALE                         FRAC16(0.40854978355)
#define WI_SCALE                        FRAC16(0.096541640911)
#define I_SCALE_SHIFT                   (0)
#define BEMF_DQ_KP_GAIN                 FRAC16(0.843068446668)
#define BEMF_DQ_KP_SHIFT                (-2)
#define BEMF_DQ_KI_GAIN                 FRAC16(0.536780985112)
#define BEMF_DQ_KI_SHIFT                (-4)

//Bemf DQ Observer                      
#define TO_KP_GAIN                      FRAC16(0.6)
#define TO_KP_SHIFT                     (-2)
#define TO_KI_GAIN                      FRAC16(0.530803494751)
#define TO_KI_SHIFT                     (-10)
#define TO_THETA_GAIN                   FRAC16(0.938666666667)
#define TO_THETA_SHIFT                  (-5)
//Observer speed output filter          
#define TO_SPEED_IIR_B0                 FRAC16(0.013954401463)
#define TO_SPEED_IIR_B1                 FRAC16(0.013954401463)
#define TO_SPEED_IIR_A1                 FRAC16(-0.097091197074)
//Open loop start-up                    
#define OL_START_RAMP_INC               FRAC32(0.000034090909)
#define OL_START_I                      FRAC16(0.05625)
#define MERG_SPEED_TRH                  FRAC16(0.113636363636)
#define MERG_COEFF                      FRAC16(0.009155273438)

//Control Structure Module - Scalar Control
//----------------------------------------------------------------------
#define SCALAR_VHZ_FACTOR_GAIN          FRAC16(0.942857142857)
#define SCALAR_VHZ_FACTOR_SHIFT         (0)
#define SCALAR_INTEG_GAIN               FRAC16(0.014666666667)
#define SCALAR_INTEG_SHIFT              (0)
#define SCALAR_RAMP_UP                  FRAC32(0.000022727273)
#define SCALAR_RAMP_DOWN                FRAC32(0.000022727273)

//Motor Identification Module           
//----------------------------------------------------------------------
#define CHAR_NUMBER_OF_POINTS_BASE      (6)
#define CHAR_CURRENT_POINT_NUMBERS      (65)
#define CHAR_NUMBER_OF_POINTS_HALF      (32)
#define TIME_50MS                       (500)
#define TIME_100MS                      (1000)
#define TIME_300MS                      (3000)
#define TIME_600MS                      (6000)
#define TIME_1200MS                     (12000)
#define TIME_2400MS                     (24000)
#define K_I_RESCALE_LUT_SHIFT           (1)
#define PWR_CHAR_CURRENT_END            FRAC16(0.25)
#define PWR_CHAR_CURRENT_INC            FRAC16(0.007692307692307693)
#define K_RESCALE_DCB_TO_PHASE_HALF     FRAC16(0.8642857142857142)
#define K_ANGLE_INCREMENT               FRAC16(0.2)
#define INV_MOD_INDEX                   FRAC16(0.5010064319414108)
#define K_I_RESCALE_LUT_GAIN            FRAC16(1.0)
#define K_I_50MA                        FRAC16(0.00625)

#endif

//End of generated file                 
/**********************************************************************/
