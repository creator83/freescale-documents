/*******************************************************************************
*
* Copyright 2014 Freescale Semiconductor, Inc.

*
* This software is owned or controlled by Freescale Semiconductor.
* Use of this software is governed by the Freescale License
* distributed with this Material.
* See the LICENSE file distributed for more details.
* 
*
****************************************************************************//*!
*
* @file     main.c
*
* @brief    The main file for PMSM sensorless on KV31
*
******************************************************************************/

/******************************************************************************
* Includes
******************************************************************************/
#include "fsl_os_abstraction.h"     /* SDK header file */
#include "fsl_interrupt_manager.h"  /* SDK header file */

#include "board_twr-kv31f120m.h"
#include "app_init.h"
#include "peripherals_init.h"
#include "freemaster.h"
/******************************************************************************
* Global variables
******************************************************************************/

/******************************************************************************
* Local variables
******************************************************************************/
static Frac16          mf16M1SpeedCmd;
/***************************************************************************
* Main
* --------------------------------------------------------------------------
* 
****************************************************************************/
void main()
{    
    /* Initialize PORTS - SW's & LED's */
    InitPorts();

    /* Initialize SPI module */
    InitSPI0();
    
    /* Initialize FTM module */
    InitFTM0();

    /* Initialize PDB module */
    InitPDB();
    
    /* Initialize ADC module */
    InitADC();
    
    /* Initialize Freemaster */
    InitFreemaster();
    
    /* Install ADC IRQ Handler */
    INT_SYS_InstallHandler(ADC1_IRQn, ADC_ISR_Handler);                         // Install IRQ
    /* Install PDB IRQ Handler */
    INT_SYS_InstallHandler(PDB0_IRQn, PDB_Error_ISR_Handler);                   // Install IRQ
    /* Install PORT IRQ handler */
    INT_SYS_InstallHandler(PORTC_IRQn, PORT_ISR_Handler);                       // Install IRQ
    
    /* Enable Interrupts */
    INT_SYS_EnableIRQ(ADC1_IRQn);                                               // Enable IRQ for ADC1
    INT_SYS_EnableIRQ(PDB0_IRQn);                                               // Enable IRQ for PDB0
    INT_SYS_EnableIRQ(PORTC_IRQn);                                              // Enable IRQ for PORTC
    
    /* Enable Global Interrupts */
    INT_SYS_EnableIRQGlobal();                                                  // Enable global interrupts
    
    for(;;)
    {
        FMSTR_Poll();                                                           // Freemaster polling mode
    }
    
}

/*************************************************************************
 * Function Name: ADC_ISR_Handler
 * Parameters: none;
 *
 * Return: nothing
 *
 * Description:  handling the adc complete interrupt
 *
 *************************************************************************/
void ADC_ISR_Handler(void)
{
    /* StateMachine call */
    SM_StateMachine(&gsM1Ctrl);   
  
    /* FreeMASTER Recorder */
    FMSTR_Recorder();  
}

/*************************************************************************
 * Function Name: PDB_Error_ISR_Handler
 * Parameters: none;
 *
 * Return: nothing
 *
 * Description:  handling the PDB error interrupt: reinitiates the PDB module 
 *
 *************************************************************************/
void PDB_Error_ISR_Handler(void)
{
    /* Clear error sequence */
    PDB_HAL_Disable(PDB0_BASE);                                                 // Disable PDB module
    PDB_HAL_ClearPreTriggerSeqErrFlag(PDB0_BASE, 0, 0);                         // Clear Error flag
    PDB_HAL_ClearPreTriggerSeqErrFlag(PDB0_BASE, 1, 0);                         // Clear Error flag
    PDB_HAL_ClearPreTriggerFlag(PDB0_BASE, 0, 0);                               // Clear trigger flag
    PDB_HAL_ClearPreTriggerFlag(PDB0_BASE, 1, 0);                               // Clear trigger flag
    PDB_HAL_Enable(PDB0_BASE);                                                  // Enable PDB module
}

/*************************************************************************
 * Function Name: PORT_ISR_Handler
 * Parameters: none;
 *
 * Return: nothing
 *
 * Description:  handling the PORTx interrupt: control of PMSM demo 
 *
 *************************************************************************/
void PORT_ISR_Handler()
{
    if(PORT_HAL_IsPinIntPending(PORTC_BASE, 6))                                 // Check if interrupt still pending        
    {
        PORT_HAL_ClearPinIntFlag(PORTC_BASE, 6);                                // Clear pin interrupt flag
    
        if(gsM1Ctrl.eState == RUN)                                              // Increase speed if button is pressed in RUN state
        {
            mf16M1SpeedCmd = M1_GetSpeed();
        if (mf16M1SpeedCmd < FRAC16(SPEED_MAX_BTN/N_MAX))
            mf16M1SpeedCmd = MLIB_AddSat_F16(mf16M1SpeedCmd,FRAC16(SPEED_INC_BTN/N_MAX));
            M1_SetSpeed(mf16M1SpeedCmd);  
        }    
        if (gsM1Ctrl.eState == STOP)                                            // Transition from Stop to Run state
        {
        mbM1SwitchAppOnOff = true;
        M1_SetAppSwitch(mbM1SwitchAppOnOff);
        }      
    }
  
    if(PORT_HAL_IsPinIntPending(PORTC_BASE, 11))                                // Check if interrupt still pending
    {   
        PORT_HAL_ClearPinIntFlag(PORTC_BASE, 11);                               // Clear pin interrupt flag
    
    if (gsM1Ctrl.eState == RUN)                                                  // Decrease speed if button is pressed
    {
        mf16M1SpeedCmd = M1_GetSpeed();
        if (mf16M1SpeedCmd == 0)
        {
            mbM1SwitchAppOnOff = false;
            M1_SetAppSwitch(mbM1SwitchAppOnOff);
        }
        if (mf16M1SpeedCmd >= FRAC16(SPEED_INC_BTN/N_MAX))
            mf16M1SpeedCmd = MLIB_SubSat_F16(mf16M1SpeedCmd,FRAC16(SPEED_INC_BTN/N_MAX));  
        if (mf16M1SpeedCmd < FRAC16(0.05))                                      // Handling rounding error
            mf16M1SpeedCmd = 0;  
        M1_SetSpeed(mf16M1SpeedCmd);        
        }
    }
}

/*
 *######################################################################
 *                           End of File
 *######################################################################
*/