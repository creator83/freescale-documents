/*******************************************************************************
*
* Copyright 2014 Freescale Semiconductor, Inc.
*
* This software is owned or controlled by Freescale Semiconductor.
* Use of this software is governed by the Freescale License
* distributed with this Material.
* See the LICENSE file distributed for more details.
* 
*
****************************************************************************//*!
*
* @file         peripherals_init.c
*
* @brief        This file contains the init functions for some peripherals.
* 
*******************************************************************************/
#ifndef __PERIPHERALS_INIT_H
#define __PERIPHERALS_INIT_H

/* SDK includes */
#include "fsl_interrupt_manager.h"
#include "fsl_clock_manager.h"
#include "fsl_port_hal.h"
#include "fsl_gpio_hal.h"
#include "fsl_ftm_hal.h"
#include "fsl_pdb_hal.h"
#include "fsl_adc_hal.h"
#include "fsl_sim_hal.h"
#include "fsl_dspi_hal.h"
#include "fsl_uart_hal.h"

/* Projects includes */
#include "main.h"
#include "m1_state_machine.h"
#include "freemaster.h"
/***************************** Prototypes **********************************/

void InitSPI0();
/***************************************************************************
* InitSPI
* --------------------------------------------------------------------------
* Initialization of the SPI module
****************************************************************************/

void InitUART();
/***************************************************************************
* InitUartHAL
* --------------------------------------------------------------------------
* Initialization of the UART module
****************************************************************************/

void InitFTM0(void);
/***************************************************************************
* InitFTM0
* --------------------------------------------------------------------------
* Initialization of the FTM0 module for quadrature decoder function
****************************************************************************/

void InitPDB(void);
/***************************************************************************
* InitPDB
* --------------------------------------------------------------------------
* Initialization of the PDB module
****************************************************************************/

void InitADC(void);
/***************************************************************************
* InitADC
* --------------------------------------------------------------------------
* Initialization of the A/D converter for current and voltage sensing
* 
****************************************************************************/

#endif /* __PERIPHERALS_INIT_H  */