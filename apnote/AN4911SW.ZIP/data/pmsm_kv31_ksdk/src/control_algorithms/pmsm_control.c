/*******************************************************************************
*
* Copyright 2014 Freescale Semiconductor, Inc.
*
* This software is owned or controlled by Freescale Semiconductor.
* Use of this software is governed by the Freescale License
* distributed with this Material.
* See the LICENSE file distributed for more details.
* 
*
****************************************************************************//*!
*
* @file         pmsm_control.c
*
* @brief        Control algorithms for PMSM
* 
*******************************************************************************/

/******************************************************************************
* Includes
******************************************************************************/
#include "pmsm_control.h"

/******************************************************************************
* Constants
******************************************************************************/

/******************************************************************************
* Macros 
******************************************************************************/

/******************************************************************************
* Types
******************************************************************************/

/******************************************************************************
* Global variables
******************************************************************************/

/******************************************************************************
* Global functions
******************************************************************************/

/***************************************************************************//*!
*
* @brief   PMSM field oriented voltage control
*
* @param   MCS_PMSM_FOC_A1_T *psFocPMSM
*            - structure of PMSM FOC parameters
*            IN: -> sAnglePosElReload - angle where the next PWM reload
*            IN: -> f16AnglePosReload - position where next PWM reload
*            IN: -> f16UDcBusFilt - actual DCBus voltage value
*            IN: -> sUDQReq - D and Q required voltages
*            IN/OUT -> sUAlBeReq - D nad Q Alpha/Beta voltages
*            OUT -> sDutyABC - ABC duty cycles
*            OUT -> uw16SectorSVM - Next step SVM sector
*
* @return  N/A
*
******************************************************************************/
void MCS_PMSMFocCtrlVoltageA1(MCS_PMSM_FOC_A1_T *psFocPMSM)
{
    /* Position angle of the last PWM update */
    psFocPMSM -> sAnglePosEl = psFocPMSM -> sAnglePosElReload;
    
    /* calculation of rotor position sinus and cosinus */
    psFocPMSM -> sAnglePosElReload.f16Sin = GFLIB_Sin(psFocPMSM -> f16PosElReload);
    psFocPMSM -> sAnglePosElReload.f16Cos = GFLIB_Cos(psFocPMSM -> f16PosElReload);
    
    /* 2-phase to 2-phase transformation to stationary ref. frame */
    GMCLIB_ParkInv(&psFocPMSM -> sUAlBeReq, &psFocPMSM -> sAnglePosElReload, &psFocPMSM -> sUDQReq);

    psFocPMSM -> sElimDCBRip.f16ArgDcBusMsr  = psFocPMSM -> f16UDcBusFilt;
    
    /* Begin - voltage control */
    GMCLIB_ElimDcBusRip(&psFocPMSM -> sUAlBeComp,&psFocPMSM -> sUAlBeReq,&psFocPMSM -> sElimDCBRip) ;   

    psFocPMSM -> uw16SectorSVM = GMCLIB_SvmStd(&psFocPMSM -> sDutyABC,&psFocPMSM -> sUAlBeComp); 
}

/***************************************************************************//*!
*
* @brief   PMSM field oriented current control
*
* @param   MCS_PMSM_FOC_A1_T *psFocPMSM
*            - structure of PMSM FOC parameters
*            IN: -> sIABC - input ABC phases currents
*            IN: -> sAnglePosEl - angle where the currents were measured
*            IN: -> sAnglePosElReload - angle where the next PWM reload
*            IN: -> f16UDcBusFilt - DC bus voltage
*            IN: -> f16UDcBusFilt - actual DCBus voltage value
*            IN: -> f16DutyCycleLimit - determines the max. value of duty cycle
*            IN/OUT -> sIdPiParams - D current controller structure
*            IN/OUT -> sIqPiParams - Q current controller structure
*            IN/OUT -> i16IdPiSatFlag - D current controller saturation flag
*            IN/OUT -> i16IqPiSatFlag - Q current controller saturation flag
*            OUT -> sDutyABC - ABC duty cycles
*            OUT -> uw16SectorSVM - Next step SVM sector
*
* @return  N/A
*
******************************************************************************/
void MCS_PMSMFocCtrlCurrentA1(MCS_PMSM_FOC_A1_T *psFocPMSM)
{
    /* Position angle of the last PWM update */
    psFocPMSM -> sAnglePosEl = psFocPMSM -> sAnglePosElReload;
    
   /* sine and cosine of the angle */
    psFocPMSM -> sAnglePosElReload.f16Sin = GFLIB_Sin(psFocPMSM -> f16PosElReload);
    psFocPMSM -> sAnglePosElReload.f16Cos = GFLIB_Cos(psFocPMSM -> f16PosElReload);
    
    /* 3-phase to 2-phase transformation to stationary ref. frame */
    GMCLIB_Clark(&psFocPMSM -> sIAlBe, &psFocPMSM -> sIABC, F16);
    
    /* 2-phase to 2-phase transformation to rotary ref. frame */
    GMCLIB_Park(&psFocPMSM -> sIDQ, &psFocPMSM -> sAnglePosEl, &psFocPMSM -> sIAlBe, F16);
    
    /* D current error calculation */
    psFocPMSM -> sIDQError.f16D = MLIB_SubSat_F16(psFocPMSM -> sIDQReq.f16D, psFocPMSM -> sIDQ.f16D);

    /* Q current error calculation */
    psFocPMSM -> sIDQError.f16Q = MLIB_SubSat_F16(psFocPMSM -> sIDQReq.f16Q, psFocPMSM -> sIDQ.f16Q);    
    
    /*** D - controller limitation calculation ***/
    psFocPMSM -> sIdPiParams.f16UpperLimit = MLIB_Mul_F16(psFocPMSM -> f16DutyCycleLimit, psFocPMSM -> f16UDcBusFilt);
    psFocPMSM -> sIdPiParams.f16LowerLimit = MLIB_Neg_F16(psFocPMSM -> sIdPiParams.f16UpperLimit);    

    /* D current PI controller */  
    psFocPMSM -> sUDQReq.f16D = GFLIB_ControllerPIpAW(psFocPMSM -> sIDQError.f16D, &psFocPMSM -> sIdPiParams);

    /* D current controller saturation flag */
    psFocPMSM -> i16IdPiSatFlag = psFocPMSM -> sIdPiParams.u16LimitFlag;

    /*** Q - controller limitation calculation ***/
    psFocPMSM -> sIqPiParams.f16UpperLimit = GFLIB_Sqrt(MLIB_Sub_F16(MLIB_Mul_F16(psFocPMSM -> sIdPiParams.f16UpperLimit,psFocPMSM -> sIdPiParams.f16UpperLimit), \
                                                        MLIB_Mul_F16(psFocPMSM ->sUDQReq.f16D,psFocPMSM ->sUDQReq.f16D)));
    psFocPMSM -> sIqPiParams.f16LowerLimit = MLIB_Neg_F16(psFocPMSM -> sIqPiParams.f16UpperLimit);   

    /* Q current PI controller */
    psFocPMSM -> sUDQReq.f16Q = GFLIB_ControllerPIpAW(psFocPMSM -> sIDQError.f16Q, &psFocPMSM -> sIqPiParams,F16);
    
    /* Q current controller saturation flag */
    psFocPMSM -> i16IqPiSatFlag = psFocPMSM -> sIqPiParams.u16LimitFlag;    
    
    /* 2-phase to 2-phase transformation to stationary ref. frame */
    GMCLIB_ParkInv(&psFocPMSM -> sUAlBeReq, &psFocPMSM -> sAnglePosEl, &psFocPMSM -> sUDQReq);

    /* DCBus ripple elimination */
    psFocPMSM -> sElimDCBRip.f16ArgDcBusMsr  = psFocPMSM -> f16UDcBusFilt;
    GMCLIB_ElimDcBusRip(&psFocPMSM -> sUAlBeComp,&psFocPMSM -> sUAlBeReq,&psFocPMSM -> sElimDCBRip) ;   

    /* space vector modulation */
    psFocPMSM -> uw16SectorSVM = GMCLIB_SvmStd(&psFocPMSM -> sDutyABC,&psFocPMSM -> sUAlBeComp); 

    /* End - voltage control */    
}

/***************************************************************************//*!
*
* @brief   PMSM foc speed control
*
* @param   MCS_PMSM_FOC_A1_T *psFocPMSM,
*            - structure of PMSM FOC parameters
*            IN: -> i16LimitFlag - limit flags of D and Q current PI controllers
*         MCS_SPEED_A1_T *psSpeed
*            - structure of PMSM speed parameters
*            IN: -> i16LimitFlag - limit flags of speed PI controllers
*            IN: -> sAlignment.f32Speed - speed of the field
*            IN: -> f16SpeedReq - required speed value
*            IN/OUT: -> f16SpeedRamp - speed ramp
*            IN: -> sAlignment.f32UStep - voltage step to ramp the voltage
*            OUT: -> psFocPMSM -> sDutyABC - duty cycles ABC
*
*
* @return  N/A
*
******************************************************************************/
void MCS_PMSMFocCtrlSpeedA1(MCS_PMSM_FOC_A1_T *psFocPMSM, MCS_SPEED_A1_T *psSpeed)
{
    /* Speed saturation flag given by the Q current controller saturation flag and speed controller saturation flag */
    psSpeed -> i16SpeedPiSatFlag = (psSpeed -> sSpeedPiParams.u16LimitFlag | psFocPMSM -> sIqPiParams.u16LimitFlag) \
            & (MLIB_AbsSat_F16(psSpeed -> f16SpeedReq) >= MLIB_AbsSat_F16(psSpeed -> f16SpeedFilt));
    
    /* Speed ramp generation */
    psSpeed -> f16SpeedRamp = (Frac16)MLIB_ShR_F32(GFLIB_Ramp_F32(MLIB_ShL_F32((Frac32)(psSpeed -> f16SpeedReq),16), &psSpeed -> sSpeedRampParams), 16);

    /* Speed error calculation */
    psSpeed -> f16SpeedError = MLIB_SubSat_F16(psSpeed -> f16SpeedRamp, psSpeed -> f16Speed);

    /* Desired current by the speed PI controller */
    psFocPMSM -> sIDQReq.f16Q = GFLIB_ControllerPIpAW(psSpeed -> f16SpeedError, &psSpeed -> sSpeedPiParams);

}

/***************************************************************************//*!
*
* @brief   PMSM 2-step rotor alignment
*
* @param   MCS_PMSM_FOC_A1_T *psFocPMSM
*            - structure of PMSM FOC parameters
*            IN/OUT: -> f16PosElReload - actual rotor position
*          MCS_ALIGNMENT_A1_T *psAlignment
*            - structure of alignment
*            IN: -> uw16CountAlignHalf - half alignment counter
*
* @return  N/A
*
******************************************************************************/
void MCS_PMSMAlignmentA1(MCS_PMSM_FOC_A1_T *psFocPMSM, MCS_ALIGNMENT_A1_T *psAlignment)
{
    /* first half duration time is position set to 120 degree */
    if (psAlignment-> uw16TimeHalf>0)
    {    
        psFocPMSM ->f16PosElReload = FRAC16(120.0/180.0);
        psAlignment -> uw16TimeHalf--;
    }
    else
    {
        psFocPMSM ->f16PosElReload    = FRAC16(0.0);
    }

    /* call voltage FOC to calculate PWM duty cycles */
    MCS_PMSMFocCtrlVoltageA1(psFocPMSM);    
}

/***************************************************************************//*!
*
* @brief   PMSM Open Loop Start-up
*          MCS_STARTUP_A1_T *psStartUp
*            - structure of open loop start up parameters
*            IN: -> f32SpeedReq - required speed
*            IN: -> f16SpeedCatchUp - merging speed threshold
*            IN/OUT: -> f16SpeedRampOpenLoop - ramped open loop speed
*            IN/OUT: -> f16RatioMerging - actual merging ration between open loop and estimated position
*            OUT: ->f16PosMerged - actual merged position
*
*
* @return  N/A
*
******************************************************************************/
void MCS_PMSMOpenLoopStartUpA1(MCS_PMSM_STARTUP_A1_T *psStartUp)
{  
    /* Open loop startup speed ramp */
    psStartUp -> f16SpeedRampOpenLoop = (Frac16)MLIB_ShR_F32((GFLIB_Ramp_F32(psStartUp -> f32SpeedReq, &psStartUp -> sSpeedRampOpenLoopParams)),16);

    /* generation of open loop position from the required speed */
    psStartUp -> f16PosGen = GFLIB_IntegratorTR(psStartUp -> f16SpeedRampOpenLoop, &psStartUp -> sSpeedIntegrator); 

    /* position merging starts above merging speed threshold*/
    if (MLIB_AbsSat_F16(psStartUp -> f16SpeedRampOpenLoop) >= psStartUp -> f16SpeedCatchUp)  
    {
        /* increment position merging coefficient */
        psStartUp -> f16RatioMerging = MLIB_AddSat_F16(psStartUp -> f16RatioMerging, psStartUp -> f16CoeffMerging);       

        /* merging equation */
        psStartUp -> f16PosMerged = MLIB_Add_F16(psStartUp -> f16PosGen,MLIB_Mul_F16(MLIB_Sub_F16(psStartUp -> f16PosEst, psStartUp -> f16PosGen), psStartUp -> f16RatioMerging));      
    }
    else           
    {
        psStartUp -> f16PosMerged = psStartUp -> f16PosGen;
    }
    
    /* clear open loop flag */
    if(psStartUp -> f16RatioMerging == FRAC16(1.0))
        psStartUp ->bOpenLoop = FALSE;

}

/***************************************************************************//*!
*
* @brief   PMSM scalar control
*
* @param   MCS_PMSM_FOC_A1_T *psFocPMSM
*            - structure of PMSM FOC parameters
*            IN/OUT: -> sUDQReq - required values of D/Q voltages
*            IN: f16PosElReload - actual position at PWM reload
*           MCS_PMSM_SCALAR_CTRL_A1_T *psScalarPMSM
*            - structure of scalar control
*            IN: f32FreqCmd - required frequency
*            IN/OUT: f16FreqRamp - ramped frequency value
*            OUT: f16PosElScalar - generated scalar position     
*
* @return  N/A
*
******************************************************************************/
void MCS_PMSMScalarCtrlA1(MCS_PMSM_FOC_A1_T *psFocPMSM, MCS_PMSM_SCALAR_CTRL_A1_T *psScalarPMSM)
{

    /* this part of code is executed when scalar control is turned-on */
    /* frequency ramp */
    psScalarPMSM -> f16FreqRamp = (Frac16)MLIB_ShR_F32((GFLIB_Ramp_F32(psScalarPMSM->f32FreqCmd, &psScalarPMSM -> sFreqRampParams)),16);

    /* voltage calculation */
    psScalarPMSM -> sUDQReq.f16Q = (Frac16)(MLIB_ShLSat_F16(MLIB_Mul_F16(psScalarPMSM->f16VHzGain,psScalarPMSM -> f16FreqRamp),\
                                                                                                       psScalarPMSM->f16VHzGainShift));
    psScalarPMSM -> sUDQReq.f16D = 0;

    /* stator voltage angle , used the same integrator as for the open-loop start up*/
    psScalarPMSM -> f16PosElScalar = GFLIB_IntegratorTR(psScalarPMSM -> f16FreqRamp, &psScalarPMSM -> sFreqIntegrator);

    /* pass parameters to FOC structure */
    psFocPMSM -> sUDQReq  = psScalarPMSM -> sUDQReq;
    psFocPMSM -> f16PosElReload = psScalarPMSM -> f16PosElScalar;

    /* call voltage FOC to calculate PWM duty cycles */
    MCS_PMSMFocCtrlVoltageA1(psFocPMSM);
}

/******************************************************************************
* Inline functions
******************************************************************************/
/*
 *######################################################################
 *                           End of File
 *######################################################################
*/


