/*
 * Copyright (c) 2013 - 2014, Freescale Semiconductor, Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * o Redistributions of source code must retain the above copyright notice, this list
 *   of conditions and the following disclaimer.
 *
 * o Redistributions in binary form must reproduce the above copyright notice, this
 *   list of conditions and the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 *
 * o Neither the name of Freescale Semiconductor, Inc. nor the names of its
 *   contributors may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#if !defined(__BOARD_TWR_KV31F120M_H__)
#define __BOARD_TWR_KV31F120M_H__

#include <stdint.h>
#include "app_init.h"

/* The board name */
#define BOARD_NAME              "TWR-KV31F120M"   
        
#define DISABLE_SW_INTERRUPT    PORT_HAL_SetPinIntMode(PORTC_BASE, 11, kPortIntDisabled)
#define DISABLE_SW_PIN          PORT_HAL_SetMuxMode(PORTC_BASE, 11, kPortPinDisabled)
#define ENABLE_SW_PIN           PORT_HAL_SetMuxMode(PORTC_BASE, 11, kPortMuxAsGpio)

#define LED1_EN  (PORT_HAL_SetMuxMode(PORTE_BASE, 1, kPortMuxAsGpio)) 	        /*!< Enable target LED1 */
#define LED2_EN  (PORT_HAL_SetMuxMode(PORTE_BASE, 0, kPortMuxAsGpio)) 	        /*!< Enable target LED2 */
#define LED3_EN  (PORT_HAL_SetMuxMode(PORTB_BASE, 19, kPortMuxAsGpio)) 	        /*!< Enable target LED3 */
#define LED4_EN  (PORT_HAL_SetMuxMode(PORTD_BASE, 7, kPortMuxAsGpio)) 	        /*!< Enable target LED4 */

#define LED1_DIS (PORT_HAL_SetMuxMode(PORTE_BASE, 1, kPortMuxAsGpio)) 	        /*!< Disable target LED1 */
#define LED2_DIS (PORT_HAL_SetMuxMode(PORTE_BASE, 0, kPortMuxAsGpio)) 	        /*!< Disable target LED2 */
#define LED3_DIS (PORT_HAL_SetMuxMode(PORTB_BASE, 19, kPortMuxAsGpio))  	    /*!< Disable target LED3 */
#define LED4_DIS (PORT_HAL_SetMuxMode(PORTD_BASE, 7, kPortMuxAsGpio)) 	        /*!< Disable target LED4 */

#define LED1_OFF (GPIO_HAL_WritePinOutput(PTE_BASE, 1, 1))                      /*!< Turn off target LED1 */
#define LED2_OFF (GPIO_HAL_WritePinOutput(PTE_BASE, 0, 1))                      /*!< Turn off target LED2 */
#define LED3_OFF (GPIO_HAL_WritePinOutput(PTB_BASE, 19, 1))                     /*!< Turn off target LED3 */
#define LED4_OFF (GPIO_HAL_WritePinOutput(PTB_BASE, 7, 1))                      /*!< Turn off target LED4 */

#define LED1_ON  (GPIO_HAL_WritePinOutput(PTE_BASE, 1, 0))                       /*!< Turn off target LED1 */
#define LED2_ON  (GPIO_HAL_WritePinOutput(PTE_BASE, 0, 0))                       /*!< Turn off target LED2 */
#define LED3_ON  (GPIO_HAL_WritePinOutput(PTB_BASE, 19, 0))                      /*!< Turn off target LED3 */
#define LED4_ON  (GPIO_HAL_WritePinOutput(PTB_BASE, 7, 0))                       /*!< Turn off target LED4 */

#if defined(__cplusplus)
extern "C" {
#endif /* __cplusplus */

#if defined(__cplusplus)
}
#endif /* __cplusplus */

#endif /* __BOARD_TWR_KV31F120M_H__ */
