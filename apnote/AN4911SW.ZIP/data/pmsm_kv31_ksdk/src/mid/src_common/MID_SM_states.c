/*******************************************************************************
*
* Copyright 2014 Freescale Semiconductor, Inc.
*
* This software is owned or controlled by Freescale Semiconductor.
* Use of this software is governed by the Freescale License
* distributed with this Material.
* See the LICENSE file distributed for more details.
*
*
****************************************************************************//*!
*
* @file      MID_SM_states.c
*
* @author    b30239
*
* @date      May-20-2014
*
* @brief     Motor parameters identification state machine
*
* @details	### Details ###
*           \par
*           In this file there are defined the motor identification state and
*           transition functions of the state machine. Switching among states is
*           done in @ref MID_SM_ctrl.c
*
*           \par
*           This code contains the MID state machine functions:
*           - MID_StateStart()
*           - MID_StatePwrStgCharact()
*           - MID_StateRs()
*           - MID_StateLd()
*           - MID_StateLq()
*           - MID_StatePp()
*           - MID_StateKe()
*           - MID_StateStop()
*
*           \par
*           MID transition functions:
*           - MID_TransStart2PwrStgCharact()
*           - MID_TransStart2Rs()
*           - MID_TransStart2Pp()
*           - MID_TransPwrStgCharact2Stop()
*           - MID_TransRs2Ld()
*           - MID_TransLd2Lq()
*           - MID_TransLq2Ke()
*           - MID_TransKe2Stop()
*           - MID_TransPp2Stop()
*
******************************************************************************/

/******************************************************************************
* Includes
******************************************************************************/
#include "MID_SM_states.h"

/******************************************************************************
* Constants
******************************************************************************/
#define true  (1)
#define false (0)

/******************************************************************************
* Macros
******************************************************************************/

/******************************************************************************
* Types
******************************************************************************/

/******************************************************************************
* Global variables
******************************************************************************/
MID_GET_RS_A1_T     sMIDRs;                    ///<Input structure for MID_getRs()
MID_GET_CHAR_A1_T   sMIDPwrStgChar;            ///<Input structure for MID_getTransChar()
MID_GET_LS_A1_T     sMIDLs;                    ///<Input structure for MID_getLs()
MID_GET_KE_A1_T     sMIDKe;                    ///<Input structure for MID_getKe()
MID_GET_PP_A1_T     sMIDPp;                    ///<Input structure for MID_getPp()
MID_ALIGN_A1_T      sMIDAlignment;             ///<Input structure for MID_alignment()
UWord16             uw16FaultMID;              ///<MID fault number, 0x0000 = no fault
UWord16             uw16EnableMeasurement;     ///<Enables measurement in superior machine
Frac16*             pf16Ud;                    ///<Pointer to required voltage Ud
Frac16*             pf16Id;                    ///<Pointer to phase current Id
Frac16*             pf16Uq;                    ///<Pointer to required voltage Uq
Frac16*             pf16Iq;                    ///<Pointer to phase current Iq
volatile float      fltMIDresistanceScale;     ///<FreeMaster resistance scale
volatile float      fltMIDfrequencyScale;      ///<FreeMaster frequency scale
volatile float      fltMIDimpedanceScale;      ///<FreeMaster impedance scale
volatile float      fltMIDinductanceDScale;    ///<FreeMaster D-axis inductance scale
volatile float      fltMIDinductanceQScale;    ///<FreeMaster Q-axis inductance scale
volatile float      fltMIDbemfConstScale;      ///<FreeMaster Bemf constant scale

/******************************************************************************
* Local variables
******************************************************************************/

/******************************************************************************
* Local functions
******************************************************************************/

/*---------------------------------------------------------
 * (user) Motor parameters identification state machine functions
 * --------------------------------------------------------*/
static void MID_StateStart(void);
static void MID_StatePwrStgCharact(void);
static void MID_StateRs(void);
static void MID_StateLd(void);
static void MID_StateLq(void);
static void MID_StatePp(void);
static void MID_StateKe(void);
static void MID_StateStop(void);

/*-------------------------------------------------------------------
 * (user) Motor parameters identification state-transition functions
 * ------------------------------------------------------------------*/
/* non-fault transition function prototypes */
static void MID_TransStart2PwrStgCharact(void);
static void MID_TransStart2Rs(void);
static void MID_TransStart2Pp(void);
static void MID_TransPwrStgCharact2Stop(void);
static void MID_TransRs2Ld(void);
static void MID_TransLd2Lq(void);
static void MID_TransLq2Ke(void);
static void MID_TransKe2Stop(void);
static void MID_TransPp2Stop(void);

/* State machine functions field */
static const MID_SM_APP_STATE_FCN_T msSTATE =   {
                                                MID_StateStart,
                                                MID_StatePwrStgCharact,
                                                MID_StateRs,
                                                MID_StateLd,
                                                MID_StateLq,
                                                MID_StatePp,
                                                MID_StateKe,
                                                MID_StateStop
                                                };

/* State-transition functions field */
/*
 * note: order of the transition function should be the same as in definition
 * of the MID_SM_APP_TRANS_FCN_T type
 */
static const MID_SM_APP_TRANS_FCN_T msTRANS =   {
                                                MID_TransStart2PwrStgCharact,
                                                MID_TransStart2Rs,
                                                MID_TransStart2Pp,
                                                MID_TransPwrStgCharact2Stop,
                                                MID_TransRs2Ld,
                                                MID_TransLd2Lq,
                                                MID_TransLq2Ke,
                                                MID_TransKe2Stop,
                                                MID_TransPp2Stop,
                                                };

/* State machine structure definition and initialization */
MID_SM_APP_CTRL_T gsMIDCtrl =
{
    /* gsMIDCtrl.psState, User state functions  */
    &msSTATE,

    /* gsMIDCtrl.psTrans, User state-transition functions */
    &msTRANS,

    /* gsMIDCtrl.uiCtrl, Default no control command */
    MID_SM_CTRL_NONE,

    /* gsMIDCtrl.eState, Default state after reset */
    MID_START
};


/******************************************************************************
* Local functions
******************************************************************************/

/***************************************************************************//*!
*
* @brief    MID START state
*
* @details  In this state the rotor is aligned into the d-axis using a
*           single-step voltage alignment.
*           \par
*           Preconditions:
*               - current measurement
*               - enabled current control
*               - DC- bus voltage measurement
*           \par
*           Escape the state:
*           when the alignment is done, which indicated by \ref sMIDAlignment.uw16Active == false
*
* @param   void
*
* @return  none
*
******************************************************************************/
static void MID_StateStart(void)
{
    /* Type the code to do when in the START state */
    /* MID alignment */
    MID_alignment(&sMIDAlignment);

    /* When MID_alignment is done */
    if (sMIDAlignment.uw16Active == false)
    {
        /* set _DONE to switch to following transition state */
        gsMIDCtrl.uiCtrl |= MID_SM_CTRL_START_DONE;
    }
}

/***************************************************************************//*!
*
* @brief    MID PWR_STG_CHARACT state
*
* @details  In this state a Power Stage characterisation is done. More details about
*           characterisation are in \ref PwrStg_characteristic.c
*           \par
*           Preconditions:
*               - current measurement
*               - enabled current control
*               - DC- bus voltage measurement
*
*           \par
*           Escape the state:
*           when the characterisation is done, which indicated by \ref sMIDPwrStgChar.uw16Active == false
*
* @param    void
*
* @return   none
*
******************************************************************************/
static void MID_StatePwrStgCharact(void)
{
    /* Type the code to do when in the PWR_STG_CHARACT state */
    MID_GetTransferCharacteristic(&sMIDPwrStgChar);

    /* If characteristic for the last current was measured (f16TransferCharIndex == number of ) */
    if (sMIDPwrStgChar.uw16Active == false)
    {
        /* set _DONE to switch to following transition state */
        gsMIDCtrl.uiCtrl |= MID_SM_CTRL_PWR_STG_CHARACT_DONE;
    }
}

/***************************************************************************//*!
*
* @brief    MID Rs state
*
* @details  In this state a stator resistance Rs is measured. More details about
*           Rs_measurement are in \ref Rs_measure.c
*           \par
*           Preconditions:
*               - enabled current control
*               - DC- bus voltage measurement
*           \par
*           Escape the state:
*           when the Rs measurement is done, which indicated by \ref sMIDRs.uw16Active == false
*
* @param    void
*
* @return   none
*
******************************************************************************/
static void MID_StateRs(void)
{
    /* Type the code to do when in the RS state */
    /* call Rs measurement routine */
    MID_getRs(&sMIDRs);

    /* when the R_s measurement is finished, set the RS_DONE flag */
    if (sMIDRs.uw16Active == false)
    {
        /* set _DONE to switch to following transition state */
        gsMIDCtrl.uiCtrl |= MID_SM_CTRL_RS_DONE;
    }
}


/***************************************************************************//*!
*
* @brief   MID Ld state

*@details   In this state a stator inductance Ld is measured. Ld is measured using
*           MID_getLs() function. However rotor must be aligned to D-axis and
*           pointers to \ref pf16Ud, \ref pf16Id are passed to the \ref sMIDLs. More details
*           about Ls_measurement are in \ref Ls_measure.c
*           \par
*           Preconditions:
*               - disabled current control -> only voltage control
*               - current transformations Iabc -> Idq are done
*               - DC- bus voltage measurement
*           \par
*           Escape the state:
*           when the Ls measurement is done, which indicated by \ref sMIDLs.uw16Active == false
*
* @param   void
*
* @return  none
*
******************************************************************************/
static void MID_StateLd(void)
{
    /* Type the code to do when in the LS state */

    /* call Rs measurement routine */
    MID_getLs(&sMIDLs);

    /* when the L_s measurement is finished, set the LS_DONE flag */
    if (sMIDLs.uw16Active == false)
    {
        /* Store measured Ls to Ld */
        sMIDLs.f16Ld = sMIDLs.f16Ls;
        sMIDLs.w16ShiftZdMax = sMIDLs.w16ShiftZsMax;
        sMIDLs.w16ShiftLdMax = sMIDLs.w16ShiftLsMax;

        /* set _DONE to switch to following transition state */
        gsMIDCtrl.uiCtrl |= MID_SM_CTRL_LD_DONE;
    }
}


/***************************************************************************//*!
*
* @brief   MID Lq state
*
* @details  In this state a stator inductance Lq is measured. Lq is measured using
*           MID_getLs() function. However rotor must be aligned to D-axis and
*           pointers to \ref pf16Uq, \ref pf16Iq are passed to the \ref sMIDLs.
*           More details about Ls_measurement are in \ref Ls_measure.c
*           \par
*           Preconditions:
*               - disabled current control -> only voltage control
*               - current transformations Iabc -> Idq are done
*               - DC- bus voltage measurement
*           \par
*           Escape the state:
*           when the Ls measurement is done, which indicated by \ref sMIDLs.uw16Active == false
*
* @param   void
*
* @return  none
*
******************************************************************************/
static void MID_StateLq(void)
{
    /* Type the code to do when in the LS state */

    /* call Rs measurement routine */
    MID_getLs(&sMIDLs);

    /* when the L_s measurement is finished, set the LS_DONE flag */
    if (sMIDLs.uw16Active == false)
    {
        /* Store measured Ls to Lq */
        sMIDLs.f16Lq = sMIDLs.f16Ls;
        sMIDLs.w16ShiftZqMax = sMIDLs.w16ShiftZsMax;
        sMIDLs.w16ShiftLqMax = sMIDLs.w16ShiftLsMax;

        /* set _DONE to switch to following transition state */
        gsMIDCtrl.uiCtrl |= MID_SM_CTRL_LQ_DONE;
    }
}

/***************************************************************************//*!
*
* @brief   MID Pp state
*
* @details  In this state a number of pole-pairs is determined.
*           \par
*           Preconditions:
*               - current control
*               - DC- bus voltage measurement
*           \par
*           Escape the state:
*           when the Pp is set by user
*
* @param   void
*
* @return  none
*
******************************************************************************/
static void MID_StatePp(void)
{
    /* Type the code to do when in the PP state */

    /* Call Pp measurement routine */
    MID_getPp(&sMIDPp);

    /* Escape MID_StateKe when measurement ends */
    if(sMIDPp.uw16Active == false)
        gsMIDCtrl.uiCtrl |= MID_SM_CTRL_PP_DONE;
}

/***************************************************************************//*!
*
* @brief   MID Ke state
*
* @details  In this state an electrical constant is measured. Ke is measured using
*           MID_getKe() function. More details about Ke measurement are in \ref Ke_measure.c
*           \par
*           Preconditions:
*               - current control with proper parameters
*               - DC- bus voltage measurement
*           \par
*           Escape the state:
*           when the Ke measurement is done, which indicated by \ref sMIDKe.uw16Active == false
*
* @param   void
*
* @return  none
*
******************************************************************************/
static void MID_StateKe(void)
{
    /* Type the code to do when in the LS state */

    /* When MCAT calculates controllers and Bemf observer */
    if(sMIDKe.uw16MCATObsrvDone == true)
    {
        /* Call Rs measurement routine */
        MID_getKe(&sMIDKe);
        /* Escape MID_StateKe when measurement ends */
        if(sMIDKe.uw16Active == false)
        gsMIDCtrl.uiCtrl |= MID_SM_CTRL_KE_DONE;
    }
}


/***************************************************************************//*!
*
* @brief   MID Stop state
*
* @details When the MID state machine enters the STOP state, measurement is over.
*
* @param   void
*
* @return  none
*
******************************************************************************/
static void MID_StateStop(void)
{
    /* Type the code to do when in the STOP state */

    /*
    * motor parameters measurement is finished, main state machine
    * can proceed with next state
    */
    gsMIDCtrl.uiCtrl |= MID_SM_CTRL_STOP_DONE;
}

/***************************************************************************//*!
*
* @brief   MID START to PWR_STG_CHARACT transition
*
* @param   void
*
* @return  none
*
******************************************************************************/
static void MID_TransStart2PwrStgCharact(void)
{
    /* Type the code to do when going from the START to the PWR_STG_CHARACT state */

    /* enable start of characterisation */
    sMIDPwrStgChar.uw16Active = false;

    /* acknowledge that the state machine can proceed into PWR_STG_CHARACT state */
    gsMIDCtrl.uiCtrl |= MID_SM_CTRL_PWR_STG_CHARACT_ACK;
}

/***************************************************************************//*!
*
* @brief   START to RS transition
*
* @param   void
*
* @return  none
*
******************************************************************************/
static void MID_TransStart2Rs(void)
{
    /* Type the code to do when going from the PWR_STG_CHARACT to the RS state */

    /* enable start of Rs measurement */
    sMIDRs.uw16Active = false;
    sMIDRs.pf16UdErrorLookUp = &(f16TransferCharError[0]);

    /* acknowledge that the state machine can proceed into RS state */
    gsMIDCtrl.uiCtrl |= MID_SM_CTRL_RS_ACK;
}

/***************************************************************************//*!
*
* @brief   START to PP transition
*
* @param   void
*
* @return  none
*
******************************************************************************/
static void MID_TransStart2Pp(void)
{
    /* Type the code to do when going from the LS to the STOP state */
    sMIDPp.uw16Active = false;
    sMIDPp.uw16PpDetermined = false;

    /* Acknowledge that the system can proceed into the STOP state */
    gsMIDCtrl.uiCtrl |= MID_SM_CTRL_PP_ACK;
}

/***************************************************************************//*!
*
* @brief   START to RS transition
*
* @param   void
*
* @return  none
*
******************************************************************************/
static void MID_TransPwrStgCharact2Stop(void)
{
    /* Type the code to do when going from the PWR_STG_CHARACT to the RS state */

    /* acknowledge that the state machine can proceed into RS state */
    gsMIDCtrl.uiCtrl |= MID_SM_CTRL_STOP_ACK;
}

/***************************************************************************//*!
*
* @brief   MID RS to LD transition
*
* @param   void
*
* @return  none
*
******************************************************************************/
static void MID_TransRs2Ld(void)
{
    /* Type the code to do when going from the RS to the LS state */

    /* Pass Ud, Id references to UdReq, Idfbck => measurement in direct axis */
    sMIDLs.pf16UdReq  = pf16Ud;
    sMIDLs.pf16Idfbck = pf16Id;
    *pf16Uq           = FRAC16(0.0);
    *pf16Iq           = FRAC16(0.0);
    sMIDLs.f16Ls      = FRAC16(0.0);

    /* enable start of Ls measurement */
    sMIDLs.uw16Active = false;

    /* Pass value of Rs to Ls strucutre */
    sMIDLs.f16Rs = sMIDRs.f16Rs;
    sMIDLs.w16ShiftRsMax = sMIDRs.w16ShiftRsMax;

    /* acknowledge that the state machine can proceed into LS state */
    gsMIDCtrl.uiCtrl |= MID_SM_CTRL_LD_ACK;
}

/***************************************************************************//*!
*
* @brief   MID LD to LQ transition
*
* @param   void
*
* @return  none
*
******************************************************************************/
static void MID_TransLd2Lq(void)
{
    /* Type the code to do when going from the RS to the LS state */

    /* Pass Ud, Id references to Udfbck, Idfbck => measurement in direct axis */
    sMIDLs.pf16UdReq  = pf16Uq;
    sMIDLs.pf16Idfbck = pf16Iq;
    *pf16Ud           = FRAC16(0.0);
    *pf16Id           = FRAC16(0.0);
    sMIDLs.f16Ls      = FRAC16(0.0);

    /* enable start of Ls measurement */
    sMIDLs.uw16Active = false;

    /* Pass value of Rs to Ls strucutre */
    sMIDLs.f16Rs = sMIDRs.f16Rs;
    sMIDLs.w16ShiftRsMax = sMIDRs.w16ShiftRsMax;

    /* acknowledge that the state machine can proceed into LS state */
    gsMIDCtrl.uiCtrl |= MID_SM_CTRL_LQ_ACK;
}

/***************************************************************************//*!
*
* @brief   LQ to KE transition
*
* @param   void
*
* @return  none
*
******************************************************************************/
static void MID_TransLq2Ke(void)
{
    /* Type the code to do when going from the LS to the STOP state */

    /* Reset Ud voltage during calibration because it wasn't reset in Ls meas */
    *pf16Ud = FRAC16(0.0);
    *pf16Uq = FRAC16(0.0);

    sMIDKe.uw16MCATObsrvDone = false;
    sMIDKe.uw16Active = false;

    /* Acknowledge that the system can proceed into the STOP state */
    gsMIDCtrl.uiCtrl |= MID_SM_CTRL_KE_ACK;
}

/***************************************************************************//*!
*
* @brief   MID KE to STOP transition
*
* @param   void
*
* @return  none
*
******************************************************************************/
static void MID_TransKe2Stop(void)
{
    /* Type the code to do when going from the LS to the STOP state */

    /* Acknowledge that the system can proceed into the STOP state */
    gsMIDCtrl.uiCtrl |= MID_SM_CTRL_STOP_ACK;
}

/***************************************************************************//*!
*
* @brief   MID KE to STOP transition
*
* @param   void
*
* @return  none
*
******************************************************************************/
static void MID_TransPp2Stop(void)
{
    /* Type the code to do when going from the LS to the STOP state */

    /* Acknowledge that the system can proceed into the STOP state */
    gsMIDCtrl.uiCtrl |= MID_SM_CTRL_STOP_ACK;
}

/******************************************************************************
* Global functions
******************************************************************************/
