/*******************************************************************************
*
* Copyright 2014 Freescale Semiconductor, Inc.
*
* This software is owned or controlled by Freescale Semiconductor.
* Use of this software is governed by the Freescale License
* distributed with this Material.
* See the LICENSE file distributed for more details.
*
*
****************************************************************************//*!
*
* @file      MID_def.h
*
* @author    b40558
*
* @date      May-20-2014
*
* @brief     Common header file for measurement routines
*
*
******************************************************************************/
#ifndef _MID_DEF_H_
#define _MID_DEF_H_

/******************************************************************************
* Includes
******************************************************************************/
#include "PMSM_appconfig.h"

/******************************************************************************
* Constants
******************************************************************************/
/* MID Fault numbers */
#define MID_FAULT_NO_MOTOR              (1)
#define MID_FAULT_TOO_HIGH_RS           (2)
#define MID_FAULT_DC_CUR_NOT_REACHED    (4)
#define MID_FAULT_RS_OUT_OF_RANGE       (8)
#define MID_FAULT_LS_OUT_OF_RANGE       (16)
#define MID_FAULT_Z_OUT_OF_RANGE        (32)
#define MID_FAULT_AC_CUR_NOT_REACHED    (64)
#define MID_FAULT_KE_OUT_OF_RANGE       (128)

/* Current controllers' coefficients ensuring slow response for variable parameters */
#define MID_KP_GAIN                     FRAC16(0.619232882253)
#define MID_KP_SHIFT                    (-5)
#define MID_KI_GAIN                     FRAC16(0.923650954675)
#define MID_KI_SHIFT                    (-8)

/* Speed minimal ramp */
#define MID_SPEED_RAMP_UP               FRAC16(0.000060606061)
#define MID_SPEED_RAMP_DOWN             FRAC16(0.000060606061)

/******************************************************************************
* Macros
******************************************************************************/

/******************************************************************************
* Types
******************************************************************************/

/******************************************************************************
* Global variables
******************************************************************************/

/******************************************************************************
* Global functions
******************************************************************************/

/******************************************************************************
* Inline functions
******************************************************************************/

#endif /* _MID_DEF_H_ */
