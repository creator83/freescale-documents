/*******************************************************************************
*
* Copyright 2014 Freescale Semiconductor, Inc.
*
* This software is owned or controlled by Freescale Semiconductor.
* Use of this software is governed by the Freescale License
* distributed with this Material.
* See the LICENSE file distributed for more details.
*
*
****************************************************************************//*!
*
* @file     MID_auxiliary.c
*
* @author   b40558
*
* @date     May-20-2014
*
* @brief    Auxiliary functions needed for identification
*
* @details  ### Details ###
*           \par
*           This file contains auxiliary functions for proper functionality of the measurement.
*
*           \par
*           There is now current alignment function which applies #MID_ALIGN_A1_T::f16CurrentAlign
*           to D-axis for #MID_ALIGN_A1_T::uw16AlignDuration loop cycles.
*
***************************************************************************//*!*/

/******************************************************************************
* Includes
******************************************************************************/
#include "MID_auxiliary.h"

/******************************************************************************
* Global variables
******************************************************************************/
/*
Put instances of global variables here.
 */
/******************************************************************************
* Constants and macros
******************************************************************************/
/*
Put any local-only #define statements here.
 */
#define true  (1)
#define false (0)

/******************************************************************************
* Local types
******************************************************************************/
/*
Put any local-only typedef statements here.
 */
/******************************************************************************
* Local function prototypes
******************************************************************************/
/*
Put any local-only function prototypes here (if needed). All the functions
should be declared static.
 */
/******************************************************************************
* Local variables
******************************************************************************/
/*
Put any local-only variable declarations here. All the variables should be
declared static.
 */
/******************************************************************************
* Local functions
******************************************************************************/
/*
Put code of your local-only static functions here. Each function should have
a pre-code comment describing the function. See exampes in the presentation.
 */
/******************************************************************************
* Global functions
******************************************************************************/
/*
Put code of your global static functions here. Each function should have
a pre-code comment describing the function. See exampes in the presentation.
 */
/***************************************************************************//*!
*
* @brief        MID one-step Current alignment.
*
* @param[in]    *sMIDRs_align
*
* @return       none
*
******************************************************************************/
void MID_alignment(MID_ALIGN_A1_T* sAlignmentFcn)
{
    /* if alignment hasn't started, set the duration of the alignment process */
    if(sAlignmentFcn->uw16Active == false)
    {
        sAlignmentFcn->uw16LoopCounter = sAlignmentFcn->uw16AlignDuration;
        sAlignmentFcn->uw16Active = true;
    }

    /* decrement alignment timer/counter */
    sAlignmentFcn->uw16LoopCounter--;

    /* single position alignment */
    if(sAlignmentFcn->uw16LoopCounter > 0)
    {
        /* require d-axis voltage for an alignment */
        *(sAlignmentFcn->pf16IdReq) = sAlignmentFcn->f16CurrentAlign;
    }
    else
    {
        /* after defined time period set required d-axis current to zero */
        *(sAlignmentFcn->pf16IdReq) = FRAC16(0.0);
        sAlignmentFcn->uw16Active = false;
    }
}
