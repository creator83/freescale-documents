/*******************************************************************************
*
* Copyright 2014 Freescale Semiconductor, Inc.
*
* This software is owned or controlled by Freescale Semiconductor.
* Use of this software is governed by the Freescale License
* distributed with this Material.
* See the LICENSE file distributed for more details.
*
*
****************************************************************************//*!
*
* @file      MID_SM_states.h
*
* @author    b30239
*
* @date      May-20-2014
*
* @brief     Motor parameters identification state machine header file
*
*
******************************************************************************/
#ifndef _MID_SM_STATES_H_
#define _MID_SM_STATES_H_

/******************************************************************************
* Includes
******************************************************************************/
#include "MID_SM_ctrl.h"
#include "MID_auxiliary.h"
#include "Rs_measure.h"
#include "PwrStg_characteristic.h"
#include "Ls_measure.h"
#include "Ke_measure.h"
#include "Pp_measure.h"

/******************************************************************************
* Constants
******************************************************************************/

/******************************************************************************
* Macros
******************************************************************************/

/******************************************************************************
* Types
******************************************************************************/

/******************************************************************************
* Global variables
******************************************************************************/
/* The MID state machine structure declaration */
extern MID_SM_APP_CTRL_T gsMIDCtrl;

/* Measurement global variables */
extern MID_GET_RS_A1_T      sMIDRs;
extern MID_GET_CHAR_A1_T    sMIDPwrStgChar;
extern MID_GET_LS_A1_T      sMIDLs;
extern MID_GET_KE_A1_T      sMIDKe;
extern MID_GET_PP_A1_T      sMIDPp;
extern MID_ALIGN_A1_T       sMIDAlignment;
extern UWord16              uw16FaultMID;
extern UWord16              uw16EnableMeasurement;
extern Frac16*              pf16Ud;
extern Frac16*              pf16Id;
extern Frac16*              pf16Uq;
extern Frac16*              pf16Iq;

/* FMSTR scales */
extern volatile float       fltMIDresistanceScale;
extern volatile float       fltMIDfrequencyScale;
extern volatile float       fltMIDimpedanceScale;
extern volatile float       fltMIDinductanceDScale;
extern volatile float       fltMIDinductanceQScale;
extern volatile float       fltMIDbemfConstScale;

/******************************************************************************
* Global functions
******************************************************************************/

/******************************************************************************
* Inline functions
******************************************************************************/

#endif /* _MID_SM_STATES_ */
