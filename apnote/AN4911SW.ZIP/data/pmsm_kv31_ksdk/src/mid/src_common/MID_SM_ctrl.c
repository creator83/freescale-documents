/*******************************************************************************
*
* Copyright 2014 Freescale Semiconductor, Inc.
*
* This software is owned or controlled by Freescale Semiconductor.
* Use of this software is governed by the Freescale License
* distributed with this Material.
* See the LICENSE file distributed for more details.
*
*
****************************************************************************//*!
*
* @file     MID_SM_ctrl.c
*
* @author   b30239
*
* @date     May-20-2014
*
* @brief    Motor parameters identification State machine control/switching
*
* @details  ### Details ###
*           \par
*           This file controls the state machine by calling state and transition
*           functions which are specified in \ref MID_SM_states.c. The state machine is
*           build on the pointer to a struct of the state machine states pointers.
*           A global struct variable @ref gsMIDCtrl contains items which defines:
*           - ('psState') state of the SM
*           - ('psTrans') transient state of the SM
*           - ('uiCtrl') control variable
*           - ('eState') actual state of the SM
*
*           The variable is defined in the MID_SM_states.c file.
*           \par
*           The state transition is done as follows:
*           * _ _DONE_ - bit of the \ref gsMIDCtrl.uiCtrl is set in the particular _state_
*           when all tasks in that state are done and SM can proceed to next state
*           through transition, ex. \ref MID_SM_CTRL_START_DONE is set in \ref MID_StateStart()
*           * _ _ACK_ - bit of the \ref gsMIDCtrl.uiCtrl is set in the _transition state_,
*           ex. \ref MID_SM_CTRL_PWR_STG_CHARACT_ACK is set in \ref MID_TransStart2PwrStgCharact() .
*           \par
*           Following figure shows how the state machine goes through the states:
*
*           \dot
*           digraph G {
*               rankdir=LR
*               {
*                   Start -> PwrStg_characterisation;
*                   PwrStg_characterisation -> Stop
*                   Start -> measure_Rs;
*                   measure_Rs -> measure_Ld;
*                   measure_Ld -> measure_Lq;
*                   measure_Lq -> measure_Ke;
*                   measure_Ke -> Stop;
*                   Start -> measure_Pp;
*                   measure_Pp -> Stop;
*               }
*           }
*           \enddot
*
******************************************************************************/

/******************************************************************************
* Includes
******************************************************************************/
#include "MID_SM_ctrl.h"

/******************************************************************************
* Constants
******************************************************************************/

/******************************************************************************
* Macros
******************************************************************************/

/******************************************************************************
* Types
******************************************************************************/

/******************************************************************************
* Global variables
******************************************************************************/
UWord16 uw16Calibration;            ///<true => calibration will be done after MID_SM_StateStart
UWord16 uw16ElectricalParameters;   ///<true => measurement of electrical parameters will be done after MID_SM_StateStart
UWord16 uw16PolePairs;              ///<true => number of pole-pairs assistant will start after MID_SM_StateStart

/******************************************************************************
* Local variables
******************************************************************************/

/******************************************************************************
* Local functions
******************************************************************************/

/*------------------------------------
 * Application state machine functions
 * ----------------------------------*/
static void MID_SM_StateStart(MID_SM_APP_CTRL_T *psAppCtrl);
static void MID_SM_StatePwrStgCharact(MID_SM_APP_CTRL_T *psAppCtrl);
static void MID_SM_StateRs(MID_SM_APP_CTRL_T *psAppCtrl);
static void MID_SM_StateLd(MID_SM_APP_CTRL_T *psAppCtrl);
static void MID_SM_StateLq(MID_SM_APP_CTRL_T *psAppCtrl);
static void MID_SM_StatePp(MID_SM_APP_CTRL_T *psAppCtrl);
static void MID_SM_StateKe(MID_SM_APP_CTRL_T *psAppCtrl);
static void MID_SM_StateStop(MID_SM_APP_CTRL_T *psAppCtrl);

/******************************************************************************
* Global functions
******************************************************************************/
/* State machine functions field */
const MID_PFCN_VOID_PSM gMID_SM_STATE_TABLE[8] = {MID_SM_StateStart, MID_SM_StatePwrStgCharact, MID_SM_StateRs, MID_SM_StateLd, MID_SM_StateLq, MID_SM_StatePp, MID_SM_StateKe, MID_SM_StateStop};

/***************************************************************************//*!
*
* @brief   Start state
*
* @param   void
*
* @return  none
*
******************************************************************************/
static void MID_SM_StateStart(MID_SM_APP_CTRL_T *psAppCtrl)
{
    /* call user Start function */
    psAppCtrl -> psState -> MID_Start();

    /* if START_DONE flag is set */
    if ((psAppCtrl -> uiCtrl & MID_SM_CTRL_START_DONE) > 0)
    {
        /* clear state's _ACK & _DONE SM control flags */
        psAppCtrl -> uiCtrl &= ~(MID_SM_CTRL_START_DONE | MID_SM_CTRL_START_ACK);

        /* if uw16Calibration go to PWR_STG_CHARACT state */
        if(uw16Calibration != 0)
        {
            psAppCtrl -> psTrans -> MID_Start2PwrStgCharact();
            psAppCtrl -> eState = MID_PWR_STG_CHARACT;
        }

        /* if uw16ElectricalParameters go to RS state */
        if(uw16ElectricalParameters != 0)
        {
            psAppCtrl -> psTrans -> MID_Start2Rs();
            psAppCtrl -> eState = MID_RS;
        }

        /* if uw16PolePairs go to PP state */
        if(uw16PolePairs != 0)
        {
            psAppCtrl -> psTrans -> MID_Start2Pp();
            psAppCtrl -> eState = MID_PP;
        }
    }
}

/***************************************************************************//*!
*
* @brief   PwrStgChar state
*
* @param   void
*
* @return  none
*
******************************************************************************/
static void MID_SM_StatePwrStgCharact(MID_SM_APP_CTRL_T *psAppCtrl)
{
    /* call user PwrStgCharact function */
    psAppCtrl -> psState -> MID_PwrStgCharact();

    /* if PWR_STG_CHARACT_DONE flag is set */
    if ((psAppCtrl -> uiCtrl & MID_SM_CTRL_PWR_STG_CHARACT_DONE) > 0)
    {
        /* Run transition function */
        psAppCtrl -> psTrans -> MID_PwrStgCharact2Stop();

        if ((psAppCtrl -> uiCtrl & MID_SM_CTRL_PWR_STG_CHARACT_DONE) > 0)
        {
            /* clear state's _ACK & _DONE SM control flags */
            psAppCtrl -> uiCtrl &= ~(MID_SM_CTRL_PWR_STG_CHARACT_DONE | MID_SM_CTRL_PWR_STG_CHARACT_ACK);

            /* next go to Rs state */
            psAppCtrl -> eState = MID_STOP;
        }
    }
}

/***************************************************************************//*!
*
* @brief   Rs state
*
* @param   void
*
* @return  none
*
******************************************************************************/
static void MID_SM_StateRs(MID_SM_APP_CTRL_T *psAppCtrl)
{
    /* call user Rs function */
    psAppCtrl -> psState -> MID_Rs();

    /* if RS_DONE flag is set */
    if ((psAppCtrl -> uiCtrl & MID_SM_CTRL_RS_DONE) > 0)
    {
        /* Run transition function */
        psAppCtrl -> psTrans -> MID_Rs2Ld();

        if ((psAppCtrl -> uiCtrl & MID_SM_CTRL_RS_DONE) > 0)
        {
            /* clear state's _ACK & _DONE SM control flags */
            psAppCtrl -> uiCtrl &= ~(MID_SM_CTRL_RS_DONE | MID_SM_CTRL_RS_ACK);

            /* next go to Ls state */
            psAppCtrl -> eState = MID_LD;
        }
    }
}


/***************************************************************************//*!
*
* @brief   Ld state
*
* @param   void
*
* @return  none
*
******************************************************************************/
static void MID_SM_StateLd(MID_SM_APP_CTRL_T *psAppCtrl)
{
    /* call user Ls function */
    psAppCtrl -> psState -> MID_Ld();

    /* if LD_DONE flag is set */
    if ((psAppCtrl -> uiCtrl & MID_SM_CTRL_LD_DONE) > 0)
    {
        /* Run transition function */
        psAppCtrl -> psTrans -> MID_Ld2Lq();

        if ((psAppCtrl -> uiCtrl & MID_SM_CTRL_LD_DONE) > 0)
        {
            /* clear state's _ACK & _DONE SM control flags */
            psAppCtrl -> uiCtrl &= ~(MID_SM_CTRL_LD_DONE | MID_SM_CTRL_LD_ACK);

            /* Stop state */
            psAppCtrl -> eState = MID_LQ;
        }
    }
}

/***************************************************************************//*!
*
* @brief   Lq state
*
* @param   void
*
* @return  none
*
******************************************************************************/
static void MID_SM_StateLq(MID_SM_APP_CTRL_T *psAppCtrl)
{
    /* call user Ls function */
    psAppCtrl -> psState -> MID_Lq();

    /* if LQ_DONE flag is set */
    if ((psAppCtrl -> uiCtrl & MID_SM_CTRL_LQ_DONE) > 0)
    {
        /* Run transition function */
        psAppCtrl -> psTrans -> MID_Lq2Ke();

        if ((psAppCtrl -> uiCtrl & MID_SM_CTRL_LQ_DONE) > 0)
        {
            /* clear state's _ACK & _DONE SM control flags */
            psAppCtrl -> uiCtrl &= ~(MID_SM_CTRL_LQ_DONE | MID_SM_CTRL_LQ_ACK);

            /* Stop state */
            psAppCtrl -> eState = MID_KE;
        }
    }
}

/***************************************************************************//*!
*
* @brief   Pp state
*
* @param   void
*
* @return  none
*
******************************************************************************/
static void MID_SM_StatePp(MID_SM_APP_CTRL_T *psAppCtrl)
{
    /* call user Ls function */
    psAppCtrl -> psState -> MID_Pp();

    /* if PP_DONE flag is set */
    if ((psAppCtrl -> uiCtrl & MID_SM_CTRL_PP_DONE) > 0)
    {
        /* Run transition function */
        psAppCtrl -> psTrans -> MID_Pp2Stop();

        if ((psAppCtrl -> uiCtrl & MID_SM_CTRL_PP_DONE) > 0)
        {
            /* clear state's _ACK & _DONE SM control flags */
            psAppCtrl -> uiCtrl &= ~(MID_SM_CTRL_PP_DONE | MID_SM_CTRL_PP_ACK);

            /* Stop state */
            psAppCtrl -> eState = MID_STOP;
        }
    }
}

/***************************************************************************//*!
*
* @brief   Ke state
*
* @param   void
*
* @return  none
*
******************************************************************************/
static void MID_SM_StateKe(MID_SM_APP_CTRL_T *psAppCtrl)
{
    /* call user Ls function */
    psAppCtrl -> psState -> MID_Ke();

    /* if KE_DONE flag is set */
    if ((psAppCtrl -> uiCtrl & MID_SM_CTRL_KE_DONE) > 0)
    {
        /* Run transition function */
        psAppCtrl -> psTrans -> MID_Ke2Stop();

        if ((psAppCtrl -> uiCtrl & MID_SM_CTRL_KE_DONE) > 0)
        {
            /* clear state's _ACK & _DONE SM control flags */
            psAppCtrl -> uiCtrl &= ~(MID_SM_CTRL_KE_DONE | MID_SM_CTRL_KE_ACK);

            /* Stop state */
            psAppCtrl -> eState = MID_STOP;
        }
    }
}


/***************************************************************************//*!
*
* @brief   Stop state
*
* @param   void
*
* @return  none
*
******************************************************************************/
static void MID_SM_StateStop(MID_SM_APP_CTRL_T *psAppCtrl)
{
    /* call user Stop function */
    psAppCtrl -> psState -> MID_Stop();
}


/******************************************************************************
* Inline functions
******************************************************************************/


