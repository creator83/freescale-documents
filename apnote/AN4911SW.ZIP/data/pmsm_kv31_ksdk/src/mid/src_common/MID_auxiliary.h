/*******************************************************************************
*
* Copyright 2014 Freescale Semiconductor, Inc.
*
* This software is owned or controlled by Freescale Semiconductor.
* Use of this software is governed by the Freescale License
* distributed with this Material.
* See the LICENSE file distributed for more details.
*
*
****************************************************************************//*!
*
* @file      MID_auxiliary.h
*
* @author    b40558
*
* @date      May-20-2014
*
* @brief     Auxiliary functions needed for identification header file
*
*******************************************************************************
*
* Detailed Description of the file.
*
***************************************************************************//*!*/

#ifndef RS_TEMP_FUNCTIONS_H_
#define RS_TEMP_FUNCTIONS_H_

/******************************************************************************
* Includes
******************************************************************************/
/*
Put your #include directives here. Be aware of that using an #include from a
header file makes your application worse readable.
Remove this section if empty
 */

#include "SWLIBS_Defines.h"
#include "SWLIBS_Typedefs.h"

/******************************************************************************
* Constants
******************************************************************************/
/*
Put your macro constants here (#define)
 */

/******************************************************************************
* Macros
******************************************************************************/
/*
Put yout macro code here (#define with parameters)
 */

/******************************************************************************
* Types
******************************************************************************/
/*
Put your shared typedef statements here
 */
/*Structure for Alignment parameters passing*/
typedef struct
{
    UWord16         uw16Active;         ///<Inidicates whether Rs is being measured (true) or not (false)
    UWord16         uw16LoopCounter;    ///<Serves for timing to determine e.g. 600ms
    Frac16*         pf16IdReq;          ///<Pointer to required current Id (input to controllers)
    Frac16          f16CurrentAlign;    ///<Alignment current
    UWord16         uw16AlignDuration;  ///<Alignment duration
}MID_ALIGN_A1_T;

/******************************************************************************
* Global variables
******************************************************************************/
/*
Put your extern references to the application global varables here
 */

/******************************************************************************
* Global functions
******************************************************************************/
#ifdef __cplusplus
extern "C" {
#endif

extern void MID_alignment(MID_ALIGN_A1_T* sAlignmentFcn);

#ifdef __cplusplus
}
#endif

/******************************************************************************
* Inline functions
******************************************************************************/
/*
Put code of your inline functions here.
 */

#endif /* RS_TEMP_FUNCTIONS_H_ */
