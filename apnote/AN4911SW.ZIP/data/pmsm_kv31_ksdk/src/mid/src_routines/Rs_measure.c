/*******************************************************************************
*
* Copyright 2014 Freescale Semiconductor, Inc.
*
* This software is owned or controlled by Freescale Semiconductor.
* Use of this software is governed by the Freescale License
* distributed with this Material.
* See the LICENSE file distributed for more details.
*
*
****************************************************************************//*!
*
* @file     Rs_measure.c
*
* @author   b40558
*
* @date     May-20-2014
*
* @brief    Stator resistance measurement routine
*
* @details  ### Details ###
*           \par
*           Before function #MID_getRs call current loop has to be enabled and
*           current controllers are calculated from \f$R_S = 6.4\Omega\f$,
*           \f$L_d = L_q = 12mH\f$, \f$F0 = 65Hz\f$, \f$ksi = 0.707\f$.
*           These values ensure slow controller response to avoid instability
*           of the whole system.
*           \par
*           The function applies measuring current #MID_GET_RS_A1_T::f16IdMeas
*           for 600ms. This is long enough to wait until phase current \f$I_{Dfbck}\f$
*           stabilizes
*           \par
*           After 600ms \f$I_{Dfbck}\f$ and \f$U_{Dreq}\f$ are read. \f$I_{Dfbck}\f$
*           and \f$U_{Dreq}\f$ might be quite noisy so it is possible to filter them
*           and point to the filtered values. Example of the measuring signal is in
*           \ref Figure_01
*
*           \anchor Figure_01
*           \image latex transient1.eps "Measuring signal" width=10cm
*           \image html transient1.jpg "Measuring signal"
*
*           \par
*           Then \f$U_{Dreq}\f$ is corrected by \f$U_{err}\f$ according to the LookUp
*           table specified in #GET_RS_STRUCT::f16ErrorLookUp[22].
*
*           \anchor eq1_Rs_measure
*           \f[
*           U_{Dcorrect} = U_{Dreq}-U_{err}
*           \f]
*           \par
*           \f$U_{err}\f$ is picked from #MID_GET_RS_A1_T::pf16UdErrorLookUp based on
*           phase current \f$I_{Dfbck}\f$ as shown in \ref Figure_02. It is possible
*           to use default LookUp data which apply to FSL HV Power Stage,
*           \f$U_{DCbus}=325V\f$, \f$T_D=1.5us\f$ and \f$f_{PWM}=20kHz\f$
*
*           \anchor Figure_02
*           \image latex LookUp1.eps "Uerr LookUp table" width=10cm
*           \image html LookUp1.jpg "Uerr LookUp table"
*
*           \par
*           After \f$U_{Dreq}\f$ compensation \f$R_S\f$ is calculated
*
*           \anchor eq1_Rs_measure
*           \f[
*           R_S = \frac{U_{Dcorrect}}{I_{Dfbck}}
*           \f]
*           \par
*           \f$R_S\f$ measurement takes 600ms. Maximal \f$R_S\f$ is limited to
*           2000\f$\Omega\f$ by \f$R_S\f$ scale.
*
*           ### Faults ###
*           \par
*           If the function detects any unusual state e.g. no motor is connected,
*           the function returns number of a fault. The fault can be recognized
*           according to its number in the following table:
*
*           \par
*           | Fault Number HEX | Fault Description |
*           | ----------------:| :---- |
*           | 0x0001           | No motor connected|
*           | 0x0004           | Rs measuring current not reached|
*           | 0x0008           | Rs is out of scaling range|
*
*
***************************************************************************//*!*/

/******************************************************************************
* Includes
******************************************************************************/
#include "Rs_measure.h"
#include "mlib.h"
#include "gflib.h"

/******************************************************************************
* External objects
******************************************************************************/
/*
In case the declarations you need to use are not put in any header file you
put the "function prototypes" and "extern" variables here.

However, this is not a recommended practise - allowed only if the code you are
referrencing is comming from 3rd party. In your application, you _should_
declare your globals in a header file and include it in any .c file which
consumes them.

Remove this section if empty.
*/

/******************************************************************************
* Global variables
******************************************************************************/
/*
Put instances of global variables here.
 */

/*Default transfer characteristics LookUp for FSL HV PowerStage and 325V DCbus*/
Frac16	f16TransferCharError[] =
{
-1859, -1857, -1869, -1882, -1883, -1887, -1878, -1868, -1865, -1870,
-1873, -1865, -1869, -1862, -1860, -1846, -1847, -1835, -1823, -1816,
-1816, -1796, -1783, -1758, -1736, -1713, -1709, -1663, -1594, -1494,
-1373, -1063, -302,   275,   1106,  1459,  1547,  1635,  1705,  1722,
 1731,  1744,  1783,  1804,  1823,  1821,  1835,  1836,  1847,  1865,
 1869,  1875,  1866,  1864,  1869,  1878,  1899,  1899,  1904,  1891,
 1886,  1890,  1896,  1908,  1909,
};

/******************************************************************************
* Constants and macros
******************************************************************************/
/*
Put any local-only #define statements here.
 */
#define true  (1)
#define false (0)

/******************************************************************************
* Local types
******************************************************************************/
/*
Put any local-only typedef statements here.
 */
/******************************************************************************
* Local function prototypes
******************************************************************************/
/*
Put any local-only function prototypes here (if needed). All the functions
should be declared static.
 */
/******************************************************************************
* Local variables
******************************************************************************/
/*
Put any local-only variable declarations here. All the variables should be
declared static.
 */
/******************************************************************************
* Local functions
******************************************************************************/
/*
Put code of your local-only static functions here. Each function should have
a pre-code comment describing the function. See exampes in the presentation.
 */
/******************************************************************************
* Global functions
******************************************************************************/
/*
Put code of your global static functions here. Each function should have
a pre-code comment describing the function. See exampes in the presentation.
 */

/*******************************************************************************
 * Implementation variant: Kinetis and FSL ESL Kinetis libraries
 ******************************************************************************/
/***************************************************************************//*!
*
* @brief        Rs estimation function
*
* @param[in]    *sRsMeasFcn   input structure of type #MID_GET_RS_A1_T for passing
*               all necessary parameters.
*
* @return       none
*
******************************************************************************/
void MID_getRs(MID_GET_RS_A1_T* sRsMeasFcn)
{
    Frac16              f16Ud, f16Id;
    Frac16              f16UdCorrect;
    Frac32              f32UdCorrect, f32UdCorrectShifted;
    Frac32              f32Rs;
    Frac16              f16Id_rescaled;
    GFLIB_LUT1D_T_F16   sLookUpLeft = GFLIB_LUT1D_DEFAULT_F16;

    /* ShamOffset represents number of LUT elements as 2^ShamOffset +1 */
    sLookUpLeft.u16ShamOffset = CHAR_NUMBER_OF_POINTS_BASE;
    /* we want to point into the middle of the LUT to have input fractional range of <-0.5;0.5> */
    sLookUpLeft.pf16Table = sRsMeasFcn->pf16UdErrorLookUp + CHAR_NUMBER_OF_POINTS_HALF;

    /* Initialisation */
    if(sRsMeasFcn->uw16Active == 0)
    {
        sRsMeasFcn->uw16Active      = true;
        sRsMeasFcn->uw16LoopCounter = 0;
        sRsMeasFcn->f16Rs           = FRAC16(0.0);
        sRsMeasFcn->w16RescaleIdLUTShift = K_I_RESCALE_LUT_SHIFT;
        sRsMeasFcn->f16RescaleIdLUTGain  = K_I_RESCALE_LUT_GAIN;

        /* Set the measuring current Id_meas*/
        *(sRsMeasFcn->pf16IdReq) = sRsMeasFcn->f16IdMeas;
    }

    /* LoopCounter for time keeping */
    sRsMeasFcn->uw16LoopCounter++;

    /* After 600ms start calculation */
    if(sRsMeasFcn->uw16LoopCounter == TIME_1200MS)
    {
        /* store actual measured current and required voltage for Rs calculation */
        f16Id = *(sRsMeasFcn->pf16Idfbck);
        f16Ud = *(sRsMeasFcn->pf16UdReq);

        /* Set required current to zero */
        *(sRsMeasFcn->pf16IdReq) = FRAC16(0.0);

        /* Rescale Id to frac <-0.5;0.5) */
        f16Id_rescaled = MLIB_ShBi_F16(MLIB_Mul_F16(sRsMeasFcn->f16RescaleIdLUTGain, f16Id), sRsMeasFcn->w16RescaleIdLUTShift);

        /* Calculate corrected voltage as a subtraction of the required voltage and the compensation voltage from the LUT */
        f16UdCorrect = MLIB_Sub_F16(f16Ud, GFLIB_Lut1D_F16(f16Id_rescaled, &sLookUpLeft));

        /* Calculate Rs from Ud_correct and Id */
        /* float eq. Rs = UdCorrect / Idfbck */
        /* frac  eq. f16Rs = (f16UdCorrect >> K_RS_MAX_SHIFT) / f16Idfbck  */
        f32UdCorrect = MLIB_ShL_F32((Frac32)f16UdCorrect, 16);

        /* Set the w16ShiftRsMax to -16 */
        sRsMeasFcn->w16ShiftRsMax = -16;

        /* Divide U/I and always increase w16ShiftRsMax until the Rs result is positive and f32UdCorrectShifted is not saturated */
        do
        {
            sRsMeasFcn->w16ShiftRsMax++;
            f32UdCorrectShifted = MLIB_ShBiSat_F32(f32UdCorrect, -sRsMeasFcn->w16ShiftRsMax);
            f32Rs = MLIB_DivSat_F32(f32UdCorrectShifted, MLIB_ShL_F32((Frac32)f16Id, 16));

        }while((f32Rs >= FRAC32(1.0)) || (f32UdCorrectShifted >= FRAC32(1.0)));

        /* Return Frac16 inductance */
        sRsMeasFcn->f16Rs = (Frac16)MLIB_ShR_F32(f32Rs, 16);

        /* Set Id_req to zero */
        *(sRsMeasFcn->pf16IdReq) = FRAC16(0.0);

        /* Check Faults */
        /* Check if motor is connected */
        if(MLIB_Abs_F16(*(sRsMeasFcn->pf16Idfbck)) < K_I_50MA)
            uw16FaultMID |= MID_FAULT_NO_MOTOR;

        /* Check if Rs is negative or saturated*/
        if(sRsMeasFcn->f16Rs < FRAC16(0.0) || sRsMeasFcn->f16Rs == FRAC16(1.0))
            uw16FaultMID |= MID_FAULT_RS_OUT_OF_RANGE;

        /* Check if measuring current was reached */
        if(*(sRsMeasFcn->pf16Idfbck) < MLIB_Sub_F16(sRsMeasFcn->f16IdMeas, K_I_50MA))
            uw16FaultMID |= MID_FAULT_DC_CUR_NOT_REACHED;
    }

    // Wait additional 600ms to stabilize Id at 0A
    // Exit the function after 1200ms
    if(sRsMeasFcn->uw16LoopCounter > TIME_2400MS)
    {
        sRsMeasFcn->uw16Active = false;
    }
}
