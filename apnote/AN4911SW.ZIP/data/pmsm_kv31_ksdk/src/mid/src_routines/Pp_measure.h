/*******************************************************************************
*
* Copyright 2014 Freescale Semiconductor, Inc.
*
* This software is owned or controlled by Freescale Semiconductor.
* Use of this software is governed by the Freescale License
* distributed with this Material.
* See the LICENSE file distributed for more details.
*
*
****************************************************************************//*!
*
* @file      Pp_measure.h
*
* @author    b40558
*
* @date      May-20-2014
*
* @brief     Number o pole-pairs measurement assistant header file
*
*******************************************************************************
*
* This header file defines input structure for Ls measurement and constant
* macros.
*
***************************************************************************//*!*/

#ifndef PP_MEASURE_H_
#define PP_MEASURE_H_

/******************************************************************************
* Includes
******************************************************************************/
/*
Put your #include directives here. Be aware of that using an #include from a
header file makes your application worse readable.
Remove this section if empty
 */
#include "MID_def.h"


#include "SWLIBS_Defines.h"
#include "SWLIBS_Typedefs.h"
#include "gflib.h"

/******************************************************************************
* Constants
******************************************************************************/
/*
Put your macro constants here (#define)
 */

/******************************************************************************
* Macros
******************************************************************************/
/*
Put your macro code here (#define with parameters)
 */

/******************************************************************************
* Types
******************************************************************************/
/*
Put your shared typedef statements here
 */

/*Structure for PpMeasure parameters passing*/

typedef struct
{
    UWord16                     uw16Active;         ///<Indicates whether Ke is being measured (true) or not (false)
    UWord16                     uw16PpDetermined;   ///<Indicates whether the user already set pp in MCAT (true) or not yet (false)
    UWord16                     uw16WaitingSteady;  ///<Indicates that motor is waiting in steady state (when electrical position is zero)
    UWord16                     uw16LoopCounter;    ///<Serves for timing to determine e.g. 300ms
    Frac16*                     pf16PosEl;          ///<Pointer to electrical position for Park transformations
    Frac16*                     pf16IdReq;          ///<Pointer to required current Id (PI current controller's input)
    Frac16                      f16PosElCurrent;    ///<Current value of electrical position
    Frac16                      f16PosElLast;       ///<Last value of electrical position
    Frac16                      f16IdReqOpenLoop;   ///<Openloop current
    Frac16                      f16SpeedElReq;      ///<Required Electrical Speed
    Frac16                      f16SpeedElRamp;     ///<Ramped f16SpeedElReq, this speed is integrated to get position
    GFLIB_RAMP_T_F16            sSpeedElRampParam;  ///<Ramp Up + Down coefficients for f16Speed
    GFLIB_INTEGRATOR_TR_T_F16   sSpeedIntegrator;   ///<Speed integrator coefficients
}MID_GET_PP_A1_T;
/******************************************************************************
* Global variables
******************************************************************************/
/*
Put your extern references to the application global varables here
 */
extern UWord16  uw16FaultMID;

/******************************************************************************
* Global functions
******************************************************************************/
#ifdef __cplusplus
extern "C" {
#endif

extern void MID_getPp(MID_GET_PP_A1_T* sKeMeasFcn);

#ifdef __cplusplus
}
#endif

/******************************************************************************
* Inline functions
******************************************************************************/
/*
Put code of your inline functions here.
Remove this section if empty
 */

#endif /* PP_MEASURE_H_ */
