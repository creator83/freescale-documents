/*******************************************************************************
*
* Copyright 2014 Freescale Semiconductor, Inc.
*
* This software is owned or controlled by Freescale Semiconductor.
* Use of this software is governed by the Freescale License
* distributed with this Material.
* See the LICENSE file distributed for more details.
*
*
****************************************************************************//*!
*
* @file      Ls_measure.h
*
* @author    b40558
*
* @date      May-20-2014
*
* @brief     Stator inductance measurement routine header file
*
*******************************************************************************
*
* This header file defines input structure for Ls measurement and constant
* macros.
*
***************************************************************************//*!*/

#ifndef LS_MEASURE_H_
#define LS_MEASURE_H_

/******************************************************************************
* Includes
******************************************************************************/
/*
Put your #include directives here. Be aware of that using an #include from a
header file makes your application worse readable.
Remove this section if empty
 */
#include "MID_def.h"


#include "SWLIBS_Defines.h"
#include "SWLIBS_Typedefs.h"

/******************************************************************************
* Constants
******************************************************************************/
/*
Put your macro constants here (#define)
 */

/******************************************************************************
* Macros
******************************************************************************/
/*
Put your macro code here (#define with parameters)
 */

/******************************************************************************
* Types
******************************************************************************/
/*
Put your shared typedef statements here
 */
/*Structure for RsMeasure parameters passing*/
typedef struct
{
    UWord16     uw16Active;             ///<Inidicates whether Ls is being measured (true) or not (false)
    UWord16     uw16LoopCounter;        ///<Serves for timing to determine e.g. 300ms
    Word16      w16AmplitudeOK;         ///<Indicates that amplitude of the measuring signal was set
    Word16      w16FrequencyOK;         ///<Indicates that frequency of the measuring signal was set
    Frac16*     pf16UdReq;              ///<Pointer to required voltage Ud which is applied to the motor
    Frac16*     pf16Idfbck;             ///<Pointer to actual real measured current Id
    Frac16      f16FreqStart;           ///<Starting measuring frequency
    Frac16      f16FreqDecrement;       ///<Frequency decrement when tuning the measuring signal
    Frac16      f16FreqMin;             ///<Minimal measuring frequency
    Frac16      f16FreqActual;          ///<Actual Measuring Frequency
    Frac16      f16Angle;               ///<Angle for generating the measuring sine signal
    Frac16      f16AngleIncrement;      ///<Angle increment for generating the measuring sine signal
    Frac16      f16AngleIncrementConst; ///<Constant for calculating f16MeasAngleIncrement from f16MeasFreq
    Frac16      f16IdAmplitudeReq;      ///<Required amplitude of measuring sine current
    Frac16      f16IdAmplitude;         ///<Amplitude of measuring sine current
    Frac16      f16UdMax;               ///<Maximal amplitude of measuring voltage set as 1/2 DCbus before measurement
    Frac16      f16UdAmplitude;         ///<Amplitude of measuring sine voltage
    Frac16      f16UdIncrement;         ///<Voltage increment when tuning the measuring signal
    Frac16      f16Rs;                  ///<Measured Rs set before measurement
    Frac16      f16Ls;                  ///<Measured Ls return
    Frac16      f16Ld;                  ///<For storage Ld
    Frac16      f16Lq;                  ///<For storage Lq
    Word16      w16ShiftRsMax;          ///<Shift used when calculating R=U/I, the shift also expresses by how many bit is basic resistance scale extended
    Word16      w16ShiftZsMax;          ///<Shift used when calculating Z=U/I, the shift also expresses by how many bit is basic impedance scale extended
    Word16      w16ShiftZdMax;          ///<Shift used when calculating Z=U/I, the shift also expresses by how many bit is basic impedance scale extended
    Word16      w16ShiftZqMax;          ///<Shift used when calculating Z=U/I, the shift also expresses by how many bit is basic impedance scale extended
    Word16      w16ShiftLsMax;          ///<Shift used when calculating Ls=Zs/f, the shift also expresses by how many bit is basic inductance scale extended
    Word16      w16ShiftLdMax;          ///<Shift used when calculating Ld=Zd/f, the shift also expresses by how many bit is basic inductance scale extended
    Word16      w16ShiftLqMax;          ///<Shift used when calculating Lq=Zq/f, the shift also expresses by how many bit is basic inductance scale extended
}MID_GET_LS_A1_T;

/******************************************************************************
* Global variables
******************************************************************************/
/*
Put your extern references to the application global varables here
 */
extern UWord16  uw16FaultMID;

/******************************************************************************
* Global functions
******************************************************************************/
#ifdef __cplusplus
extern "C" {
#endif

extern void MID_getLs(MID_GET_LS_A1_T* sLdMeasFcn);

#ifdef __cplusplus
}
#endif

/******************************************************************************
* Inline functions
******************************************************************************/
/*
Put code of your inline functions here.
Remove this section if empty
 */

#endif /* LS_MEASURE_H_ */
