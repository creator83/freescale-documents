/*******************************************************************************
*
* Copyright 2014 Freescale Semiconductor, Inc.
*
* This software is owned or controlled by Freescale Semiconductor.
* Use of this software is governed by the Freescale License
* distributed with this Material.
* See the LICENSE file distributed for more details.
*
*
****************************************************************************//*!
*
* @file     Ke_measure.c
*
* @author   b40558
*
* @date     May-20-2014
*
* @brief    BackEMF constant measurement routine
*
* @details	### Details ###
*           \par
*           Function #MID_getKe measures motor BackEMF constant using Bemf Observer.
*           The observer's parameters must be calculated in advance e.g. using MCAT.
*           Be aware that inaccuracy in previous Rs, Ld, Lq measurements causes inaccuracy
*           in Bemf constant measurement.
*           \par
*           Connected motor is spun with openloop method to #MID_GET_KE_A1_T::f16SpeedElReq
*           Currend is controlled to #MID_GET_KE_A1_T::f16IdReqOpenLoop. #MID_GET_KE_A1_T::f16SpeedElReq
*           is ramped to #MID_GET_KE_A1_T::f16SpeedElRamp. When #MID_GET_KE_A1_T::f16SpeedElRamp
*           reaches #MID_GET_KE_A1_T::f16SpeedElReq spinning continues at constant speed
*           for another 2.4s. Bemf voltages in d-q coordinates provided by Bemf observer
*           are filtered. After the 2.4s time total Bemf voltage is calculated:
*
*           \anchor eq1_Total_Bemf_voltage
*           \f[
*           U_{Bemf} = sqrt(U_{BemfD}^2+U_{BemfQ}^2)
*           \f]
*           \par
*           Then Bemf constant is calculated:
*           \anchor eq1_Bemf_constant
*           \f[
*           ke = U_{Bemf}/N_{req}
*           \f]
*           \par
*           where \f$N_{req}\f$ is #MID_GET_KE_A1_T::f16SpeedElReq.
***************************************************************************//*!*/

/******************************************************************************
* Includes
******************************************************************************/
#include "Ke_measure.h"
#include "mlib.h"
#include "gflib.h"

/******************************************************************************
* External objects
******************************************************************************/
/*
In case the declarations you need to use are not put in any header file you
put the "function prototypes" and "extern" variables here.

However, this is not a recommended practise - allowed only if the code you are
referrencing is comming from 3rd party. In your application, you _should_
declare your globals in a header file and include it in any .c file which
consumes them.

Remove this section if empty.
*/


/******************************************************************************
* Global variables
******************************************************************************/
/*
Put instances of global variables here.
 */

/******************************************************************************
* Constants and macros
******************************************************************************/
/*
Put any local-only #define statements here.
 */
#define true  (1)
#define false (0)

/******************************************************************************
* Local types
******************************************************************************/
/*
Put any local-only typedef statements here.
 */
/******************************************************************************
* Local function prototypes
******************************************************************************/
/*
Put any local-only function prototypes here (if needed). All the functions
should be declared static.
 */
/******************************************************************************
* Local variables
******************************************************************************/
/*
Put any local-only variable declarations here. All the variables should be
declared static.
 */
/******************************************************************************
* Local functions
******************************************************************************/
/*
Put code of your local-only static functions here. Each function should have
a pre-code comment describing the function. See exampes in the presentation.
 */
/******************************************************************************
* Global functions
******************************************************************************/
/*
Put code of your global static functions here. Each function should have
a pre-code comment describing the function. See exampes in the presentation.
 */

/*******************************************************************************
 * Implementation variant: Kinetis and FSL ESL Kinetis libraries
 ******************************************************************************/
/***************************************************************************//*!
*
* @brief   Ls estimation function
*
* @param[in]  *sLdMeasFcn   input structure of type #MID_GET_LS_A1_T for passing
*                           all necessary parameters.
*
* @return  none
*
******************************************************************************/
void MID_getKe(MID_GET_KE_A1_T* sKeMeasFcn)
{
    Frac32 f32EdFilt, f32EqFilt;
    Frac32 f32EdFiltSquare, f32EqFiltSquare;
    Frac32 f32Etotal, f32EtotalShifted, f32SpeedElReq, f32Ke;

    /* Initialisation */
    if(sKeMeasFcn->uw16Active == false)
    {
        sKeMeasFcn->sSpeedElRampParam.f16RampUp     = MID_SPEED_RAMP_UP;
        sKeMeasFcn->sSpeedElRampParam.f16RampDown   = MID_SPEED_RAMP_DOWN;
        sKeMeasFcn->sSpeedIntegrator.f32State       = FRAC32(0.0);
        sKeMeasFcn->sEdMA32Filter.u16NSamples       = 10;
        sKeMeasFcn->sEdMA32Filter.f32Acc            = FRAC32(0.0);
        sKeMeasFcn->sEqMA32Filter.u16NSamples       = 10;
        sKeMeasFcn->sEqMA32Filter.f32Acc            = FRAC32(0.0);

        sKeMeasFcn->uw16Active = true;
        sKeMeasFcn->uw16LoopCounter = 0;
        sKeMeasFcn->f16SpeedElRamp = FRAC16(0.0);
    }
    /* Set Id required */
    *(sKeMeasFcn->pf16IdReq) = sKeMeasFcn->f16IdReqOpenLoop;
    /* Ramp electrical speed */
    sKeMeasFcn->f16SpeedElRamp = GFLIB_Ramp_F16(sKeMeasFcn->f16SpeedElReq, &sKeMeasFcn->sSpeedElRampParam);
    /* Integrate electrical speed to get electrical position */
    *sKeMeasFcn->pf16PosEl = GFLIB_IntegratorTR_F16(sKeMeasFcn->f16SpeedElRamp, &sKeMeasFcn->sSpeedIntegrator);

    /* Bemf filtering */
    f32EdFilt = GDFLIB_FilterMA_F32(*(sKeMeasFcn->pf32Ed), &sKeMeasFcn->sEdMA32Filter);
    f32EqFilt = GDFLIB_FilterMA_F32(*(sKeMeasFcn->pf32Eq), &sKeMeasFcn->sEqMA32Filter);

    if(sKeMeasFcn->f16SpeedElRamp == sKeMeasFcn->f16SpeedElReq)
    {
        sKeMeasFcn->uw16LoopCounter++;

        if(sKeMeasFcn->uw16LoopCounter > TIME_2400MS)
        {
            /* Total Bemf calculation */
            f32EdFiltSquare = MLIB_Mul_F32(f32EdFilt, f32EdFilt);
            f32EqFiltSquare = MLIB_Mul_F32(f32EqFilt, f32EqFilt);
            f32Etotal = GFLIB_Sqrt_F32(MLIB_Add_F32(f32EdFiltSquare, f32EqFiltSquare));

            /* Ke calculation */
            f32Etotal = MLIB_ShR_F32(f32Etotal, sKeMeasFcn->w16ShiftKeMax);
            f32SpeedElReq = MLIB_ShL_F32((Frac32)sKeMeasFcn->f16SpeedElReq, 16);

            /* Set the w16ShiftRsMax to -1 */
            sKeMeasFcn->w16ShiftKeMax = -1;

            /* Divide U/I and always increase w16ShiftRsMax until the Rs result is positive and f32UdCorrectShifted is not saturated */
            do
            {
                sKeMeasFcn->w16ShiftKeMax++;
                f32EtotalShifted = MLIB_ShBiSat_F32(f32Etotal, -sKeMeasFcn->w16ShiftKeMax);
                f32Ke = MLIB_DivSat_F32(f32EtotalShifted, f32SpeedElReq);

            }while(f32Ke >= FRAC32(1.0) || f32EtotalShifted >= FRAC32(1.0));
            //while(f32Ke >= FRAC32(1.0) || f32EtotalShifted >= FRAC32(1.0));

            /* Return Frac16 inductance */
            sKeMeasFcn->f16Ke = (Frac16)MLIB_ShR_F32(f32Ke, 16);

            /* Check Faults */
            /* Check if Ke is negative or saturated*/
            if(sKeMeasFcn->f16Ke < FRAC16(0.0) || sKeMeasFcn->f16Ke == FRAC16(1.0))
                uw16FaultMID |= MID_FAULT_KE_OUT_OF_RANGE;

            /* When finished exit the function */
            sKeMeasFcn->uw16Active = false;
        }
    }
}
