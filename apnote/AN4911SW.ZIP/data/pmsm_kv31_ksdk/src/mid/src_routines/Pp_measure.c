/*******************************************************************************
*
* Copyright 2014 Freescale Semiconductor, Inc.
*
* This software is owned or controlled by Freescale Semiconductor.
* Use of this software is governed by the Freescale License
* distributed with this Material.
* See the LICENSE file distributed for more details.
*
*
****************************************************************************//*!
*
* @file     Pp_measure.c
*
* @author   b40558
*
* @date     May-20-2014
*
* @brief    Number of pole-pairs measurement assistant
*
* @details	### Details ###
*           \par
*           Function #MID_getPp runs number of pole-pairs assistant which helps with
*           determining the number of pole-pairs.
*
*           \par
*           This routine conltrols Id to #MID_GET_KE_A1_T::f16IdReqOpenLoop and performs
*           one elctrical revolution (from -180 to 180 deg). Then waits for 2.4s and
*           performs another revolution again and again. Number of pole-pairs is determined
*           as number of stable positions per one mechanical revolution.
***************************************************************************//*!*/

/******************************************************************************
* Includes
******************************************************************************/
#include "Pp_measure.h"
#include "mlib.h"
#include "gflib.h"
#include "aclib.h"

/******************************************************************************
* External objects
******************************************************************************/
/*
In case the declarations you need to use are not put in any header file you
put the "function prototypes" and "extern" variables here.

However, this is not a recommended practise - allowed only if the code you are
referrencing is comming from 3rd party. In your application, you _should_
declare your globals in a header file and include it in any .c file which
consumes them.

Remove this section if empty.
*/

/******************************************************************************
* Global variables
******************************************************************************/
/*
Put instances of global variables here.
 */
/******************************************************************************
* Constants and macros
******************************************************************************/
/*
Put any local-only #define statements here.
 */
#define true  (1)
#define false (0)

/******************************************************************************
* Local types
******************************************************************************/
/*
Put any local-only typedef statements here.
 */
/******************************************************************************
* Local function prototypes
******************************************************************************/
/*
Put any local-only function prototypes here (if needed). All the functions
should be declared static.
 */
/******************************************************************************
* Local variables
******************************************************************************/
/*
Put any local-only variable declarations here. All the variables should be
declared static.
 */
/******************************************************************************
* Local functions
******************************************************************************/
/*
Put code of your local-only static functions here. Each function should have
a pre-code comment describing the function. See exampes in the presentation.
 */
/******************************************************************************
* Global functions
******************************************************************************/
/*
Put code of your global static functions here. Each function should have
a pre-code comment describing the function. See exampes in the presentation.
 */

/*******************************************************************************
 * Implementation variant: Kinetis and FSL ESL Kinetis libraries
 ******************************************************************************/
/***************************************************************************//*!
*
* @brief   Ls estimation function
*
* @param[in]  *sLdMeasFcn   input structure of type #MID_GET_LS_A1_T for passing
*                           all necessary parameters.
*
* @return  none
*
******************************************************************************/
void MID_getPp(MID_GET_PP_A1_T* sPpMeasFcn)
{
    /* Initialisation */
    if(sPpMeasFcn->uw16Active == false)
    {
        sPpMeasFcn->sSpeedElRampParam.f16RampUp   = MID_SPEED_RAMP_UP;
        sPpMeasFcn->sSpeedElRampParam.f16RampDown = MID_SPEED_RAMP_DOWN;
        sPpMeasFcn->sSpeedIntegrator.f16C1        = SCALAR_INTEG_GAIN;
        sPpMeasFcn->sSpeedIntegrator.u16NShift    = SCALAR_INTEG_SHIFT;
        sPpMeasFcn->sSpeedIntegrator.f32State     = FRAC32(0.0);
        sPpMeasFcn->uw16Active = true;
        sPpMeasFcn->f16SpeedElRamp = FRAC16(0.0);
        sPpMeasFcn->uw16PpDetermined = 0;
    }

    /* Set Id required */
    *(sPpMeasFcn->pf16IdReq) = sPpMeasFcn->f16IdReqOpenLoop;

    /* Else start incrementing position */
    if(sPpMeasFcn->uw16WaitingSteady == 0)
    {
        /* Ramp electrical speed */
        sPpMeasFcn->f16SpeedElRamp = GFLIB_Ramp_F16(sPpMeasFcn->f16SpeedElReq, &sPpMeasFcn->sSpeedElRampParam);
        /* Integrate electrical speed to get electrical position */
        *sPpMeasFcn->pf16PosEl = GFLIB_IntegratorTR_F16(sPpMeasFcn->f16SpeedElRamp, &sPpMeasFcn->sSpeedIntegrator);
    }

    /* If position overflows, wait 2400ms in zero position */
    if(((*sPpMeasFcn->pf16PosEl < FRAC16(0.0)) && (sPpMeasFcn->f16PosElLast > FRAC16(0.0))) || (sPpMeasFcn->uw16WaitingSteady == 1))
    {
        *sPpMeasFcn->pf16PosEl = FRAC16(-1.0);

        /* Initialise waiting */
        if(sPpMeasFcn->uw16WaitingSteady == 0)
        {
            sPpMeasFcn->uw16LoopCounter = 0;
            sPpMeasFcn->uw16WaitingSteady = 1;
        }

        sPpMeasFcn->uw16LoopCounter++;

        /* Escape waiting in steady position after 2400 ms */
        if(sPpMeasFcn->uw16LoopCounter > TIME_2400MS)
        {
            *sPpMeasFcn->pf16PosEl   = FRAC16(0.0);
            sPpMeasFcn->f16PosElLast = FRAC16(0.0);
            sPpMeasFcn->uw16WaitingSteady = 0;
        }
    }

    /* Save last position */
    sPpMeasFcn->f16PosElLast = sPpMeasFcn->f16PosElCurrent;
    sPpMeasFcn->f16PosElCurrent = *sPpMeasFcn->pf16PosEl;

    if(sPpMeasFcn->uw16PpDetermined > 0)
    {
        /* When finished exit the function */
        sPpMeasFcn->uw16Active = false;
    }
}
