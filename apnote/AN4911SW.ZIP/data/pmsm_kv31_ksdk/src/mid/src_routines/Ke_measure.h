/*******************************************************************************
*
* Copyright 2014 Freescale Semiconductor, Inc.
*
* This software is owned or controlled by Freescale Semiconductor.
* Use of this software is governed by the Freescale License
* distributed with this Material.
* See the LICENSE file distributed for more details.
*
*
****************************************************************************//*!
*
* @file      Ke_measure.h
*
* @author    b40558
*
* @date      May-20-2014
*
* @brief     BackEMF constant measurement routine header file
*
*******************************************************************************
*
* Detailed Description of the file.
*
***************************************************************************//*!*/

#ifndef KE_MEASURE_H_
#define KE_MEASURE_H_

/******************************************************************************
* Includes
******************************************************************************/
/*
Put your #include directives here. Be aware of that using an #include from a
header file makes your application worse readable.
Remove this section if empty
 */
#include "MID_def.h"


#include "SWLIBS_Defines.h"
#include "SWLIBS_Typedefs.h"
#include "gflib.h"
#include "gdflib.h"

/******************************************************************************
* Constants
******************************************************************************/
/*
Put your macro constants here (#define)
 */

/******************************************************************************
* Macros
******************************************************************************/
/*
Put your macro code here (#define with parameters)
 */

/******************************************************************************
* Types
******************************************************************************/
/*
Put your shared typedef statements here
 */
/*Structure for KeMeasure parameters passing*/

typedef struct
{
    UWord16                     uw16Active;         ///<Inidicates whether Ke is being measured (true) or not (false)
    UWord16                     uw16MCATObsrvDone;  ///<Inidicates whether MCAT has calculated Befm observer (true) or not yet (false)
    UWord16                     uw16LoopCounter;    ///<Serves for timing to determine e.g. 300ms
    Frac16*                     pf16PosEl;          ///<Pointer to electrical position for Park transformations
    Frac16*                     pf16UdReq;          ///<Pointer to required voltage Ud which is applied to the motor
    Frac16*                     pf16IdReq;          ///<Pointer to required current Id (PI current controller's input)
    Frac16*                     pf16Idfbck;         ///<Pointer to actual real measured current Id
    Frac32*                     pf32Ed;             ///<Pointer to Befm voltage in d-axis calculated by Bemf observer
    Frac32*                     pf32Eq;             ///<Pointer to Befm voltage in q-axis calculated by Bemf observer
    Frac16                      f16IdReqOpenLoop;   ///<Openloop current
    Frac16                      f16SpeedElReq;      ///<Required Electrical Speed
    Frac16                      f16SpeedElRamp;     ///<Ramped f16SpeedElReq, this speed is integrated to get position
    Frac16                      f16Ke;              ///<Resulting electrical constant
    Word16                      w16ShiftKeMax;      ///<Shift used when calculating e/w, the shift also expresses by how many bit is basic ke scale extended
    GFLIB_RAMP_T_F16            sSpeedElRampParam;  ///<Ramp Up + Down coefficients for f16Speed
    GFLIB_INTEGRATOR_TR_T_F16   sSpeedIntegrator;   ///<Speed integrator coefficients
    GDFLIB_FILTER_MA_T_F32      sEdMA32Filter;      ///<Bemf Ed MA filter
    GDFLIB_FILTER_MA_T_F32      sEqMA32Filter;      ///<Bemf Eq MA filter
}MID_GET_KE_A1_T;

/******************************************************************************
* Global variables
******************************************************************************/
/*
Put your extern references to the application global variables here
 */
extern UWord16  uw16FaultMID;

/******************************************************************************
* Global functions
******************************************************************************/
#ifdef __cplusplus
extern "C" {
#endif

extern void MID_getKe(MID_GET_KE_A1_T* sKeMeasFcn);

#ifdef __cplusplus
}
#endif

/******************************************************************************
* Inline functions
******************************************************************************/
/*
Put code of your inline functions here.
Remove this section if empty
 */

#endif /* KE_MEASURE_H_ */
