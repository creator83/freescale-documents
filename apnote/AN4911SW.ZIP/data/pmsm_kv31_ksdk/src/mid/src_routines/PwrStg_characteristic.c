/*******************************************************************************
*
* Copyright 2014 Freescale Semiconductor, Inc.
*
* This software is owned or controlled by Freescale Semiconductor.
* Use of this software is governed by the Freescale License
* distributed with this Material.
* See the LICENSE file distributed for more details.
*
*
****************************************************************************//*!
*
* @file     PwrStg_characteristic.c
*
* @author   b40558
*
* @date     May-20-2014
*
* @brief    Transfer characteristic measurement
*
* @details  ### Details ###
*           \par
*           Phase voltage required by an application \f$U_{Dreq}\f$ is corrupted
*           by an error voltage \f$U_{err}\f$ introduced by the inverter. For an
*           accurate \f$R_S\f$ measurement the inverter nonlinearity \f$U_{err}\f$
*           has to be determined at first. This \f$U_{err}\f$ is dependent on phase
*           current and this nonlinearity is described by an S-curve shown in
*           \ref Figure_03. The S-curve includes dead-time, current clamping and
*           transistor voltage drop nonlinearities.
*
*           \anchor Figure_03
*           \image latex Nonlinearities1.eps "Inverter's nonlinearity" width=10cm
*           \image html Nonlinearities1.jpg "Inverter's nonlinearity"
*
*           \par
*           Before function #MID_getRs call current loop has to be enabled and
*           current controllers are calculated from \f$R_S = 6.4\Omega\f$,
*           \f$L_d = L_q = 12mH\f$, \f$F0 = 65Hz\f$, \f$ksi = 0.707\f$.
*           These values ensure slow controller response to avoid instability
*           of the whole system. A motor with known RS from interval \f$1 - 50 \Omega\f$ has
*           to be connected to the inverter. DCbus voltage has to be high enough
*           to reach phase current 2A.
*
*           \par
*           The function sets required current \f$I_{Dreq}\f$ gradually from -2A to
*           +2A in 65 steps, each value for 600ms so the current increment after each 300ms is
*           61.5 mA which is also resolution of the measured characteristic.
*           600ms step is long enough to wait until the transient settles. Measurement
*           progress is in Figure_04.
*
*           \anchor Figure_04
*           \image latex transferCharFMSTR.png "Measurement progress" width=10cm
*           \image html transferCharFMSTR.png "Measurement progress"
*
*           \par
*           After each step an error voltage is calculated as follows where
*           \f$R_S \times I_{Dfbck}\f$ represents real output voltage.
*
*           \anchor eq1_TransChar_measure
*           \f[
*           U_{err} = U_{Dreq}-R_S \times I_{Dfbck}
*           \f]
*           \par
*           values are stored in the input structure as #MID_GET_CHAR_A1_T::f16UdErrorLookUp[CHAR_CURRENT_POINT_NUMBERS]
*           These values of the are always valid only for certain inverter, DCbus voltage
*           \f$U_{DCbus}\f$, dead time length \f$T_D\f$ and PWM frequency \f$f_{PWM}\f$.
*           Whole measurement takes 65*600ms = 39s
*
*           ### Faults ###
*           \par
*           If the function detects any unusual state e.g. no motor is connected,
*           the function returns number of a fault. The fault can be recognized
*           according to its number in the following table:
*
*           \par
*           | Fault Number HEX | Fault Description |
*           | ----------------:| :---- |
*           | 0x0001           | No motor connected|
*           | 0x0002           | Too high Rs for characterisation (2A cannot be reached)|
*
***************************************************************************//*!*/

/******************************************************************************
* Includes
******************************************************************************/
#include "PwrStg_characteristic.h"
#include "mlib.h"
#include "gflib.h"

/******************************************************************************
* External objects
******************************************************************************/
/*
In case the declarations you need to use are not put in any header file you
put the "function prototypes" and "extern" variables here.

However, this is not a recommended practise - allowed only if the code you are
referrencing is comming from 3rd party. In your application, you _should_
declare your globals in a header file and include it in any .c file which
consumes them.

Remove this section if empty.
*/


/******************************************************************************
* Global variables
******************************************************************************/
/*
Put instances of global variables here.
*/

/******************************************************************************
* Constants and macros
******************************************************************************/
/*
Put any local-only #define statements here.
 */
#define true  (1)
#define false (0)

/******************************************************************************
* Local types
******************************************************************************/
/*
Put any local-only typedef statements here.
 */
/******************************************************************************
* Local function prototypes
******************************************************************************/
/*
Put any local-only function prototypes here (if needed). All the functions
should be declared static.
 */
/******************************************************************************
* Local variables
******************************************************************************/
/*
Put any local-only variable declarations here. All the variables should be
declared static.
 */
/******************************************************************************
* Local functions
******************************************************************************/
/*
Put code of your local-only static functions here. Each function should have
a pre-code comment describing the function. See examples in the presentation.
 */
/******************************************************************************
* Global functions
******************************************************************************/
/*
Put code of your global static functions here. Each function should have
a pre-code comment describing the function. See examples in the presentation.
 */

/*******************************************************************************
 * Implementation variant: Kinetis and FSL ESL Kinetis libraries
 ******************************************************************************/
/***************************************************************************//*!
*
* @brief   Transfer characteristic measurement function
*
* @param[in]  *sTransferCharFcn     input structure of type #MID_GET_CHAR_A1_T
*                                   for passing all necessary parameters.
*
* @return  none
*
******************************************************************************/
void MID_GetTransferCharacteristic(MID_GET_CHAR_A1_T* sTransferCharFcn)
{
    Frac16 f16Rs_voltage_drop;      /* Auxiliary variable for Rs voltage drop calculation */
    Frac32 f32Rs_voltage_drop;      /* Auxiliary variable for Rs voltage drop calculation */
    Frac32 f32IdReqActual, f32Rs;

    /* Initialisation */
    if(sTransferCharFcn->uw16Active == 0)
    {
        sTransferCharFcn->uw16Active      = true;
        sTransferCharFcn->uw16LoopCounter = 0;
        sTransferCharFcn->f16IdReqActual  = MLIB_Neg_F16(PWR_CHAR_CURRENT_END);
        sTransferCharFcn->f16IdIncrement  = PWR_CHAR_CURRENT_INC;
        *(sTransferCharFcn->pf16IdReq)    = sTransferCharFcn->f16IdReqActual;
        sTransferCharFcn->uw16LUTIndex    = 0;
    }

    /* LoopCounter for time keeping */
    sTransferCharFcn->uw16LoopCounter++;

    /* After 300ms settling of Id start calculation */
    if(sTransferCharFcn->uw16LoopCounter >= TIME_300MS)
    {
        /* Faults */
        /* Check if Rs is low enough to reach 2A */
        if((MLIB_Abs_F16(*(sTransferCharFcn->pf16Idfbck)) < (PWR_CHAR_CURRENT_END - K_I_50MA)) && (sTransferCharFcn->uw16LUTIndex == 0))
        {
            uw16FaultMID |= MID_FAULT_TOO_HIGH_RS;
            sTransferCharFcn->uw16Active   = false;
            *(sTransferCharFcn->pf16IdReq) = FRAC16(0.0);
        }
        /* Check if motor is connected */
        if((MLIB_Abs_F16(*(sTransferCharFcn->pf16Idfbck)) < K_I_50MA) && (sTransferCharFcn->uw16LUTIndex == 0))
        {
            uw16FaultMID |= MID_FAULT_NO_MOTOR;
            sTransferCharFcn->uw16Active   = false;
            *(sTransferCharFcn->pf16IdReq) = FRAC16(0.0);
        }

        /* Calculate voltage drop from Rs and Id */
        /* float eq. V_Rs = Rs * Idfbck */
        /* frac  eq. f16Rs_voltage_drop = (f16Rs * f16Idfbck) << K_RS_MAX_SHIFT */
        f32IdReqActual     = MLIB_ShL_F32((Frac32)sTransferCharFcn->f16IdReqActual, 16);
        f32Rs              = MLIB_ShL_F32((Frac32)sTransferCharFcn->f16Rs, 16);
        f32Rs_voltage_drop = MLIB_ShBi_F32(MLIB_Mul_F32(f32Rs, f32IdReqActual), sTransferCharFcn->w16ShiftRsMax);
        f16Rs_voltage_drop = (Frac16)MLIB_ShR_F32(f32Rs_voltage_drop, 16);

        /* Calculate Error voltage and store it to f16ErrorLookUp */
        /* float eq. Error voltage = Required voltage - Rs voltage drop */
        sTransferCharFcn->f16UdErrorLookUp[sTransferCharFcn->uw16LUTIndex] = MLIB_Sub_F16(*(sTransferCharFcn->pf16UdReq), f16Rs_voltage_drop);

        /* Prepare for next point measurement */
        sTransferCharFcn->uw16LUTIndex++;
        sTransferCharFcn->f16IdReqActual = MLIB_Add_F16(sTransferCharFcn->f16IdReqActual, sTransferCharFcn->f16IdIncrement);
        *(sTransferCharFcn->pf16IdReq) = sTransferCharFcn->f16IdReqActual;
        sTransferCharFcn->uw16LoopCounter = 0;

        /* End after last current was measured */
        if(sTransferCharFcn->uw16LUTIndex >= CHAR_CURRENT_POINT_NUMBERS)
        {
            sTransferCharFcn->uw16Active   = false;
            *(sTransferCharFcn->pf16IdReq) = FRAC16(0.0);
        }
    }
}
