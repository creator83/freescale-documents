/*******************************************************************************
*
* Copyright 2014 Freescale Semiconductor, Inc.
*
* This software is owned or controlled by Freescale Semiconductor.
* Use of this software is governed by the Freescale License
* distributed with this Material.
* See the LICENSE file distributed for more details.
*
*
****************************************************************************//*!
*
* @file      Rs_measure.h
*
* @author    b40558
*
* @date      May-20-2014
*
* @brief     Stator resistance measurement routine header file
*
*******************************************************************************
*
* Detailed Description of the file.
*
***************************************************************************//*!*/

#ifndef RS_MEASURE_H_
#define RS_MEASURE_H_

/******************************************************************************
* Includes
******************************************************************************/
/*
Put your #include directives here. Be aware of that using an #include from a
header file makes your application worse readable.
Remove this section if empty
 */
#include "MID_def.h"


#include "SWLIBS_Defines.h"
#include "SWLIBS_Typedefs.h"

/******************************************************************************
* Constants
******************************************************************************/
/*
Put your macro constants here (#define)
 */

/******************************************************************************
* Macros
******************************************************************************/
/*
Put yout macro code here (#define with parameters)
 */

/******************************************************************************
* Types
******************************************************************************/
/*
Put your shared typedef statements here
 */
/*Structure for RsMeasure parameters passing*/
typedef struct
{
    UWord16     uw16Active;             ///<Inidicates whether Rs is being measured (true) or not (false)
    UWord16     uw16LoopCounter;        ///<Serves for timing to determine e.g. 600ms
    Frac16*     pf16IdReq;              ///<Pointer to required current Id (PI current controller's input)
    Frac16      f16IdMeas;              ///<User defined measuring DC current
    Frac16*     pf16UdReq;              ///<Pointer to required voltage Ud (PI current controller's output)
    Frac16*     pf16Idfbck;             ///<Pointer to actual real measured current Id
    Frac16      f16Rs;                  ///<Measured Rs return
    Frac16*     pf16UdErrorLookUp;      ///<Pointer to Look Up table with the transfer characteristic coefficients
    Word16      w16RescaleIdLUTShift;   ///<Shift amount when re-scaling current Id into range -2A to 2A for LUT
    Frac16      f16RescaleIdLUTGain;    ///<Gain when re-scaling current Id into range -2A to 2A for LUT
    Word16      w16ShiftRsMax;          ///<Shift used when calculating U/I and Rs*I, the shift also expresses by how many bit is basic resistance scale extended
}MID_GET_RS_A1_T;                       ///<Structure containing necessary variable for Rs measurement

/******************************************************************************
* Global variables
******************************************************************************/
/*
Put your extern references to the application global variables here
 */
extern Frac16   f16TransferCharError[];
extern UWord16  uw16FaultMID;

/******************************************************************************
* Global functions
******************************************************************************/
#ifdef __cplusplus
extern "C" {
#endif

extern void MID_getRs(MID_GET_RS_A1_T* sRsMeasFcn);

#ifdef __cplusplus
}
#endif

/******************************************************************************
* Inline functions
******************************************************************************/
/*
Put code of your inline functions here.
Remove this section if empty
 */

#endif /* RS_MEASURE_H_ */
