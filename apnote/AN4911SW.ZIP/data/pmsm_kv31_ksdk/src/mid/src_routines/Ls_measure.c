/*******************************************************************************
*
* Copyright 2014 Freescale Semiconductor, Inc.
*
* This software is owned or controlled by Freescale Semiconductor.
* Use of this software is governed by the Freescale License
* distributed with this Material.
* See the LICENSE file distributed for more details.
*
*
****************************************************************************//*!
*
* @file     Ls_measure.c
*
* @author   b40558
*
* @date     May-20-2014
*
* @brief    Stator inductance measurement routine
*
* @details  ### Details ###
*           \par
*           Function #MID_getLs measures stator inductance using high frequency
*           injection and inductive reactance measurement. At first a measuring
*           signal amplitude and frequency are adjusted. Measuring sinusoidal
*           voltage is injected to D axis. Position for Park transformation
*           is kept zero which produces non-rotating magnetic field as shown in
*           \ref Figure_05.
*
*           \anchor Figure_05
*           \image latex non_rotating_field1.eps "Non-rotating magnetic field" width=10cm
*           \image html non_rotating_field1.jpg "Non-rotating magnetic field"
*
*           \par
*           Testing signal adjustment starts with sine signal with amplitude
*           0V and frequency #MID_GET_LS_A1_T::f16FreqStart. Adjusted signal is applied to the motor for
*           300ms always. At first amplitude gradually increases with increment
*           #MID_GET_LS_A1_T::f16UdIncrement until phase current #MID_GET_LS_A1_T::f16IdAmplitudeReq
*           is reached. The voltage amplitude increases up to #MID_GET_LS_A1_T::f16UdMax
*           which is set before measurement as half of DCbus voltage. If #MID_GET_LS_A1_T::f16IdAmplitudeReq
*           is not reached even with the maximum amplitude, frequency of
*           the sine signal is adjusted. The frequency gradually decreases by
*           #MID_GET_LS_A1_T::f16FreqDecrement again until phase current #MID_GET_LS_A1_T::f16IdAmplitudeReq is
*           reached. The frequency decreases down to #MID_GET_LS_A1_T::f16FreqMin
*           If #MID_GET_LS_A1_T::f16IdAmplitudeReq is not reached
*           even with the minimal frequency, measuring continues anyway and \ref uw16FaultMID is
*           set to 0x0002. Measurement signal tuning is depicted in \ref Figure_07
*
*           \anchor Figure_07
*           \image html Ls_meas_signal.jpg "Measurement signal tuning"
*
*           \par
*           Then the measuring sine signal is applied to the motor and current
*           amplitude #MID_GET_LS_A1_T::f16IdAmplitude is determined. However there might be a distortion of the
*           current amplitude so first 100ms are neglected as shown in \ref Figure_06
*
*           \anchor Figure_06
*           \image latex measuring_signal_Ld1.eps "Measuring signal" width=10cm
*           \image html measuring_signal_Ld1.jpg "Measuring signal"
*
*           \par
*           From the measuring voltage amplitude #MID_GET_LS_A1_T::f16UdAmplitude
*           and current amplitude #MID_GET_LS_A1_T::f16IdAmplitude total
*           impedance of the RL circuit is calculated
*
*           \anchor eq1_Ls_measure
*           \f[
*           Z_{total} = \frac{U_{MAX}}{I_{MAX}}
*           \f]
*           \par
*           Then pure inductive reactance is calculated
*
*           \anchor eq2_Ls_measure
*           \f[
*           X_L = \sqrt{Z_{total}^2 - R_S^2}
*           \f]
*           \par
*           And finally stator inductance is
*
*           \anchor eq3_Ls_measure
*           \f[
*           L_S = \frac{X_L}{2 \times \pi \times f}
*           \f]
*           \par
*           \f$L_S\f$ identification time depends on when #MID_GET_LS_A1_T::f16IdAmplitudeReq is reached.
*           ### Faults ###
*           \par
*           If the function detects any unusual state e.g. no motor is connected,
*           the function returns number of a fault. The fault can be recognized
*           according to its number in the following table:
*
*           \par
*           | Fault Number HEX | Fault Description |
*           | ----------------:| :---- |
*           | 0x0001           | No motor connected|
*           | 0x0040           | Amplitude of Ls measuring current not reached|
*
*
***************************************************************************//*!*/

/******************************************************************************
* Includes
******************************************************************************/
#include "Ls_measure.h"
#include "mlib.h"
#include "gflib.h"

/******************************************************************************
* External objects
******************************************************************************/
/*
In case the declarations you need to use are not put in any header file you
put the "function prototypes" and "extern" variables here.

However, this is not a recommended practise - allowed only if the code you are
referrencing is comming from 3rd party. In your application, you _should_
declare your globals in a header file and include it in any .c file which
consumes them.

Remove this section if empty.
*/


/******************************************************************************
* Global variables
******************************************************************************/
/*
Put instances of global variables here.
 */
/******************************************************************************
* Constants and macros
******************************************************************************/
/*
Put any local-only #define statements here.
 */
#define true  (1)
#define false (0)

/******************************************************************************
* Local types
******************************************************************************/
/*
Put any local-only typedef statements here.
 */
/******************************************************************************
* Local function prototypes
******************************************************************************/
/*
Put any local-only function prototypes here (if needed). All the functions
should be declared static.
 */
/******************************************************************************
* Local variables
******************************************************************************/
/*
Put any local-only variable declarations here. All the variables should be
declared static.
 */
/******************************************************************************
* Local functions
******************************************************************************/
/*
Put code of your local-only static functions here. Each function should have
a pre-code comment describing the function. See exampes in the presentation.
 */
/******************************************************************************
* Global functions
******************************************************************************/
/*
Put code of your global static functions here. Each function should have
a pre-code comment describing the function. See exampes in the presentation.
 */

/*******************************************************************************
 * Implementation variant: Kinetis and FSL ESL Kinetis libraries
 ******************************************************************************/
/***************************************************************************//*!
*
* @brief   Ls estimation function
*
* @param[in]  *sLdMeasFcn   input structure of type #MID_GET_LS_A1_T for passing
*                           all necessary parameters.
*
* @return  none
*
******************************************************************************/

void MID_getLs(MID_GET_LS_A1_T* sLdMeasFcn)
{
    Frac32	f32UdAmplitude, f32UdAmplitudeShifted;
    Frac32	f32XRs;
    Frac32	f32Ztotal;
    Frac32	f32XLd, f32XLd_aux1, f32XLd_aux2;
    Frac32	f32Ld, f32XLdShifted;

    /* Initialisation */
    if(sLdMeasFcn->uw16Active == false)
    {
        sLdMeasFcn->uw16Active        = true;
        sLdMeasFcn->uw16LoopCounter   = 0;
        sLdMeasFcn->w16AmplitudeOK    = false;
        sLdMeasFcn->w16FrequencyOK    = false;
        sLdMeasFcn->f16AngleIncrement = FRAC16(0.0);
        sLdMeasFcn->f16Angle          = FRAC16(0.0);
        sLdMeasFcn->f16IdAmplitude    = FRAC16(0.0);
        sLdMeasFcn->f16UdAmplitude    = FRAC16(0.0);
        sLdMeasFcn->f16Ls             = FRAC16(0.0);
        sLdMeasFcn->f16FreqActual     = sLdMeasFcn->f16FreqStart;
        sLdMeasFcn->f16AngleIncrementConst = K_ANGLE_INCREMENT;
    }

    /* Sine angle increment */
    sLdMeasFcn->f16AngleIncrement = MLIB_Mul_F16(sLdMeasFcn->f16AngleIncrementConst, sLdMeasFcn->f16FreqActual);
    sLdMeasFcn->f16Angle = MLIB_Add_F16(sLdMeasFcn->f16Angle, sLdMeasFcn->f16AngleIncrement);

    /* For time keeping */
    sLdMeasFcn->uw16LoopCounter++;


    /* Measuring voltage amplitude adjusting */
    if(sLdMeasFcn->w16AmplitudeOK != true)
    {
        /* Apply sine voltage (start with 10V/1kHz) for 300ms */
        if(sLdMeasFcn->uw16LoopCounter < TIME_300MS)
            *(sLdMeasFcn->pf16UdReq) = MLIB_Mul_F16(sLdMeasFcn->f16UdAmplitude, GFLIB_Sin(sLdMeasFcn->f16Angle));

        /* If current f16Idfbck > f16MeasCurrentAmp, proceed to frequency adjusting */
        if((sLdMeasFcn->uw16LoopCounter > TIME_100MS) && (*(sLdMeasFcn->pf16Idfbck) > sLdMeasFcn->f16IdAmplitudeReq))
        {
            sLdMeasFcn->w16AmplitudeOK = true;
            *(sLdMeasFcn->pf16UdReq) = FRAC16(0.0);
            sLdMeasFcn->uw16LoopCounter = 0;
        }

        /* After 300ms */
        if(sLdMeasFcn->uw16LoopCounter >= TIME_300MS)
        {
            /* Increase voltage amplitude by f16Ls_Volt_Increment */
            sLdMeasFcn->f16UdAmplitude += sLdMeasFcn->f16UdIncrement;

            /* If voltage amplitude was greater than f16UdMax, proceed to frequency adjusting */
            if(sLdMeasFcn->f16UdAmplitude > sLdMeasFcn->f16UdMax)
            {
                sLdMeasFcn->f16UdAmplitude = sLdMeasFcn->f16UdMax;
                sLdMeasFcn->w16AmplitudeOK = true;
                *(sLdMeasFcn->pf16UdReq) = FRAC16(0.0);
            }

            sLdMeasFcn->uw16LoopCounter = 0;
        }
    }

    /* Measuring frequency adjusting */
    if(sLdMeasFcn->w16AmplitudeOK == true && sLdMeasFcn->w16FrequencyOK != true)
    {
        /* Apply voltage with frequency for 300ms */
        if(sLdMeasFcn->uw16LoopCounter < TIME_300MS)
            *(sLdMeasFcn->pf16UdReq) = MLIB_Mul_F16(sLdMeasFcn->f16UdAmplitude, GFLIB_Sin(sLdMeasFcn->f16Angle));

        /* If current f16Idfbck > f16MeasCurrentAmp, proceed to measurement */
        if((sLdMeasFcn->uw16LoopCounter > TIME_100MS) && (*(sLdMeasFcn->pf16Idfbck) > sLdMeasFcn->f16IdAmplitudeReq))
        {
            sLdMeasFcn->w16FrequencyOK = true;
            *(sLdMeasFcn->pf16UdReq) = FRAC16(0.0);
            sLdMeasFcn->uw16LoopCounter = 0;
        }

        /* After 300ms */
        if(sLdMeasFcn->uw16LoopCounter >= TIME_300MS)
        {
            /* Decrease frequency by f16Ls_Freq_Decrement */
            sLdMeasFcn->f16FreqActual -= sLdMeasFcn->f16FreqDecrement;

            /* If frequency was lower than f16FreqMin, proceed to measurement */
            if(sLdMeasFcn->f16FreqActual < sLdMeasFcn->f16FreqMin)
            {
                sLdMeasFcn->f16FreqActual = sLdMeasFcn->f16FreqMin;
                sLdMeasFcn->w16FrequencyOK = true;
                *(sLdMeasFcn->pf16UdReq) = FRAC16(0.0);
            }

            sLdMeasFcn->uw16LoopCounter = 0;
        }
    }

    /* When amplitude and frequency adjusted, start Ld measurement */
    if(sLdMeasFcn->w16AmplitudeOK == true && sLdMeasFcn->w16FrequencyOK == true)
    {
        /* Apply measuring signal */
        if(sLdMeasFcn->uw16LoopCounter <= TIME_300MS)
        {
            /* Sine to d_axis */
            *(sLdMeasFcn->pf16UdReq) = MLIB_Mul_F16(sLdMeasFcn->f16UdAmplitude, GFLIB_Sin(sLdMeasFcn->f16Angle));

            /* Current amplitudes after 100ms delay */
            if((sLdMeasFcn->uw16LoopCounter > TIME_100MS) && (*(sLdMeasFcn->pf16Idfbck) > sLdMeasFcn->f16IdAmplitude))
                sLdMeasFcn->f16IdAmplitude = *(sLdMeasFcn->pf16Idfbck);
        }

        /* Inductance calculation */
        if(sLdMeasFcn->uw16LoopCounter > TIME_300MS)
        {
            /* Total circuit reactance */
            /* float eq. Z = Ud / Id */
            /* frac  eq. f32Rs_voltage_drop = (f16Ud_max1  << w16K_Z_Max_Shift) / f16Id_max1 */
            f32UdAmplitude = MLIB_ShL_F32((Frac32)sLdMeasFcn->f16UdAmplitude, 16);

            /* Set the w16ShiftZsMax to -16 */
            sLdMeasFcn->w16ShiftZsMax = -16;

            /* Divide U/I and always increase w16ShiftZsMax until the Ztotal result is positive and f32UdAmplitudeShifted is not saturated */
            do
            {
                sLdMeasFcn->w16ShiftZsMax++;
                f32UdAmplitudeShifted = MLIB_ShBiSat_F32(f32UdAmplitude, -sLdMeasFcn->w16ShiftZsMax);
                f32Ztotal = MLIB_DivSat_F32(f32UdAmplitudeShifted, MLIB_ShL_F32((Frac32)sLdMeasFcn->f16IdAmplitude, 16));

            }while(f32Ztotal >= FRAC32(1.0) || f32UdAmplitudeShifted >= FRAC32(1.0));

            /* Rs re-scaling from FM_RS_SCALE => FM_Z_SCALE */
            f32XRs = MLIB_ShBi_F32(MLIB_ShL_F32((Frac32)sLdMeasFcn->f16Rs, 16), -(sLdMeasFcn->w16ShiftZsMax - sLdMeasFcn->w16ShiftRsMax));

            /* Pure inductive reactance */
            /* float eq. XL = sqrt(Z^2 - R^2) */
            /* frac  eq. f32XLd = sqrt((f32Ztotal*f32Ztotal)-(f32XRs*f32XRs)) */
            f32XLd_aux1 = MLIB_Mul_F32(f32Ztotal, f32Ztotal);
            f32XLd_aux2 = MLIB_Mul_F32(f32XRs, f32XRs);
            f32XLd = GFLIB_Sqrt_F32(MLIB_Sub_F32(f32XLd_aux1, f32XLd_aux2));

            /* Inductance */
            /* float eq. L = XL / (2*pi*f) */
            /* frac  eq. f32Ld = (f32XLd  << w16K_L_Max_Shift) / f16MeasFreq */

            /* Set the w16ShiftLMax to -16 */
            sLdMeasFcn->w16ShiftLsMax = -16;

            /* Divide U/I and always increase w16ShiftZMax until the Ztotal result is positive and f32UdAmplitudeShifted is not saturated */
            do
            {
                sLdMeasFcn->w16ShiftLsMax++;
                f32XLdShifted = MLIB_ShBiSat_F32(f32XLd, -sLdMeasFcn->w16ShiftLsMax);
                f32Ld = MLIB_DivSat_F32(f32XLdShifted, MLIB_ShL_F32((Frac32)sLdMeasFcn->f16FreqActual, 16));

            }while(f32Ld >= FRAC32(1.0) || f32XLdShifted >= FRAC32(1.0));

            /* Return Frac16 inductance */
            sLdMeasFcn->f16Ls = (Frac16)MLIB_ShR_F32(f32Ld, 16);

            sLdMeasFcn->uw16Active = false;
            *(sLdMeasFcn->pf16UdReq) = FRAC16(0.0);

            /* Check Faults */
            /* Check if f16MeasCurrentAmp was reached (95% of the f16MeasCurrentAmp) */
            if(sLdMeasFcn->f16IdAmplitude < MLIB_Mul_F16(sLdMeasFcn->f16IdAmplitudeReq, FRAC16(0.95)))
                uw16FaultMID |= MID_FAULT_AC_CUR_NOT_REACHED;

            /* Check negative result or saturation of Z*/
            if(f32Ztotal < FRAC32(0.0) || f32Ztotal == FRAC32(1.0))
                uw16FaultMID |= MID_FAULT_Z_OUT_OF_RANGE;

                        /* Check negative result or saturation of Ls*/
            if(sLdMeasFcn->f16Ls < FRAC16(0.0) || sLdMeasFcn->f16Ls == FRAC16(1.0))
                uw16FaultMID |= MID_FAULT_LS_OUT_OF_RANGE;

            /* Check if motor is connected */
            if(sLdMeasFcn->f16IdAmplitude < K_I_50MA)
                uw16FaultMID |= MID_FAULT_NO_MOTOR;
        }
    }
}
