/*******************************************************************************
*
* Copyright 2014 Freescale Semiconductor, Inc.
*
* This software is owned or controlled by Freescale Semiconductor.
* Use of this software is governed by the Freescale License
* distributed with this Material.
* See the LICENSE file distributed for more details.
*
*
****************************************************************************//*!
*
* @file      PwrStg_characteristic.h
*
* @author    b40558
*
* @date      May-20-2014
*
* @brief     Transfer characteristic measurement header file
*
*******************************************************************************
*
* Detailed Description of the file.
*
***************************************************************************//*!*/

#ifndef PWRSTG_CHARASTERISTIC_H_
#define PWRSTG_CHARASTERISTIC_H_

/******************************************************************************
* Includes
******************************************************************************/
/*
Put your #include directives here. Be aware of that using an #include from a
header file makes your application worse readable.
Remove this section if empty
 */
#include "MID_def.h"


#include "SWLIBS_Defines.h"
#include "SWLIBS_Typedefs.h"

/******************************************************************************
* Constants
******************************************************************************/
/*
Put your macro constants here (#define)
 */

/******************************************************************************
* Macros
******************************************************************************/
/*
Put your macro code here (#define with parameters)
 */

/******************************************************************************
* Types
******************************************************************************/
/*
Put your shared typedef statements here
 */
/* Structure for GetTransferCharacteristic parameters passing */
typedef struct
{
UWord16    uw16Active;                ///< Inidicates whether Transfer characteristic is being measured (true) or not (false)
UWord16    uw16LoopCounter;           ///< Serves for timing to determine e.g. 600ms
Frac16     f16Rs;                     ///< Stator resistance of connected motor
Frac16*    pf16IdReq;                 ///< Pointer to required current Id (PI current controller's input)
Frac16*    pf16UdReq;                 ///< Pointer to required voltage Ud (PI current controller's output)
Frac16*    pf16Idfbck;                ///< Pointer to actual real measured current Id
Frac16     f16IdReqActual;            ///< Actual current at which is the characteristic being measured at the moment
Frac16     f16UdErrorLookUp[CHAR_CURRENT_POINT_NUMBERS];  ///< Ud error voltages
UWord16    uw16LUTIndex;              ///< Lookup table index, counts up to 65 until a whole characteristic is measured
Frac16     f16IdIncrement;            ///< Id increment after each 300ms
Word16     w16ShiftRsMax;             ///< Shift used when calculating U/I and Rs*I, the shift also expresses by how many bit is basic resistance scale extended
}MID_GET_CHAR_A1_T;

/******************************************************************************
* Global variables
******************************************************************************/
/*
Put your extern references to the application global varables here
 */
extern UWord16  uw16FaultMID;

/******************************************************************************
* Global functions
******************************************************************************/
#ifdef __cplusplus
extern "C" {
#endif

extern void MID_GetTransferCharacteristic(MID_GET_CHAR_A1_T* sTransferCharFcn);

#ifdef __cplusplus
}
#endif

/******************************************************************************
* Inline functions
******************************************************************************/
/*
Put code of your inline functions here.
Remove this section if empty
 */

#endif /* PWRSTG_CHARASTERISTIC_H_ */
