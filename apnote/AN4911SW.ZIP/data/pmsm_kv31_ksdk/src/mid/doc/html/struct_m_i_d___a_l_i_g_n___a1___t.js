var struct_m_i_d___a_l_i_g_n___a1___t =
[
    [ "f16CurrentAlign", "struct_m_i_d___a_l_i_g_n___a1___t.html#a9f6fc5496300bc7d617ba28969477ea9", null ],
    [ "pf16IdReq", "struct_m_i_d___a_l_i_g_n___a1___t.html#a48027336cbab0a0f4442a8bf325c7258", null ],
    [ "uw16Active", "struct_m_i_d___a_l_i_g_n___a1___t.html#a674fb088318ecec597817da6ea1d958d", null ],
    [ "uw16AlignDuration", "struct_m_i_d___a_l_i_g_n___a1___t.html#a699244a09efb5a62ed6aa43f56b97212", null ],
    [ "uw16LoopCounter", "struct_m_i_d___a_l_i_g_n___a1___t.html#a64518747615877c7bc8f176a27f87ddc", null ]
];