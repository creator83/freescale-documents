var struct_m_i_d___g_e_t___p_p___a1___t =
[
    [ "f16IdReqOpenLoop", "struct_m_i_d___g_e_t___p_p___a1___t.html#a713e602531ba4e0d18c32a44fb4a71e1", null ],
    [ "f16PosElCurrent", "struct_m_i_d___g_e_t___p_p___a1___t.html#a1bbda50189c47135887e77b0e4287009", null ],
    [ "f16PosElLast", "struct_m_i_d___g_e_t___p_p___a1___t.html#a811e8d65aba15e731369e0bcaca28ff7", null ],
    [ "f16SpeedElRamp", "struct_m_i_d___g_e_t___p_p___a1___t.html#a2aae81ecd6b80ab4ec43b082eb6a14d6", null ],
    [ "f16SpeedElReq", "struct_m_i_d___g_e_t___p_p___a1___t.html#aee58ff8101c3849801704e02c0dcd564", null ],
    [ "pf16IdReq", "struct_m_i_d___g_e_t___p_p___a1___t.html#a993750f54610523401c68e18e6fbeb54", null ],
    [ "pf16PosEl", "struct_m_i_d___g_e_t___p_p___a1___t.html#ad39336ac5da3567d4d10874e1aea7ee4", null ],
    [ "sSpeedElRampParam", "struct_m_i_d___g_e_t___p_p___a1___t.html#a19b8a9755c48ad3e55fc565f5783d4c1", null ],
    [ "sSpeedIntegrator", "struct_m_i_d___g_e_t___p_p___a1___t.html#ab65b7cbc7dd0e017da42011897f36c01", null ],
    [ "uw16Active", "struct_m_i_d___g_e_t___p_p___a1___t.html#a9dbe722aa6c3d4afb2dfea659629ebbc", null ],
    [ "uw16LoopCounter", "struct_m_i_d___g_e_t___p_p___a1___t.html#a80ad7c81e8420d8b5b43f9c77838deb6", null ],
    [ "uw16PpDetermined", "struct_m_i_d___g_e_t___p_p___a1___t.html#a164aebb5875505ed546dda04e3e3d661", null ],
    [ "uw16WaitingSteady", "struct_m_i_d___g_e_t___p_p___a1___t.html#a561e7ff6bfca98350dae98b7fa7746df", null ]
];