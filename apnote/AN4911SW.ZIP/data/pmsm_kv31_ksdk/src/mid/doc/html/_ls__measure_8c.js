var _ls__measure_8c =
[
    [ "false", "_ls__measure_8c.html#a65e9886d74aaee76545e83dd09011727", null ],
    [ "true", "_ls__measure_8c.html#a41f9c5fb8b08eb5dc3edce4dcb37fee7", null ],
    [ "MID_getLs", "_ls__measure_8c.html#a6b134a09ad1c13db05aa819d27377118", null ]
];