var struct_m_i_d___g_e_t___k_e___a1___t =
[
    [ "f16IdReqOpenLoop", "struct_m_i_d___g_e_t___k_e___a1___t.html#a0eb5265c0a08dd6dbb55d85c777de8ca", null ],
    [ "f16Ke", "struct_m_i_d___g_e_t___k_e___a1___t.html#aaacb0cef58c05ca98c8d8be8450d86df", null ],
    [ "f16SpeedElRamp", "struct_m_i_d___g_e_t___k_e___a1___t.html#a5b46f7c7b9c9e399cd6598e1be3a795a", null ],
    [ "f16SpeedElReq", "struct_m_i_d___g_e_t___k_e___a1___t.html#a59c4e3e4048421833747f0239d9c22c9", null ],
    [ "pf16Idfbck", "struct_m_i_d___g_e_t___k_e___a1___t.html#a37d9c2c427937e218b00c17a0fdd3115", null ],
    [ "pf16IdReq", "struct_m_i_d___g_e_t___k_e___a1___t.html#aad48f3a676fb3bcb3edbdbbc5cf5809b", null ],
    [ "pf16PosEl", "struct_m_i_d___g_e_t___k_e___a1___t.html#a3beaf880a87c18f258c9da755db9d069", null ],
    [ "pf16UdReq", "struct_m_i_d___g_e_t___k_e___a1___t.html#a2dcfdfa6a003014c425188740d13322b", null ],
    [ "pf32Ed", "struct_m_i_d___g_e_t___k_e___a1___t.html#ac90cfb01ad1ce212ab3617dbba846b53", null ],
    [ "pf32Eq", "struct_m_i_d___g_e_t___k_e___a1___t.html#a64f29c32475c14ba20f45b8909d35b8b", null ],
    [ "sEdMA32Filter", "struct_m_i_d___g_e_t___k_e___a1___t.html#af9f702a55dff8bc2af4d93e12a1c52e4", null ],
    [ "sEqMA32Filter", "struct_m_i_d___g_e_t___k_e___a1___t.html#a6309284a96e4ab06bc8a9128715e65f9", null ],
    [ "sSpeedElRampParam", "struct_m_i_d___g_e_t___k_e___a1___t.html#ad447b2917da17873607d39987623a880", null ],
    [ "sSpeedIntegrator", "struct_m_i_d___g_e_t___k_e___a1___t.html#a51273070320b0f99a7bb94890d9d4baf", null ],
    [ "uw16Active", "struct_m_i_d___g_e_t___k_e___a1___t.html#a9791da407e09afb9880ee552375cb5dc", null ],
    [ "uw16LoopCounter", "struct_m_i_d___g_e_t___k_e___a1___t.html#a0e80e36f2d00230452ce784a192bc141", null ],
    [ "uw16MCATObsrvDone", "struct_m_i_d___g_e_t___k_e___a1___t.html#a501276a78ed3c8937860c5730aff30ca", null ],
    [ "w16ShiftKeMax", "struct_m_i_d___g_e_t___k_e___a1___t.html#ad9776105fa6b85398fa067d0c29ff2c8", null ]
];