var _m_i_d__def_8h =
[
    [ "MID_FAULT_AC_CUR_NOT_REACHED", "_m_i_d__def_8h.html#a558b59450737cd11cb951804b39bdeb8", null ],
    [ "MID_FAULT_DC_CUR_NOT_REACHED", "_m_i_d__def_8h.html#a6e2ace0356d51b35f5ad2adb9397083e", null ],
    [ "MID_FAULT_KE_OUT_OF_RANGE", "_m_i_d__def_8h.html#ac91d0d7ab94a68d7ba9accd45902675f", null ],
    [ "MID_FAULT_LS_OUT_OF_RANGE", "_m_i_d__def_8h.html#a936f5ad0eeec0e3a3f2826cc5ab2d88a", null ],
    [ "MID_FAULT_NO_MOTOR", "_m_i_d__def_8h.html#af344c89dd77d98fada0a0d50f349b0f3", null ],
    [ "MID_FAULT_RS_OUT_OF_RANGE", "_m_i_d__def_8h.html#aa12f30775e3cdc2b5fcd1a9d058b5bca", null ],
    [ "MID_FAULT_TOO_HIGH_RS", "_m_i_d__def_8h.html#a3c97cfb5b40264d83fdf65d685df41f3", null ],
    [ "MID_FAULT_Z_OUT_OF_RANGE", "_m_i_d__def_8h.html#aae55a3424b06eee09f4377eac02e60f7", null ],
    [ "MID_KI_GAIN", "_m_i_d__def_8h.html#a054fbdae422a976d9c45bcb861700cca", null ],
    [ "MID_KI_SHIFT", "_m_i_d__def_8h.html#aafff8fc388b111cb6aec1a326e9bd026", null ],
    [ "MID_KP_GAIN", "_m_i_d__def_8h.html#a67c21b7e67f9ff483bfe080b810fcdc4", null ],
    [ "MID_KP_SHIFT", "_m_i_d__def_8h.html#afd961b09e102c6a3646db919ac5f02f6", null ],
    [ "MID_SPEED_RAMP_DOWN", "_m_i_d__def_8h.html#a66c9beae9abf47fa09227f66d7908c9d", null ],
    [ "MID_SPEED_RAMP_UP", "_m_i_d__def_8h.html#a62cfa35bfe611c5fe456d247620b66f7", null ]
];