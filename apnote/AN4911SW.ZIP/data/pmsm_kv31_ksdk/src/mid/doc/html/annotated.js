var annotated =
[
    [ "MID_ALIGN_A1_T", "struct_m_i_d___a_l_i_g_n___a1___t.html", "struct_m_i_d___a_l_i_g_n___a1___t" ],
    [ "MID_GET_CHAR_A1_T", "struct_m_i_d___g_e_t___c_h_a_r___a1___t.html", "struct_m_i_d___g_e_t___c_h_a_r___a1___t" ],
    [ "MID_GET_KE_A1_T", "struct_m_i_d___g_e_t___k_e___a1___t.html", "struct_m_i_d___g_e_t___k_e___a1___t" ],
    [ "MID_GET_LS_A1_T", "struct_m_i_d___g_e_t___l_s___a1___t.html", "struct_m_i_d___g_e_t___l_s___a1___t" ],
    [ "MID_GET_PP_A1_T", "struct_m_i_d___g_e_t___p_p___a1___t.html", "struct_m_i_d___g_e_t___p_p___a1___t" ],
    [ "MID_GET_RS_A1_T", "struct_m_i_d___g_e_t___r_s___a1___t.html", "struct_m_i_d___g_e_t___r_s___a1___t" ],
    [ "MID_SM_APP_CTRL_T", "struct_m_i_d___s_m___a_p_p___c_t_r_l___t.html", "struct_m_i_d___s_m___a_p_p___c_t_r_l___t" ],
    [ "MID_SM_APP_STATE_FCN_T", "struct_m_i_d___s_m___a_p_p___s_t_a_t_e___f_c_n___t.html", "struct_m_i_d___s_m___a_p_p___s_t_a_t_e___f_c_n___t" ],
    [ "MID_SM_APP_TRANS_FCN_T", "struct_m_i_d___s_m___a_p_p___t_r_a_n_s___f_c_n___t.html", "struct_m_i_d___s_m___a_p_p___t_r_a_n_s___f_c_n___t" ]
];