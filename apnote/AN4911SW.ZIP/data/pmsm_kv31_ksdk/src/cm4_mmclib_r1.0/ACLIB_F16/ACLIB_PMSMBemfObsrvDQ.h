/******************************************************************************
* 
* Copyright (c) 2008 - 2011 Freescale Semiconductor;
* All Rights Reserved                       
*
*******************************************************************************
*
* THIS SOFTWARE IS PROVIDED BY FREESCALE "AS IS" AND ANY EXPRESSED OR 
* IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES 
* OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  
* IN NO EVENT SHALL FREESCALE OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
* INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
* SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
* STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING 
* IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF 
* THE POSSIBILITY OF SUCH DAMAGE.
*
***************************************************************************//*!
*
* @file      ACLIB_PMSMBemfObsrvDQ.h
*
* @author    r59400, plcm001
* 
* @version   1.0.3.0
* 
* @date      Oct-25-2013
*            Ported to K40 by PLCM001 : Nov-2011       
* 
* @brief     template
*
*******************************************************************************
*
* Detailed Description of the file.
*
******************************************************************************/
#ifndef _ACLIB_PMSM_BEMF_OBSRV_DQ_H
#define _ACLIB_PMSM_BEMF_OBSRV_DQ_H

/******************************************************************************
* Includes
******************************************************************************/

#include "SWLIBS_Defines.h"
#include "mlib.h"
#include "gflib.h"


/******************************************************************************
* Constants
******************************************************************************/

/******************************************************************************
* Macros 
******************************************************************************/	

/******************************************************************************
* Types
******************************************************************************/
typedef struct
{
	//Extended BEMF - d/q
	struct
	{
		Frac32 f32D;
		Frac32 f32Q;	
	} udtEObsrv;

	//Accumulators - d/q
	struct
	{
		Frac32 f32D;
		Frac32 f32Q;	
	} udtIObsrv;
	
	//Observer parameters for controllers
	struct
	{
		Frac32		f32ID_1;	//d-accumulator
		Frac32		f32IQ_1;	//q-accumulator
		Frac16  	f16PropScaled;
		Int16		i16PropShift;
		Frac16  	f16IntegScaled;	
		Int16		i16IntegShift;
	} udtCtrl;

	//misalignment error of reference frame
	Frac16	f16Error;

	//Configuration parameters 
	Frac16	f16IScaled; 	//current
	Frac16	f16UScaled; 	//voltage
	Frac16	f16WIScaled;	//decoupling
	Frac16	f16EScaled;		//extended BEMF
	
} ACLIB_BEMF_OBSRV_DQ_T_F16;




/******************************************************************************
* Global variables
******************************************************************************/
   
/******************************************************************************
* Global functions
******************************************************************************/
extern void ACLIB_PMSMBemfObsrvDQ_F16
(
    MCLIB_2_COOR_SYST_D_Q_T_F16 *pudtIdq,
    MCLIB_2_COOR_SYST_D_Q_T_F16 *pudtUdq,
    Frac16 f16Speed, 
    ACLIB_BEMF_OBSRV_DQ_T_F16 * const pudtCtrl
);
/******************************************************************************
* Inline functions
******************************************************************************/

#endif /* _ACLIB_PMSM_BEMF_OBSRV_DQ_H */		
