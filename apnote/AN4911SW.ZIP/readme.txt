    readme.txt file for PMSM Control Framework under KSDK
	               TWR-KV31  Release r1.0
	======================================================

Installation instructions:
==========================
1. The PMSM control framework requires instalation of Freescale KSDK-1.0.0 on
   the computer (www.freescale.com/ksdk)
2. Run mc_sdk_setup program and procced according to the instructions
    - read licence agreement and check the box "Agree" below the licence text
    - specify the destination folder the Freescale MC framework will be installed to
    - specify the installation folder of KDSK-1.0.0
3. Click "next" button to complete the installation
4. Read AN4911 to setup and run the KV31 MC framework
   - http://cache.freescale.com/files/32bit/doc/app_note/AN4911.pdf 
