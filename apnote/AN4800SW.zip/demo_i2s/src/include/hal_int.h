

void hal_int_enable(void);
void hal_int_disable(void);
void hal_relocation(void);

