
#ifndef __HAL_I2C__
#define __HAL_I2C__

void hal_i2c_init(void);

#endif

