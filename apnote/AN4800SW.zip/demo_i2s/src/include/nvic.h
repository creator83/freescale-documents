

#define IRQ_DMA0  0
#define IRQ_DMA1  1
#define IRQ_DMA2  2
#define IRQ_DMA3  3
#define IRQ_ETH_T 76
#define IRQ_ETH_R 77


void nvic_enable_irq(u8 irq_n);



