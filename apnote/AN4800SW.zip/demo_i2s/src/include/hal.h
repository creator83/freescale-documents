

#ifndef __HAL__
#define __HAL__

void hal_init(void);

#endif

