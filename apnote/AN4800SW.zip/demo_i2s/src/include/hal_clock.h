
#ifndef __HAL_CLOCK__
#define __HAL_CLOCK__


void hal_clock_init(void);

#endif

