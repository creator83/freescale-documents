
#ifndef __HAL_WATCHDOG__
#define __HAL_WATCHDOG__

void hal_watchdog_close(void);

#endif

