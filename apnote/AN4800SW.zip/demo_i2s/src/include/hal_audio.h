



void hal_audio_init(void);
void hal_audio_play(s32 *sin_table, s32 *sin_table2, uint buf_size);
void hal_fill_tx_buf(s32 *p_r, s32 *p_l, uint buf_n_sample);


