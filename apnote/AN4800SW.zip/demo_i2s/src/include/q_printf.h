




#ifndef __q_printf__
#define __q_printf__

void print_buf(void *buf, uint size);

#endif

