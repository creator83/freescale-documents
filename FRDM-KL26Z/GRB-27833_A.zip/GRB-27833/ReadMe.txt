README for GRB-27833_A.zip

Company Part Number: 170-27833 REV A

Date : Fri, 08 Mar 2013 14:17:40 GMT

Freescale Semiconductor
7700 West Parmer Lane
Austin, TX 78729
Maildrop: PL59

Company Contact: [full_name]
	Work Phone: (512)996-XXXX
		 Email:	 [email]@freescale.com