README for GRB-28163_E.zip

Company Part Number: 170-28163 REV E

Date : Fri, 01 Aug 2014 14:33:55 GMT

Freescale Semiconductor
6501 William Cannon Drive West
Austin, TX 78735-8598

Company Contact: Alberto Carrillo
Work Phone:52-3332832100
Email:	albertocarrillo@freescale.com